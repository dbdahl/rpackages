void *cargodummy();
