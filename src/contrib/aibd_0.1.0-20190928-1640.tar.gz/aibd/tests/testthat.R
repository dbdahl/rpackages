library(testthat)
library(aibd)

test_check("aibd")
