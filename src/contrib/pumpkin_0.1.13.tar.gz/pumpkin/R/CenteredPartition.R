#' Probabilities for the Centered Partition Process
#'
#' This function evaluates the probability mass function of the centered
#' partition distribution for given target partition, weight, mass (a.k.a.,
#' concentration), and discount parameters.
#'
#' @inheritParams FocalPartition
#' @param weight A numeric value giving the weight.
#' @param useVI Should the distance between the a particular partition and the
#'   target partition be measured using the variation of information
#'   (\code{TRUE}) or using Binder loss (\code{FALSE})?
#' @param a A nonnegative scalar giving the relative cost of placing two items
#'   in separate clusters when in truth they belong to the same cluster.  This
#'   defaults to \code{1}, meaning equal costs.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/CenteredPartition.R
#' @export
#'
CenteredPartition <- function(target, weight, mass, discount=0, useVI=TRUE, a=1.0) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  if ( length(weight) != 1 ) stop("'weight' must be a scalar.")
  if ( weight < 0.0 ) stop("'weight' must be nonnegative.")
  checkMassDiscount(mass, discount)
  if ( ! is.logical(useVI) ) stop("'useVI' must be a logical.")
  if ( length(a) != 1 ) stop("'a' must be a scalar.")
  if ( a < 0.0 ) stop("'a' must be nonnegative.")
  result <- list(nItems=nItems, target=target, weight=weight, mass=mass, discount=discount, useVI=useVI, a=a)
  class(result) <- c("CenteredPartition", "partitionDistribution")
  result
}

#' @export
print.CenteredPartition <- function(x, ...) {
  cat("\nCentered partition distribution\n\n")
  print(unclass(x))
}
