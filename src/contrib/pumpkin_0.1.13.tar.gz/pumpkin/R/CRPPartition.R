#' Probabilities for the Chinese Restaurant Process (CRP) Partition Distribution
#'
#' This function evaluates the probability mass function of the Chinese
#' restaurant process (CRP) partition distribution for given mass (a.k.a.,
#' concentration) and discount parameters.
#'
#' @param nItems An integer giving the number of items in each partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/CRPPartition.R
#' @export
#'
CRPPartition <- function(nItems, mass, discount=0) {
  if ( nItems < 1 ) stop("'nItems' must be at least one.")
  checkMassDiscount(mass, discount)
  result <- list(nItems=nItems, mass=mass, discount=discount)
  class(result) <- c("CRPPartition", "partitionDistribution")
  return(result)
}

#' @export
print.CRPPartition <- function(x, ...) {
  cat("\nChinese restaurant process partition distribution\n\n")
  print(unclass(x))
}
