#' Compute the (Log of) the Probability of a Partition
#'
#' This function computes (the log of) the probability of the supplied
#' partitions for the given partition distribution.
#'
#' @inheritParams samplePartition
#' @param partition A matrix of integers giving cluster labels on the rows. For
#'   partition \eqn{k}, items \eqn{i} and \eqn{j} are in the same cluster if and
#'   only if \code{partition[k,i] == partition[k,j]}.
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logarithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @seealso \code{\link{CRPPartition}}, \code{\link{FocalPartition}},
#'   \code{\link{LocationScalePartition}}, \code{\link{CenteredPartition}},
#'   \code{\link{samplePartition}}, \code{\link{nealAlgorithm3}},
#'   \code{\link{nealAlgorithm8}}
#'
#' @example man/examples/prPartition.R
#'
#' @useDynLib pumpkin .prPartition
#' @export
#'
prPartition <- function(distr, partition, log=TRUE) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  nSamples <- nrow(partition)
  if ( nSamples == 0 ) return(numeric(0))
  logProbabilities <- partitionDispatch(function(priorID, p) .Call(.prPartition, partition, priorID, p), distr)
  if (log) logProbabilities else exp(logProbabilities)
}
