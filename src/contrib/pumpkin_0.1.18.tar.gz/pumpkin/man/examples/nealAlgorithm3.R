# Neal (2000) model and data

data <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
sigma2 <- 0.1^2
mu0 <- 0
sigma02 <- 1

logIntegratedLikelihoodItem <- function(i, subset) {
  posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
  posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
  posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
  dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
}

# Prior partition distribution.  Many are supported.

mass <- 1.5
discount <- 0.2
baselinePartition <- c(1,1,2,2,2,3,4,4,4)
permutation <- sample(length(baselinePartition))

distr <- CRPPartition(length(data), mass, discount)
distr <- LocationScalePartition(baselinePartition, 3, permutation)
distr <- CenteredPartition(baselinePartition, weight=3, mass, discount)
distr <- FocalPartition(baselinePartition, weights=c(3,3,1,1,1,0,5,5,0), permutation, mass,discount)
distr <- TiltedPartition(baselinePartition, weights=c(3,3,1,1,1,0,5,5,0), permutation,
                         baselineDistribution=CRPPartition(length(data), mass, discount))

subset <- c("Maine","Georgia","California","Minnesota","Oregon","Utah","Wisconsin","Texas","Nevada")
d <- as.matrix(dist(scale(USArrests[subset,])))
temperature <- 1.0
similarity <- exp( -temperature * d )
distr <- EPAPartition(similarity, permutation, mass, discount)

# MCMC

mcmcTuning <- list(nUpdates=2)
nSamples <- 100L
partitionSamples <- matrix(1, nrow=nSamples, ncol=length(data))
nAcceptancesPermutation <- 0L
for ( i in 2:nSamples ) {
  # Update partition
  partitionSamples[i,] <- nealAlgorithm3(partitionSamples[i-1,], distr,
                                         logIntegratedLikelihoodItem, mcmcTuning)$partition
  # Update permutation
  out <- updatePermutation(distr, partitionSamples[i,], k=length(data)/2)
  distr <- out$distr
  nAcceptancesPermutation <- nAcceptancesPermutation + out$accepted
  # Perhaps add code to update other parameters, e.g., mass, discount, etc.
}

# Acceptance rate for updating the permutation
nAcceptancesPermutation / nSamples

nSubsets <- apply(partitionSamples, 1, function(x) length(unique(x)))
plot(nSubsets, type="l")
mean(nSubsets)
sum(acf(nSubsets)$acf)-1   # Autocorrelation time

