mass <- 1.0
discount <- 0.1
nSamples <- 3

distr <- CRPPartition(nItems=5, mass, discount)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

baselinePartition <- c(1,1,1,2,2)
permutation <- c(1,5,4,2,3)

distr <- LocationScalePartition(baselinePartition, weights=1/0.1, permutation)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

distr <- FocalPartition(baselinePartition, weights=c(10,10,10,3,3), permutation, mass, discount)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

distr <- CenteredPartition(baselinePartition, weights=1/0.1, uniform=FALSE, mass, discount)
prPartition(distr, x)

subset <- c("Maine","Georgia","California","Minnesota","Montana")
d <- as.matrix(dist(scale(USArrests[subset,])))
temperature <- 1.0
similarity <- exp( - temperature * d )
distr <- EPAPartition(similarity, permutation, mass, discount)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

