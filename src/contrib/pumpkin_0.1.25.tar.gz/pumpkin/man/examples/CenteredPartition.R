CenteredPartition(baselinePartition=c(1,1,1,2,2), weights=3, uniform=FALSE, mass=1.0, discount=0.1)
