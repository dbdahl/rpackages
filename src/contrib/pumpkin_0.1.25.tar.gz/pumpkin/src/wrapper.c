#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

// Actual Wrappers
RR_SEXP sexp_to_rr_sexp(SEXP sexp) {
  RR_SEXP s;
  s.sexp_ptr = (void*) sexp;
  return s;
}

RR_SEXP null_rr_sexp() {
  RR_SEXP s;
  s.sexp_ptr = (void*) 0;
  return s;
}

RR_SEXP_vector_INTSXP rrAllocVectorINTSXP(int len) {
  RR_SEXP_vector_INTSXP s;
  s.sexp_ptr = (void*) PROTECT(Rf_allocVector(INTSXP, len));
  s.data_ptr = INTEGER((SEXP)s.sexp_ptr);
  s.len = len;
  return s;
}

double callRFunction_logIntegratedLikelihoodItem(const void* fn_ptr, int i, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP s, t;
  t = s = PROTECT(Rf_allocList(3));
  SET_TYPEOF(s, LANGSXP);
  SETCAR(t, *(SEXP*)fn_ptr); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(i)); t = CDR(t);
  SETCAR(t, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(s, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

double callRFunction_logIntegratedLikelihoodSubset(const void* fn_ptr, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP R_fcall = PROTECT(Rf_lang2(*(SEXP*)fn_ptr, R_NilValue));
  SETCADR(R_fcall, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(R_fcall, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

double callRFunction_logLikelihoodItem(const void* fn_ptr, int i, int label, int is_new, const void* env_ptr) {
  SEXP s, t;
  t = s = PROTECT(Rf_allocList(4));
  SET_TYPEOF(s, LANGSXP);
  SETCAR(t, *(SEXP*)fn_ptr); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(i)); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(label)); t = CDR(t);
  SETCAR(t, Rf_ScalarLogical(is_new)); t = CDR(t);
  double ans = Rf_asReal(Rf_eval(s, *(SEXP*)env_ptr));
  UNPROTECT(1);
  return ans;
}

SEXP new_FixedPartitionParameters(SEXP partition_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  FixedPartitionParameters *ptr = dahl_randompartition__fixedpartitionparameters_new(n_items, partition);
  UNPROTECT(1);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_FixedPartitionParameters(SEXP ptr_sexp) {
  FixedPartitionParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__fixedpartitionparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_CRPParameters(SEXP n_items_sexp, SEXP mass_sexp, SEXP discount_sexp) {
  int n_items = Rf_asInteger(n_items_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  CRPParameters *ptr = dahl_randompartition__crpparameters_new(n_items, mass, discount);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_CRPParameters(SEXP ptr_sexp) {
  CRPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__crpparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_FRPParameters(SEXP partition_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP use_natural_permutation_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP power_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  weights_sexp = PROTECT(Rf_coerceVector(weights_sexp, REALSXP));
  double* weights = REAL(weights_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  int use_natural_permutation = Rf_asLogical(use_natural_permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  double power = Rf_asReal(power_sexp);
  FRPParameters *ptr = dahl_randompartition__frpparameters_new(n_items, partition, weights, permutation, use_natural_permutation, mass, discount, power);
  UNPROTECT(3);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_FRPParameters(SEXP ptr_sexp) {
  FRPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__frpparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_LSPParameters(SEXP partition_sexp, SEXP rate_sexp, SEXP permutation_sexp, SEXP use_natural_permutation_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  double rate = Rf_asReal(rate_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  int use_natural_permutation = Rf_asLogical(use_natural_permutation_sexp);
  LSPParameters *ptr = dahl_randompartition__lspparameters_new(n_items, partition, rate, permutation, use_natural_permutation);
  UNPROTECT(2);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_LSPParameters(SEXP ptr_sexp) {
  LSPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__lspparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_CPPParameters(SEXP partition_sexp, SEXP rate_sexp, SEXP uniform_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP use_vi_sexp, SEXP a_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  double rate = Rf_asReal(rate_sexp);
  int uniform = Rf_asLogical(uniform_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  int use_vi = Rf_asLogical(use_vi_sexp);
  double a = Rf_asReal(a_sexp);
  CPPParameters *ptr = dahl_randompartition__cppparameters_new(n_items, partition, rate, uniform, mass, discount, use_vi, a);
  UNPROTECT(1);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_CPPParameters(SEXP ptr_sexp) {
  CPPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__cppparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_EPAParameters(SEXP similarity_sexp, SEXP permutation_sexp, SEXP use_natural_permutation_sexp, SEXP mass_sexp, SEXP discount_sexp) {
  int n_items = Rf_nrows(similarity_sexp);
  similarity_sexp = PROTECT(Rf_coerceVector(similarity_sexp, REALSXP));
  double* similarity = REAL(similarity_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  int use_natural_permutation = Rf_asLogical(use_natural_permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  EPAParameters *ptr = dahl_randompartition__epaparameters_new(n_items, similarity, permutation, use_natural_permutation, mass, discount);
  UNPROTECT(2);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_EPAParameters(SEXP ptr_sexp) {
  EPAParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__epaparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_TRPParameters(SEXP partition_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP use_natural_permutation_sexp, SEXP baseline_distribution_id_sexp, SEXP baseline_distribution_ptr_sexp, SEXP loss_sexp, SEXP a_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  weights_sexp = PROTECT(Rf_coerceVector(weights_sexp, REALSXP));
  double* weights = REAL(weights_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  int use_natural_permutation = Rf_asLogical(use_natural_permutation_sexp);
  int baseline_distribution_id = Rf_asInteger(baseline_distribution_id_sexp);
  void *baseline_distribution_ptr = R_ExternalPtrAddr(baseline_distribution_ptr_sexp);
  int loss = Rf_asInteger(loss_sexp);
  double a = Rf_asReal(a_sexp);
  TRPParameters *ptr = dahl_randompartition__trpparameters_new(n_items, partition, weights, permutation, use_natural_permutation, baseline_distribution_id, baseline_distribution_ptr, loss, a);
  UNPROTECT(3);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_TRPParameters(SEXP ptr_sexp) {
  TRPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__trpparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP nealAlgorithm(SEXP partition_sexp, SEXP callback_sexp, SEXP is_algorithm3_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP prior_id_sexp, SEXP prior_ptr_sexp) {
  int prior_only = Rf_isNull(callback_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(callback_sexp)) Rf_error("Expecting a function.");
  }
  void* callback_ptr = &callback_sexp;
  int is_algorithm3 = Rf_asLogical(is_algorithm3_sexp);
  RR_SEXP map = null_rr_sexp();
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int prior_id = Rf_asInteger(prior_id_sexp);
  void *prior_ptr = R_ExternalPtrAddr(prior_ptr_sexp);
  if ( is_algorithm3 != 0 ) {
    dahl_randompartition__neal_algorithm3(n_updates_for_partition, n_items, partition, prior_only, callback_ptr, env_ptr, seed, prior_id, prior_ptr);
  } else {
    dahl_randompartition__neal_algorithm8(n_updates_for_partition, n_items, partition, prior_only, callback_ptr, env_ptr, seed, prior_id, prior_ptr, &map);
  }
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  if ( is_algorithm3 == 0 ) {
    SET_VECTOR_ELT(results_sexp, 1, (SEXP)map.sexp_ptr);
  }
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("map"));
  Rf_namesgets(results_sexp, names_sexp);
  if ( is_algorithm3 != 0 ) {
    UNPROTECT(3);
  } else {
    UNPROTECT(4);
  }
  return results_sexp;
}

SEXP samplePartition(SEXP n_samples_sexp, SEXP n_items_sexp, SEXP seed_sexp, SEXP prior_id_sexp, SEXP prior_ptr_sexp, SEXP randomize_permutation_sexp) {
  int n_samples = Rf_asInteger(n_samples_sexp);
  int n_items = Rf_asInteger(n_items_sexp);
  SEXP partition_labels_sexp = PROTECT(Rf_allocMatrix(INTSXP, n_samples, n_items));
  int *partition_labels = INTEGER(partition_labels_sexp);
  int *seed = INTEGER(seed_sexp);
  int prior_id = Rf_asInteger(prior_id_sexp);
  void *prior_ptr = R_ExternalPtrAddr(prior_ptr_sexp);
  int randomize_permutation = Rf_asLogical(randomize_permutation_sexp);
  dahl_randompartition__sample_partition(n_samples, n_items, partition_labels, seed, prior_id, prior_ptr, randomize_permutation);
  UNPROTECT(1);
  return partition_labels_sexp;
}

SEXP prPartition(SEXP partition_sexp, SEXP prior_id_sexp, SEXP prior_ptr_sexp) {
  int n_samples = Rf_nrows(partition_sexp);
  int n_items = Rf_ncols(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  SEXP log_probability_sexp = PROTECT(Rf_allocVector(REALSXP, n_samples));
  double *log_probability = REAL(log_probability_sexp);
  int* partition = INTEGER(partition_sexp);
  int prior_id = Rf_asInteger(prior_id_sexp);
  void *prior_ptr = R_ExternalPtrAddr(prior_ptr_sexp);
  dahl_randompartition__log_probability_of_partition(n_samples, n_items, partition, log_probability, prior_id, prior_ptr);
  UNPROTECT(2);
  return log_probability_sexp;
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
  {".new_FixedPartitionParameters", (DL_FUNC) &new_FixedPartitionParameters, 1},
  {".free_FixedPartitionParameters", (DL_FUNC) &free_FixedPartitionParameters, 1},
  {".new_CRPParameters", (DL_FUNC) &new_CRPParameters, 3},
  {".free_CRPParameters", (DL_FUNC) &free_CRPParameters, 1},
  {".new_FRPParameters", (DL_FUNC) &new_FRPParameters, 7},
  {".free_FRPParameters", (DL_FUNC) &free_FRPParameters, 1},
  {".new_LSPParameters", (DL_FUNC) &new_LSPParameters, 4},
  {".free_LSPParameters", (DL_FUNC) &free_LSPParameters, 1},
  {".new_CPPParameters", (DL_FUNC) &new_CPPParameters, 7},
  {".free_CPPParameters", (DL_FUNC) &free_CPPParameters, 1},
  {".new_EPAParameters", (DL_FUNC) &new_EPAParameters, 5},
  {".free_EPAParameters", (DL_FUNC) &free_EPAParameters, 1},
  {".new_TRPParameters", (DL_FUNC) &new_TRPParameters, 8},
  {".free_TRPParameters", (DL_FUNC) &free_TRPParameters, 1},
  {".nealAlgorithm", (DL_FUNC) &nealAlgorithm, 8},
  {".samplePartition", (DL_FUNC) &samplePartition, 6},
  {".prPartition", (DL_FUNC) &prPartition, 3},
  {NULL, NULL, 0}
};

void R_init_pumpkin(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
