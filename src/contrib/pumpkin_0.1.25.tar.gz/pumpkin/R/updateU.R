# # As suggested by Favaro and Teh (2013), this uses a Gaussian random walk for the log(U) with a proposal variance of 1/4.
# updateU <- function(partitionPrior, partition, nUpdates=1) {  # This could be implemented in a low-level language for the sake of speed.
#   m <- partitionPrior$mass
#   r <- partitionPrior$reinforcement
#   ni <- length(partition)
#   ns <- length(unique(partition))
#   logFullConditionalOfV <- function(v) {  # See last equation on pg. 343 of Favaro and Teh (2013)
#     uPlus1 <- exp(v) + 1
#     v*ni - (ni - r*ns) * log(uPlus1) - (m/r)*(uPlus1^r - 1)
#   }
#   current <- log(partitionPrior$u)
#   fCurrent <- logFullConditionalOfV(current)
#   for ( i in 1:nUpdates ) {
#     proposal <- rnorm(1, current, sd=sqrt(1/4))
#     fProposal <- logFullConditionalOfV(proposal)
#     if ( log(runif(1)) < fProposal - fCurrent ) {
#       current <- proposal
#       fCurrent <- fProposal
#     }
#   }
#   partitionPrior$u <- exp(current)
#   partitionPrior
# }
