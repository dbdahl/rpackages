#' Update the Mass Parameter of a Partition Distribution
#'
#' This function updates the mass parameter of a partition distribution (e.g,
#' \code{\link{FocalPartition}} and \code{\link{TiltedPartition}}) using a
#' Gaussian random walk.  The prior can be specified by the user.
#'
#' @inheritParams updateWeights
#'
#' @return A list containing the potentially updated partition distribution and
#'   a logical named \code{accepted} (indicating whether the proposal was
#'   accepted).
#'
#' @seealso \code{\link{nealAlgorithm3}}, \code{\link{nealAlgorithm8}}
#'
#' @example man/examples/nealAlgorithm3.R
#'
#' @importFrom stats dunif runif rnorm
#' @export
#'
updateMass <- function(distr, partition, rwsd=0.5,
                       logPriorDensity=function(w) dunif(w, 0, 15, log=TRUE)) {
  UseMethod("updateMass")
}

#' @export
#'
updateMass.default <- function(distr, partition, rwsd=0.5,
                       logPriorDensity=function(w) dunif(w, 0, 15, log=TRUE)) {
  if ( is.null(distr[['mass']]) || rwsd <= 0 || inherits(distr,"CenteredPartition") ) {
    return(list(distr=distr, accepted=FALSE))
  }
  proposalDistr <- distr
  oldM <- distr[['mass']]
  newM <- rnorm(1, mean=oldM, sd=rwsd)
  if ( newM < 0.0 ) return(list(distr=distr, accepted=FALSE))
  proposalDistr$mass <- newM
  logMHRatio <- prPartition(proposalDistr, partition, log=TRUE) + logPriorDensity(newM) - prPartition(distr, partition, log=TRUE) - logPriorDensity(oldM)
  if ( log(runif(1)) < logMHRatio ) list(distr=proposalDistr, accepted=TRUE)
  else list(distr=distr, accepted=FALSE)
}

#' @export
#'
updateMass.TiltedPartition <- function(distr, partition, rwsd=0.5,
                                       logPriorDensity=function(w) dunif(w, 0, 15, log=TRUE)) {
  if ( is.null(distr$baselineDistribution[['mass']]) || rwsd <= 0 || inherits(distr$baselineDistribution,"CenteredPartition") ) {
    return(list(distr=distr, accepted=FALSE))
  }
  proposalDistr <- distr
  oldM <- distr$baselineDistribution[['mass']]
  newM <- rnorm(1, mean=oldM, sd=rwsd)
  if ( newM < 0.0 ) return(list(distr=distr, accepted=FALSE))
  proposalDistr$baselineDistribution$mass <- newM
  logMHRatio <- prPartition(proposalDistr, partition, log=TRUE) + logPriorDensity(newM) - prPartition(distr, partition, log=TRUE) - logPriorDensity(oldM)
  if ( log(runif(1)) < logMHRatio ) list(distr=proposalDistr, accepted=TRUE)
  else list(distr=distr, accepted=FALSE)
}
