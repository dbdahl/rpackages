#' Probabilities for the Ewens-Pitman Attaction (EPA) Partition Distribution
#'
#' This function specifies the Ewens-Pitman attraction partition distribution
#' for given similarity matrix, permutation, mass (a.k.a., concentration), and
#' discount parameters.
#'
#' @inheritParams FocalPartition
#' @param similarity An n-by-n symmetric matrix giving the similarity between
#'   pairs of items.  Matrix entries must be strictly positive.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/EPAPartition.R
#' @export
#'
EPAPartition <- function(similarity, permutation, mass, discount=0) {
  checkSimilarity(similarity)
  nItems <- nrow(similarity)
  if ( nItems < 1 ) stop("The number of rows in 'similarity' must be at least one.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the number of rows in 'similarity'.")
  checkMassDiscount(mass, discount)
  result <- list(nItems=nItems, similarity=similarity, permutation=permutation-1L, mass=mass, discount=discount)
  class(result) <- c("EPAPartition", "partitionDistribution")
  result
}

#' @export
print.EPAPartition <- function(x, ...) {
  cat("\nEPA partition distribution\n\n")
  z <- unclass(x)
  z$permutation <- z$permutation + 1L
  print(z)
}
