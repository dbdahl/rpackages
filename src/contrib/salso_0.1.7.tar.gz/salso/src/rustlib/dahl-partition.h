#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

void dahl_partition__enumerated(int32_t n_partitions, int32_t n_items, int32_t *partitions_ptr);
