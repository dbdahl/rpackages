# Neal (2000) model and data

data <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
sigma2 <- 0.1^2
mu0 <- 0
sigma02 <- 1

logLikelihoodOfItem <- function(i, parameter) {
  dnorm(data[i], mean=parameter, sd=sqrt(sigma2), log=TRUE)
}

sampleParameter <- function() {
  rnorm(1, mean=mu0, sd=sqrt(sigma02))
}

updateParameter <- function(parameter, subset) {
  posteriorVariance <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
  posteriorMean     <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
  rnorm(1, mean=posteriorMean, sd=sqrt(posteriorVariance))
}

# Prior partition distribution.  Many are supported.

mass <- 1.5
discount <- 0.2
baselinePartition <- c(1,1,2,2,2,3,4,4,4)
permutation <- sample(length(baselinePartition))

subset <- c("Maine","Georgia","California","Minnesota","Oregon","Utah","Wisconsin","Texas","Nevada")
d <- as.matrix(dist(scale(USArrests[subset,])))
temperature <- 1.0
similarity <- exp( -temperature * d )
distr <- EPAPartition(similarity, permutation, mass, discount)

distr <- CRPPartition(length(data), mass, discount)
distr <- LocationScalePartition(baselinePartition, 3, permutation)
distr <- CenteredPartition(baselinePartition, weight=3, mass, discount)
distr <- FocalPartition(baselinePartition, weights=c(3,3,1,1,1,0,5,5,0), permutation, mass,discount)
distr <- TiltedPartition(baselinePartition, weights=c(3,3,1,1,1,0,5,5,0), permutation,
                         baselineDistribution=CRPPartition(length(data), mass, discount))

# MCMC

mcmcTuning <- list(nUpdates=2)
nSamples <- 100L
partitionSamples <- matrix(1, nrow=nSamples, ncol=length(data))
parametersSamples <- list(list(sampleParameter()))
relativeTo <- 1
weightsSamples <- rep(distr$weights[relativeTo], nSamples)
massSamples <- rep(distr$mass, nSamples)
nAcceptancesPermutation <- nAcceptancesWeights <- nAcceptancesMass <- 0L
getOr <- function(x, or) if ( is.null(x) ) or else x

for ( i in 2:nSamples ) {
  # Update partition
  out <- nealAlgorithm8(partitionSamples[i-1,], parametersSamples[[i-1]], distr,
                        logLikelihoodOfItem, sampleParameter, updateParameter, mcmcTuning)
  partitionSamples[i,] <- out$partition
  parametersSamples[[i]] <- out$parameters
  # Update permutation
  out <- updatePermutation(distr, partitionSamples[i,], k=length(data)/2)
  distr <- out$distr
  nAcceptancesPermutation <- nAcceptancesPermutation + out$accepted
  # Update weights
  out <- updateWeights(distr, partitionSamples[i,], rwsd=1, relativeTo=1)
  distr <- out$distr
  nAcceptancesWeights <- nAcceptancesWeights + out$accepted
  weightsSamples[i] <- getOr(distr$weights[relativeTo],0)
  # Update mass
  out <- updateMass(distr, partitionSamples[i,], rwsd=2)
  distr <- out$distr
  nAcceptancesMass <- nAcceptancesMass + out$accepted
  massSamples[i] <- if ( inherits(distr,"TiltedPartition") ) {
    getOr(distr$baselineDistribution$mass,0)
  } else {
    getOr(distr$mass,0)
  }
  # Perhaps add code to update other parameters, e.g., discount, etc.
}

# Acceptance rate for updates
nAcceptancesPermutation / (nSamples-1)
nAcceptancesWeights / (nSamples-1)
nAcceptancesMass / (nSamples-1)

nSubsets <- apply(partitionSamples, 1, function(x) length(unique(x)))
plot(nSubsets, type="l")
mean(nSubsets)
sum(acf(nSubsets)$acf)-1   # Autocorrelation time

plot(weightsSamples, type="l", main = "Trace Plot of Weights")
plot(massSamples, type="l", main = "Trace Plot of Mass")

