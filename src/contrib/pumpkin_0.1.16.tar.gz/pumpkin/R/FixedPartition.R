#' Probabilities for the Fixed Partition Distribution
#'
#' This function evaluates the probability mass function of the fixed partition
#' distribution for given baseline partition.  This is a point-mass distribution
#' at the baseline partition.
#'
#' @inheritParams FocalPartition
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/FixedPartition.R
#' @export
#'
FixedPartition <- function(baselinePartition) {
  nItems <- length(baselinePartition)
  if ( nItems < 1 ) stop("The number of items in 'baselinePartition' must be at least one.")
  result <- list(nItems=nItems, baselinePartition=baselinePartition)
  class(result) <- c("FixedPartition", "partitionDistribution")
  result
}

#' @export
print.FixedPartition <- function(x, ...) {
  cat("\nFixed partition distribution\n\n")
  print(unclass(x))
}
