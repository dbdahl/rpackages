partition <- c(1,1,2,2,3)
center <- c(1,1,1,2,2)
weight <- 3
mass <- 1.0
discount <- 0.1

dCenteredPartition(partition, center, weight, mass, discount)

partitions <- salso::enumeweight.partitions(length(center))
weights <- dCenteredPartition(partitions, center, weight, mass, discount)
probs <- weights/sum(weights)
cbind(partitions, prob=round(probs, 5))

