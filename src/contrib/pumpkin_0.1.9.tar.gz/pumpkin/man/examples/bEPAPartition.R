partition <- c(0,0,1,1,2)
n <- length(partition)
subset <- c("Maine","Georgia","California","Minnesota","Montana")
d <- as.matrix(dist(USArrests[subset,]))
temperature <- 1.0
similarity <- exp( -temperature * d )
permutation <- 1:n
mass <- 1.0
discount <- 0.1

x <- rEPAPartition(100, similarity, permutation, mass, discount, useRandomPermutation=FALSE)
p <- dEPAPartition(x$partition, similarity, permutation, mass, discount, log=TRUE)
all.equal(p, x$logProbability)

psm <- salso::psm(x$partition)
upper <- upper.tri(psm)
plot(psm[upper], d[upper])

