# Neal (2000) model and data

data <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
sigma2 <- 0.1^2
mu0 <- 0
sigma02 <- 1

logIntegratedLikelihoodItem <- function(i, subset) {
  posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
  posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
  posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
  dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
}


# Prior partition distribution

partitionPrior <- dCRPPartition(mass=1.5, discount=0.2)

target <- c(1,1,1,1,1,2,2,2,2)

partitionPrior <- dLocationScalePartition(
    target=target, weight=1/0.5, permutation=seq_along(data))

partitionPrior <- dCenteredPartition(
    target=target, weight=2, mass=1.0)

partitionPrior <- dFocalPartition(
    target=target, weights=2, permutation=seq_along(data), mass=1.0, discount=0.1)

# MCMC

mcmcTuning <- list(nUpdates=2)
nSamples <- 1000L
nAccepts <- nAttempts <- 0L
partitions <- matrix(1, nrow=nSamples, ncol=length(data))
for ( i in 2:nSamples ) {
  # Update partition
  partitions[i,] <- nealAlgorithm3(partitions[i-1,], logIntegratedLikelihoodItem,
                                   partitionPrior, mcmcTuning)$partition
  # Update permutation
  if ( ! is.null(partitionPrior$permutation) ) {
    proposal <- sample(partitionPrior$permutation)
    logMHRatio <- 0.0
    logMHRatio <- logMHRatio + dFocalPartition(partitions[i,], target=target, weights=2,
        permutation=proposal, mass=1.0)
    logMHRatio <- logMHRatio - dFocalPartition(partitions[i,], target=target, weights=2,
        permutation=partitionPrior$permutation, mass=1.0)
    if ( log(runif(1)) < logMHRatio ) partitionPrior$permutation <- proposal
  }
  # Perhaps add code to update other parameters, e.g., mass, discount, etc.
}

nSubsets <- apply(partitions, 1, function(x) length(unique(x)))
mean(nSubsets)
sum(acf(nSubsets)$acf)-1   # Autocorrelation time

#
# # Covariate-based partition distribution
#
# partition <- c(0,0,1,1,2)
# subset <- c("Maine","Georgia","California","Minnesota","Montana")
# d <- as.matrix(dist(USArrests[subset,]))
# temperature <- 1.0
# similarity <- exp( -temperature * d )
# mass <- 1.0
# discount <- 0.1
#
# partitionPrior <- dEPAPartition(similarity=similarity, permutation=1:5,
#     mass=mass, discount=discount)
#
# mcmcTuning <- list(nUpdates=2)
# nSamples <- 1000L
# nAccepts <- nAttempts <- 0L
# partitions <- matrix(1, nrow=nSamples, ncol=ncol(similarity))
# for ( i in 2:nSamples ) {
#   # Update partition
#   partitions[i,] <- nealAlgorithm3(partitions[i-1,], logIntegratedLikelihoodItem,
#                                    partitionPrior, mcmcTuning)$partition
#   # Update permutation
#   if ( ! is.null(partitionPrior$permutation) ) {
#     proposal <- sample(partitionPrior$permutation)
#     logMHRatio <- 0.0
#     logMHRatio <- logMHRatio + dEPAPartition(partitions[i,], similarity=similarity, mass=1.0,
#         permutation=proposal)
#     logMHRatio <- logMHRatio - dEPAPartition(partitions[i,], similarity=similarity, mass=1.0,
#         permutation=partitionPrior$permutation)
#     if ( log(runif(1)) < logMHRatio ) partitionPrior$permutation <- proposal
#   }
#   # Perhaps add code to update other parameters, e.g., mass, discount, etc.
# }
#
# salso::psm(partitions)
# d
#
