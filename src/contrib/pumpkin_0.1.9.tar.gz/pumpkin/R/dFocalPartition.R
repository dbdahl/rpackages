#' Probabilities for the Focal Partition Distribution
#'
#' This function evaluates the probability mass function of the focal partition
#' distribution for given target partition, weights, permutation, mass (a.k.a.,
#' concentration), and discount parameters.
#'
#' @inheritParams dCRPPartition
#' @param target An integer vector giving the target partition (e.g., focal
#'   partition, center partition, location partition).
#' @param weights A numeric vector of length equal to the length of
#'   \code{target} (i.e., the number of items) giving the weight for each item.
#' @param permutation An vector of integers containing the integers 1, 2, ..., n
#'   giving the order in which items are allocated to the partition.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/bFocalPartition.R
#' @useDynLib pumpkin .bFocalPartition
#' @export
#'
dFocalPartition <- function(partition, target, weights, permutation, mass, discount=0, log=FALSE) {
  weights <- checkArgumentsFocalPartition(target, weights, permutation, mass, discount)
  if ( missing(partition) ) {
    result <- list(name="Focal", target=target, weights=weights, permutation=permutation, mass=mass, discount=discount,
                   logProbability=function(partition) dFocalPartitionEngine(partition, target, weights, permutation, mass, discount, log=TRUE))
    class(result) <- "partitionDistribution"
    result
  } else {
    dFocalPartitionEngine(partition, target, weights, permutation, mass, discount, log)
  }
}

dFocalPartitionEngine <- function(partition, target, weights, permutation, mass, discount, log) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != length(target) ) stop("Length of 'partition' must equal the length of 'target'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bFocalPartition, FALSE, partition, numeric(nSamples), 0L, target, weights, permutation - 1L, mass, discount, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Focal Partition Distribution
#'
#' This function returns randomly sampled partitions from the focal partition
#' distribution for given target partition, weights, permutation, and mass
#' (a.k.a., concentration) parameters.
#'
#' @inheritParams dFocalPartition
#' @param nSamples An integer giving the number of partitions to sample.
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @example man/examples/bFocalPartition.R
#' @concept useDynLib pumpkin .bFocalPartition
#' @export
#'
rFocalPartition <- function(nSamples, target, weights, permutation, mass, discount=0, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  weights <- checkArgumentsFocalPartition(target, weights, permutation, mass, discount)
  partitions <- matrix(0L, nrow=nSamples, ncol=length(target))
  .Call(.bFocalPartition, TRUE, partitions, numeric(nSamples), seed4rust(), target, weights, permutation - 1L, mass, discount, useRandomPermutation)
}

checkArgumentsFocalPartition <- function(target, weights, permutation, mass, discount) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nItems)
  else  if ( length(weights) != nItems ) stop("The length of 'weights' must be equal to the number of items in 'target'.")
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'target'.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  weights
}
