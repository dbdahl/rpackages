#' Probabilities for the Location Scale Distribution
#'
#' This function evaluates the probability mass function of the location scale
#' partition distribution for given target partition, weight, and permutation
#' parameters.  The weight parameter is the reciprocal of the scale parameter.
#'
#' @inheritParams dFocalPartition
#' @param weight A numeric value giving the weight, i.e., the reciprocal of the
#'   scale.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/bLocationScalePartition.R
#' @useDynLib pumpkin .bLocationScalePartition
#' @export
#'
dLocationScalePartition <- function(partition, target, weight, permutation, log=FALSE) {
  checkArgumentsLocationScalePartition(target, weight, permutation)
  if ( missing(partition) ) {
    result <- list(name="LocationScale", target=target, weight=weight, permutation=permutation,
                   logProbability=function(partition) dLocationScalePartitionEngine(partition, target, weight, permutation, log=TRUE))
    class(result) <- "partitionDistribution"
    result
  } else {
    dLocationScalePartitionEngine(partition, target, weight, permutation, log)
  }
}

dLocationScalePartitionEngine <- function(partition, target, weight, permutation, log) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != length(target) ) stop("Length of 'partition' must equal the length of 'target'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bLocationScalePartition, FALSE, partition, numeric(nSamples), 0L, target, weight, permutation - 1L, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Location Scale Partition Distribution
#'
#' This function returns randomly sampled partitions from the location partition
#' distribution for given target partition, weight, and permutation.  The weight
#' parameter is the reciprocal of the scale parameter.
#'
#' @inheritParams dLocationScalePartition
#' @param nSamples An integer giving the number of partitions to sample.
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @example man/examples/bLocationScalePartition.R
#' @useDynLib pumpkin .bLocationScalePartition
#' @export
#'
rLocationScalePartition <- function(nSamples, target, weight, permutation, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  checkArgumentsLocationScalePartition(target, weight, permutation)
  partitions <- matrix(0L, nrow=nSamples, ncol=length(target))
  .Call(.bLocationScalePartition, TRUE, partitions, numeric(nSamples), seed4rust(), target, weight, permutation - 1L, useRandomPermutation)
}

checkArgumentsLocationScalePartition <- function(target, weight, permutation) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  if ( length(weight) != 1 ) stop("'weight' must be a scalar.")
  if ( weight < 0.0 ) stop("'weight' must be nonnegative.")
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'target'.")
  invisible(NULL)
}
