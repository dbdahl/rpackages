#' Neal's Algorithm 8 for a Partition
#'
#' This function performs Algorithm 8 of Neal (2000), which updates a partition
#' based on a partition prior distribution and user-supplied functions to
#' evaluate an item's contribution to the loglikelihood sample a model parameter
#' for its prior distribution, and update a model parameter based on a subset.
#'
#' @inheritParams nealAlgorithm3
#' @param parameters A list whose \eqn{j}th element is the shared model
#'   parameter for all those items having cluster label \eqn{j} in the
#'   \code{partition} argument.
#' @param logLikelihood A function taking an index \eqn{i} (as a single
#'   integer), a cluster label \eqn{label} (as a single integer), and an
#'   indication as to whether a new parameter should be sampled (as an single
#'   logical) and returning the natural logarithm of \eqn{p( y_i | 'parameter
#'   associated with "label"' )}, i.e., that item's contribution to the log
#'   likelihood given the parameter associated the cluster with label "label".
#' @param sampleParameter A function taking no arguments and returning a draw
#'   from the prior parameter distribution (i.e., the centering distribution).
#' @param updateParameter A function taking a \code{parameter} (a current value
#'   of a parameter) and a subset of integers \code{subset} (as a numeric
#'   vector) and returning an updated value for the parameter by some valid MCMC
#'   update scheme for the full conditional distribution of the parameter.
#'
#' @return A list containing \code{partition} (an integer vector giving the
#'   updated partition encoded using cluster labels), \code{parameters} (a list
#'   like the \code{parameters} argument, with updated values), and possibly
#'   other items specific to a particular prior.
#'
#' @export
#' @example man/examples/nealAlgorithm8.R
#' @useDynLib pumpkin .nealAlgorithm
#' @useDynLib pumpkin .new_CRPParameters .free_CRPParameters
#' @useDynLib pumpkin .new_FRPParameters .free_FRPParameters
#' @useDynLib pumpkin .new_LSPParameters .free_LSPParameters
#' @useDynLib pumpkin .new_CPPParameters .free_CPPParameters
#'
nealAlgorithm8 <- function(partition, parameters, logLikelihood=function(i, parameter) 0, sampleParameter=function() 0, updateParameter=function(parameter, subset) 0, priorDistribution=dCRPPartition(mass=1), mcmcTuning=list()) {
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  nUpdatesForPartition <- getOr(mcmcTuning$nUpdatesForPartition, 1)
  pd <- priorDistribution
  logLike <- function(i, label, isNew) {
    if ( isNew ) parameters[[label]] <<- sampleParameter()
    logLikelihood(i, parameters[[label]])
  }
  result <- if ( priorDistribution$name == "CRP" ) {
    p <- .Call(.new_CRPParameters, pd$mass, pd$discount)
    result <- .Call(.nealAlgorithm, partition, logLike, FALSE, environment(), nUpdatesForPartition, seed4rust(), 0, p)
    .Call(.free_CRPParameters,p)
    result
  } else if ( priorDistribution$name == "Focal" ) {
    p <- .Call(.new_FRPParameters, pd$target, pd$weights, pd$permutation,TRUE, pd$mass, pd$discount)
    result <- .Call(.nealAlgorithm, partition, logLike, FALSE, environment(), nUpdatesForPartition, seed4rust(), 1, p)
    .Call(.free_FRPParameters,p)
    result
  } else if ( priorDistribution$name == "LocationScale" ) {
    p <- .Call(.new_LSPParameters, pd$target, pd$weight, pd$permutation, TRUE)
    result <- .Call(.nealAlgorithm, partition, logLike, FALSE, environment(), nUpdatesForPartition, seed4rust(), 2, p)
    .Call(.free_LSPParameters,p)
    result
  } else if ( priorDistribution$name == "Centered" ) {
    p <- .Call(.new_CPPParameters, pd$target, pd$weight, pd$mass, pd$discount, pd$useVI, pd$a)
    result <- .Call(.nealAlgorithm, partition, logLike, FALSE, environment(), nUpdatesForPartition, seed4rust(), 3, p)
    .Call(.free_CPPParameters,p)
    result
  } else stop(sprintf("'%s' is not supported.",priorDistribution$name))
  # Standardize the order of the parameters
  parameters <- parameters[result$map]
  # Update parameters
  sapply(unique(result$partition), function(label) {
    subset <- which(result$partition==label)
    parameters[[label]] <<- if ( length(subset) == 0 ) NA
    else updateParameter(parameters[[label]], subset)
  })
  list(partition=result$partition, parameters=parameters)
}
