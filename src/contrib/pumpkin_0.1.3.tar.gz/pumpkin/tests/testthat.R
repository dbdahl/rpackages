library(testthat)
library(pumpkin)
library(salso)

test_check("pumpkin")
