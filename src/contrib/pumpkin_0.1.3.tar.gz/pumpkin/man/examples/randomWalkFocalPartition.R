# Neal (2000) model and data
nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
mkLogIntegratedLikelihoodOfItem <- function(data=nealData, sigma2=0.1^2, mu0=0, sigma02=1) {
  function(i, subset) {
    posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
    posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
    posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
    dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
  }
}

mkLogIntegratedLikelihoodOfSubset <- function(f) {
  function(subset) sum(sapply(seq_along(subset), function(j) f(subset[j], subset[seq_len(j-1)])))
}

logLike <- mkLogIntegratedLikelihoodOfSubset(mkLogIntegratedLikelihoodOfItem())
partitionPrior <- dFocalPartition(focal=rep(0,length(nealData)), weights=0, mass=1, discount=0,
                                  permutation=seq_along(nealData))
partitionPrior <- dCRPPartition(mass=1)

nSamples <- 1000L
nAccepts <- nAttempts <- 0L
partitions <- matrix(1, nrow=nSamples, ncol=length(nealData))
for ( i in 2:nSamples ) {
  x <- randomWalkFocalPartition(partitions[i-1,], 20, 1, 0, logLike, partitionPrior, nAttempts=2)
  partitions[i,] <- x$partition
  nAccepts  <- nAccepts  + x$nAccepts
  nAttempts <- nAttempts + x$nAttempts
}

nSubsets <- apply(partitions, 1, function(x) length(unique(x)))
mean(nSubsets)
nAccepts/nAttempts         # Acceptance rate
sum(acf(nSubsets)$acf)-1   # Autocorrelation time

