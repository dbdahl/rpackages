#' Random Walk Update for a Partition
#'
#' This function performs a random walk update for a partition using the focal
#' partition distribution for proposals.  The current partition serves as the
#' focal partition and \code{rate} providing a tuning parameter (analogous to a
#' precision parameter for a Gaussian random walk for a real-valued parameter.)
#'
#' @param partition A numeric vector of cluster labels representing the current
#'   partition.
#' @param rate A scalar providing the tuning parameter for the random walk
#'   proposals.  This value is analogous to a precision parameter for a Gaussian
#'   random walk for a real-valued parameter.
#' @param mass A scalar providing the tuning parameter for the random walk
#'   proposals.  This value is a mass parameter for the focal random partition
#'   distribution proposal and must be greater than the negative of the \code{discount} argument.
#' @param discount A scalar providing the tuning parameter for the random walk
#'   proposals.  This value is a discount parameter for the focal random partition
#'   distribution proposal and must be a numeric value in [0,1).
#' @param logLikelihoodOfSubset A function taking a subset of integers (as a
#'   numeric vector) and returning the natural logarithm of that subset's
#'   contribution to the integrated likelihood.  The default value "turns off"
#'   the likelihood, resulting in prior simulation (rather than posterior
#'   simulation).
#' @param priorDistribution A specification of the prior partition distribution,
#'   as returned by a function such as \code{\link{dCRPPartition}}.
#' @param nAttempts An integer giving the number of MCMC updates attempted
#'   before returning.  This has the effect of thinning the Markov chain.
#'
#' @return A list of the following elements: \describe{ \item{partition}{An
#'   integer vector giving the updated partition encoded using cluster labels.}
#'   \item{nAccepts}{The number of proposals that were accepted.}
#'   \item{nAttempts}{The number of proposals that were attempted.} }
#'
#' @example man/examples/randomWalkFocalPartition.R
#' @useDynLib pumpkin .randomWalkFocalPartition_CRP
#'   .randomWalkFocalPartition_FRP
#' @export
#'
randomWalkFocalPartition <- function(partition, rate=1, mass=1, discount=0, logLikelihoodOfSubset=function(subset) 0, priorDistribution=dCRPPartition(mass=1), nAttempts=1) {
  if ( rate <  0.0) stop("'rate' must be nonnegative.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be strictly positive.")
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  if ( is.list(partition) ) partition <- partition$partition
  if ( priorDistribution$name == "CRP" ) {
    .Call(.randomWalkFocalPartition_CRP, partition, rate, mass, discount, logLikelihoodOfSubset, environment(), nAttempts, seed4rust(), priorDistribution$mass, priorDistribution$discount)
  } else if ( priorDistribution$name == "Focal" ) {
    pd <- priorDistribution
    .Call(.randomWalkFocalPartition_FRP, partition, rate, mass, discount, logLikelihoodOfSubset, environment(), nAttempts, seed4rust(), pd$focal, pd$weights, pd$permutation-1L, pd$mass, pd$discount)
  } else stop(sprintf("'%s' is not supported.",priorDistribution$name))
}
