CRPPartition(nItems=5, mass=1.5, discount=0.1)
