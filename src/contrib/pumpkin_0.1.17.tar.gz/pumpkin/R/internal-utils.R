getOr <- function(x, or) {
  if ( is.null(x) ) or else x
}

seed4rust <- function() sapply(1:32, function(i) sample.int(256L,1L)-1L)

checkSimilarity <- function(similarity) {
  if ( ! is.matrix(similarity) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
  if ( ! isSymmetric(similarity) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
  if ( any( similarity <= 0 ) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
}

checkPermutation <- function(permutation) {
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  if ( ! is.vector(permutation) ) stop("'permutation' must a vector.")
  if ( ! all(permutation %% 1 == 0) ) stop("'permutation' must only contain integers.")
  n <- length(permutation)
  if ( ( min(permutation) < 1 ) || ( max(permutation) > n ) || ( length(unique(permutation)) != n ) ) stop("'permutation' is not a valid permutation.")
}

checkMassDiscount <- function(mass, discount) {
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
}

isCanonical <- function(labels) isCanonicalFromUnique(unique(labels))

isCanonicalFromUnique <- function(u) {
  if ( min(u) != 1L ) return(FALSE)
  if ( max(u) != length(u) ) return(FALSE)
  all(diff(u) > 0)
}

canonicalForm <- function(labels) {
  temp <- integer(length(labels))
  i <- 1
  for (s in unique(labels)) {
    temp[which(labels == s)] <- i
    i <- i + 1
  }
  temp
}

#' @useDynLib pumpkin .new_FixedPartitionParameters .free_FixedPartitionParameters
#' @useDynLib pumpkin .new_CRPParameters .free_CRPParameters
#' @useDynLib pumpkin .new_FRPParameters .free_FRPParameters
#' @useDynLib pumpkin .new_LSPParameters .free_LSPParameters
#' @useDynLib pumpkin .new_CPPParameters .free_CPPParameters
#' @useDynLib pumpkin .new_EPAParameters .free_EPAParameters
#' @useDynLib pumpkin .new_TRPParameters .free_TRPParameters
#'
partitionDispatch <- function(engine, distr, excluded=NULL) {
  stp <- function() stop(sprintf("'%s' is not supported.", class(distr)[1]))
  if ( ( ! is.null(excluded) ) && ( class(distr)[1] %in% excluded ) ) stp()
  if ( inherits(distr,"FixedPartition") ) {
    p <- .Call(.new_FixedPartitionParameters, distr$baselinePartition)
    result <- engine(0, p)
    .Call(.free_FixedPartitionParameters, p)
    result
  } else if ( inherits(distr,"CRPPartition") ) {
    p <- .Call(.new_CRPParameters, distr$nItems, distr$mass, distr$discount)
    result <- engine(1, p)
    .Call(.free_CRPParameters, p)
    result
  } else if ( inherits(distr, "FocalPartition") ) {
    p <- .Call(.new_FRPParameters, distr$baselinePartition, distr$weights, distr$permutation, FALSE, distr$mass, distr$discount, distr$power)
    result <- engine(2, p)
    .Call(.free_FRPParameters, p)
    result
  } else if ( inherits(distr, "LocationScalePartition") ) {
    p <- .Call(.new_LSPParameters, distr$baselinePartition, distr$weight, distr$permutation, FALSE)
    result <- engine(3, p)
    .Call(.free_LSPParameters, p)
    result
  } else if ( inherits(distr, "CenteredPartition") ) {
    p <- .Call(.new_CPPParameters, distr$baselinePartition, distr$weight, distr$mass, distr$discount, distr$useVI, distr$a)
    result <- engine(4, p)
    .Call(.free_CPPParameters, p)
    result
  } else if ( inherits(distr, "EPAPartition") ) {
    p <- .Call(.new_EPAParameters, distr$similarity, distr$permutation, FALSE, distr$mass, distr$discount)
    result <- engine(5, p)
    .Call(.free_EPAParameters, p)
    result
  } else if ( inherits(distr, "TiltedPartition") ) {
    z <- x2drawspsm(matrix(0), distr$loss)
    engine2 <- function(priorID2, p2) {
      p <- .Call(.new_TRPParameters, distr$baselinePartition, distr$weights, distr$permutation, FALSE, priorID2, p2, z$lossCode, z$a)
      result <- engine(6, p)
      .Call(.free_TRPParameters, p)
      result
    }
    partitionDispatch(engine2, distr$baselineDistribution, c("TiltedPartition","EPAPartition","CenteredPartition","LocationScalePartition","FocalPartition"))
  } else stp()
}

# Below is copied from the "salso" package (version 0.2.5) and then neutered a bit by commenting out stuff.

lossMapping <- c("binder.draws" = 0L, "binder.psm" = 1L, "omARI" = 2L,
                 "omARI.approx" = 3L, "VI" = 4L, "VI.lb" = 5L,
                 "NVI" = 6L, "ID" = 7L, "NID" = 8L)

x2drawspsm <- function(x, loss, nCores=0) {
  draws <- NULL
  psm <- NULL
  a <- 1
  if ( inherits(loss, "salso.loss") ) {
    if ( loss$loss %in% c("binder","VI") ) a <- loss$a
    loss <- loss$loss
  }
  lossStr <- loss
  # if ( isPSM(x) ) {
  #   psm <- x
  #   if ( lossStr == "binder" ) lossStr <- "binder.psm"
  # } else {
  #   draws <- x
  #   if ( lossStr == "binder" ) lossStr <- "binder.draws"
  # }
  if ( ( length(lossStr) != 1 ) || ! ( lossStr %in% names(lossMapping) ) ) {
    stop(sprintf('loss="%s" is not recognized.  Please use one of the following: %s', loss, paste0('"',names(lossMapping),'"',collapse=", ")))
  }
  lossCode <- unname(lossMapping[lossStr])
  # if ( lossStr %in% c("binder.psm","omARI.approx","VI.lb") ) {
  #   if ( is.null(psm) ) psm <- salso::psm(draws, nCores)
  # } else {
  #   if ( is.null(draws) ) stop(sprintf("For the '%s' criterion, 'x' must be samples from a partition distribution.",loss))
  # }
  list(loss=loss, lossStr=lossStr, lossCode=lossCode, a=a, draws=draws, psm=psm)
}
