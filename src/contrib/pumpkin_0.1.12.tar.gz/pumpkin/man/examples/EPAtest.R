subset <- c("Maine","Georgia","California","Minnesota","Montana")
dis <- dist(scale(USArrests[subset,]))

temperature <- 1.0
similarity <- exp( -temperature * as.matrix(dis) )

permutation <- sample(c(1,5,4,2,3))
mass <- 2.0
discount <- 0.1 

partition <- c(1,1,2,3,1)

library(pumpkin)
distr <- EPAPartition(similarity, permutation, mass, discount)
p1 <- function(partition) prPartition(distr, partition, FALSE)
p1(partition)

library(shallot)
temperature2 <- temperature(temperature)
decay2 <- decay.exponential(temperature2, dis)
permutation2 <- permutation(permutation)
attraction <- attraction(permutation2, decay2)
mass2 <- mass(mass)
discount2 <- discount(discount)
distr2 <- ewens.pitman.attraction(mass2, discount2, attraction)
ptmp <- partition.pmf(distr2)
p2 <- function(partition) ptmp(partition, log=FALSE)
p2(partition)

library(salso)
partitions <- enumerate.partitions(length(partition))
sum(apply(partitions, 1, p1))
sum(apply(partitions, 1, p2))

library(microbenchmark)
microbenchmark(
sum(apply(partitions, 1, p1))
,
sum(apply(partitions, 1, p2))
,times=10)




data <- matrix(0, nrow=4, ncol=4)





