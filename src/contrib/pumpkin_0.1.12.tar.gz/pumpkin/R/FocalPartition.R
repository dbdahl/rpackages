#' Probabilities for the Focal Partition Distribution
#'
#' This function evaluates the probability mass function of the focal partition
#' distribution for given target partition, weights, permutation, mass (a.k.a.,
#' concentration), and discount parameters.
#'
#' @inheritParams CRPPartition
#' @param target An integer vector giving the target partition (e.g., focal
#'   partition, center partition, location partition).
#' @param weights A numeric vector of length equal to the length of
#'   \code{target} (i.e., the number of items) giving the weight for each item.
#'   This can also be a scalar, in which case that value is used for each item.
#' @param permutation An vector of integers containing the integers 1, 2, ..., n
#'   giving the order in which items are allocated to the partition.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/FocalPartition.R
#' @export
#'
FocalPartition <- function(target, weights, permutation, mass, discount=0) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nItems)
  else  if ( length(weights) != nItems ) stop("The length of 'weights' must be equal to the number of items in 'target'.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'target'.")
  checkMassDiscount(mass, discount)
  result <- list(nItems=nItems, target=target, weights=weights, permutation=permutation-1L, mass=mass, discount=discount)
  class(result) <- c("FocalPartition", "partitionDistribution")
  result
}

#' @export
print.FocalPartition <- function(x, ...) {
  cat("\nFocal partition distribution\n\n")
  z <- unclass(x)
  z$permutation <- z$permutation + 1L
  print(z)
}
