cat("************ Stopping tests. ************\n")
