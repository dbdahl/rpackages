mass <- 1.5
discount <- 0.1
x <- rCRPPartition(10, 5, mass, discount)
p <- dCRPPartition(x$partition, mass, discount, log=TRUE)
all.equal(p, x$logProbability)
