#' Neal's Algorithm 3 for a Partition
#'
#' This function performs Algorithm 3 of Neal (2000), which updates a partition
#' based on a Dirichlet process (DP) prior for the partition and user-supplied
#' posterior predictive density.  Other prior distributions may be supported in
#' the future.
#'
#' @param partition A numeric vector of cluster labels representing the current
#'   partition.
#' @param logPosteriorPredictiveDensity A function taking an index \eqn{i} (as
#'   an numeric vector of length one) and a subset of integers \eqn{subset} (as
#'   a numeric vector) and returning the natural logarithm of \eqn{p( y_i |
#'   y_subset )}, i.e., that item's contribution to the log integrated
#'   likelihood given the subset of integers. The default value "turns off" the
#'   likelihood, resulting in prior simulation (rather than posterior
#'   simulation).
#' @param priorDistribution A specification of the prior partition distribution,
#'   as returned by a function such as \code{\link{dCRPPartition}}.
#' @param mcmcTuning A list optionally containing \code{nUpdates} (an integer
#'   giving the number of Gibbs scans before returning, defaulting to \code{1})
#'   and \code{nUpdatesForU} (an integer giving the number of Metroplis updates
#'   per partition updates, defaults to \code{1}).
#'
#' @return A list containing \code{partition} (an integer vector giving the
#'   updated partition encoded using cluster labels) and \code{u}.
#'
#' @export
#' @example man/examples/nealAlgorithm3.R
#' @useDynLib pumpkin .nealAlgorithm3_CRP .nealAlgorithm3_NGGP .nealAlgorithm3_FRP .nealAlgorithm3_LSP
#'
nealAlgorithm3 <- function(partition, logPosteriorPredictiveDensity=function(i, subset) 0, priorDistribution=dCRPPartition(mass=1), mcmcTuning=list()) {
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  nUpdatesForPartition <- getOr(mcmcTuning$nUpdatesForPartition, 1)
  pd <- priorDistribution
  if ( priorDistribution$name == "CRP" ) {
    .Call(.nealAlgorithm3_CRP, partition, logPosteriorPredictiveDensity, environment(), nUpdatesForPartition, seed4rust(), pd$mass, pd$discount)
  } else if ( priorDistribution$name == "NGGP" ) {
    stop("This prior distribution is not yet supported for this function.")
    .Call(.nealAlgorithm3_NGGP, partition, logPosteriorPredictiveDensity, environment(), nUpdatesForPartition, seed4rust(), getOr(mcmcTuning$nUpdatesForU, 1), pd$u, pd$mass, pd$reinforcement)
  } else if ( priorDistribution$name == "Focal" ) {
    .Call(.nealAlgorithm3_FRP, partition, logPosteriorPredictiveDensity, environment(), nUpdatesForPartition, seed4rust(), pd$focal, pd$weights, pd$permutation-1L, pd$mass, pd$discount)
  } else if ( priorDistribution$name == "LocationScale" ) {
    .Call(.nealAlgorithm3_LSP, partition, logPosteriorPredictiveDensity, environment(), nUpdatesForPartition, seed4rust(), pd$location, pd$rate, pd$permutation-1L)
  } else stop(sprintf("'%s' is not supported.",priorDistribution$name))
}
