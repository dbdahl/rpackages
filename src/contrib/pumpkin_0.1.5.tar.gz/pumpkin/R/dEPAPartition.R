#' Probabilities for the Ewens-Pitman attraction (EPA) Partition Distribution
#'
#' This function evaluates the probability mass function of the Ewens-Pitman
#' attraction (EPA) partition distribution for given similarity, permutation,
#' mass (a.k.a., concentration), and discount parameters.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param similarity An n-by-n symmetric matrix giving the similarity between
#'   pairs of items.  Matrix enteries must be strictly positive.
#' @param permutation An vector of integers containing the integers 1, 2, ...,
#'   n giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logorithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/bEPAPartition.R
#' @useDynLib pumpkin .bEPAPartition
#' @export
#'
dEPAPartition <- function(partition, similarity, permutation, mass, discount=0, log=FALSE) {
  checkSimilarity(similarity)
  checkPermutation(permutation)
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  if ( length(permutation) != nrow(similarity) ) stop("Dimensionality in 'similarity' and 'permutation' are not compatible.")
  if ( missing(partition) ) {
    result <- list(name="EPA", similarity=similarity, permutation=permutation, mass=mass, discount=discount,
                   logProbability=function(partition) dEPAPartition(partition, similarity, permutation, mass, discount, TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != nrow(similarity) ) stop("Length of 'partition' must equal the number of rows of 'similarity'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bEPAPartition, FALSE, partition, numeric(nSamples), 0L, similarity, permutation-1L, mass, discount, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Ewens-Pitman Attraction (EPA) Partition Distribution
#'
#' This function returns randomly sampled partitions from the Ewens-Pitman
#' attraction (EPA) partition distribution for given similarity, permutation,
#' mass (a.k.a., concentration), and discount parameters.
#'
#' @param nSamples An integer giving the number of partitions to sample.
#' @param similarity An n-by-n symmetric matrix giving the similarity between
#'   pairs of items.  Matrix enteries must be strictly positive.
#' @param permutation An vector of integers containing the integers 0, 1, ...,
#'   n-1 giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @example man/examples/bEPAPartition.R
#' @useDynLib pumpkin .bEPAPartition
#' @export
#'
rEPAPartition <- function(nSamples, similarity, permutation, mass, discount=0, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  checkSimilarity(similarity)
  checkPermutation(permutation)
  nItems <- length(permutation)
  if ( nItems != nrow(similarity) ) stop("Dimensionality in 'similarity' and 'permutation' are not compatible.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  partitions <- matrix(0L, nrow=nSamples, ncol=nItems)
  .Call(.bEPAPartition, TRUE, partitions, numeric(nSamples), seed4rust(), similarity, permutation-1L, mass, discount, useRandomPermutation)
}
