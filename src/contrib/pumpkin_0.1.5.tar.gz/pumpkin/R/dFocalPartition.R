#' Probabilities for the Focal Partition Distribution
#'
#' This function evaluates the probability mass function of the focal partition
#' distribution for given partition, weights, permutation, mass (a.k.a.,
#' concentration), and discount parameters.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param focal An integer vector giving the focal partition.
#' @param weights A numeric vector of length equal to the length of
#'   \code{focal} (i.e., the number of items) giving the weight for
#'   each item.
#' @param permutation An vector of integers containing the integers 1, 2, ...,
#'   n giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logorithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/bFocalPartition.R
#' @useDynLib pumpkin .bFocalPartition
#' @export
#'
dFocalPartition <- function(partition, focal, weights, permutation, mass, discount=0, log=FALSE) {
  weights <- checkArgumentsFocalPartition(focal, weights, permutation, mass, discount)
  if ( missing(partition) ) {
    result <- list(name="Focal", focal=focal, weights=weights, permutation=permutation, mass=mass, discount=discount,
                   logProbability=function(partition) dFocalPartitionEngine(partition, focal, weights, permutation, mass, discount, log=TRUE))
    class(result) <- "partitionDistribution"
    result
  } else {
    dFocalPartitionEngine(partition, focal, weights, permutation, mass, discount, log)
  }
}

dFocalPartitionEngine <- function(partition, focal, weights, permutation, mass, discount, log) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != length(focal) ) stop("Length of 'partition' must equal the length of 'focal'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bFocalPartition, FALSE, partition, numeric(nSamples), 0L, focal, weights, permutation - 1L, mass, discount, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Focal Partition Distribution
#'
#' This function returns randomly sampled partitions from the focal partition
#' distribution for given focal partition, weights, permutation, and mass
#' (a.k.a., concentration) parameters.
#'
#' @inheritParams dFocalPartition
#' @param nSamples An integer giving the number of partitions to sample.
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @example man/examples/bFocalPartition.R
#' @useDynLib pumpkin .bFocalPartition
#' @export
#'
rFocalPartition <- function(nSamples, focal, weights, permutation, mass, discount=0, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  weights <- checkArgumentsFocalPartition(focal, weights, permutation, mass, discount)
  partitions <- matrix(0L, nrow=nSamples, ncol=length(focal))
  .Call(.bFocalPartition, TRUE, partitions, numeric(nSamples), seed4rust(), focal, weights, permutation - 1L, mass, discount, useRandomPermutation)
}

checkArgumentsFocalPartition <- function(focal, weights, permutation, mass, discount) {
  nItems <- length(focal)
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nItems)
  else  if ( length(weights) != nItems ) stop("The length of 'weights' must be equal to the number of items in 'focal'.")
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'focal'.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  weights
}
