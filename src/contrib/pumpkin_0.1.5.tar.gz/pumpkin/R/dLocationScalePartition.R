#' Probabilities for the Location Scale Distribution
#'
#' This function evaluates the probability mass function of the location scale partition
#' distribution for given partition, rate, and permutation parameters.  The rate
#' parameter is the reciprocal of the scale parameter.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param location An integer vector giving the location partition.
#' @param rate A numeric vector of length one
#'   giving the rate, i.e., the reciprocal of the scale.
#' @param permutation An vector of integers containing the integers 1, 2, ...,
#'   n giving the order in which items are allocated to the partition.
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logorithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/bLocationScalePartition.R
#' @useDynLib pumpkin .bLocationScalePartition
#' @export
#'
dLocationScalePartition <- function(partition, location, rate, permutation, log=FALSE) {
  checkArgumentsLocationScalePartition(location, rate, permutation)
  if ( missing(partition) ) {
    result <- list(name="LocationScale", location=location, rate=rate, permutation=permutation,
                   logProbability=function(partition) dLocationScalePartitionEngine(partition, location, rate, permutation, log=TRUE))
    class(result) <- "partitionDistribution"
    result
  } else {
    dLocationScalePartitionEngine(partition, location, rate, permutation, log)
  }
}

dLocationScalePartitionEngine <- function(partition, location, rate, permutation, log) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != length(location) ) stop("Length of 'partition' must equal the length of 'location'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bLocationScalePartition, FALSE, partition, numeric(nSamples), 0L, location, rate, permutation - 1L, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Location Scale Partition Distribution
#'
#' This function returns randomly sampled partitions from the location partition
#' distribution for given location partition, rate, and permutation.  The rate
#' parameter is the reciprocal of the scale parameter.
#'
#' @inheritParams dLocationScalePartition
#' @param nSamples An integer giving the number of partitions to sample.
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @example man/examples/bLocationScalePartition.R
#' @useDynLib pumpkin .bLocationScalePartition
#' @export
#'
rLocationScalePartition <- function(nSamples, location, rate, permutation, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  checkArgumentsLocationScalePartition(location, rate, permutation)
  partitions <- matrix(0L, nrow=nSamples, ncol=length(location))
  .Call(.bLocationScalePartition, TRUE, partitions, numeric(nSamples), seed4rust(), location, rate, permutation - 1L, useRandomPermutation)
}

checkArgumentsLocationScalePartition <- function(location, rate, permutation) {
  nItems <- length(location)
  if ( nItems < 1 ) stop("The number of items in 'location' must be at least one.")
  if ( length(rate) != 1 ) stop("'rate' must be a scalar.")
  if ( rate < 0.0 ) stop("'rate' must be nonnegative.")
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'location'.")
  invisible(NULL)
}
