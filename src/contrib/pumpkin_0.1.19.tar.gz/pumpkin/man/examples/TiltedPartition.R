TiltedPartition(baselinePartition=c(1,1,1,2,2), weights=c(10,10,10,3,3), permutation=c(1,5,4,2,3),
                baseline=CRPPartition(nItems=5, mass=1.5, discount=0.1))
