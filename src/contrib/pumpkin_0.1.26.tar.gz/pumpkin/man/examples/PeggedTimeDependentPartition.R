PeggedTimeDependentPartition(nItems=5, mass=1.5, discount=0.1, nSlices=2, peggedProbability=0.7)
