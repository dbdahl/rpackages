#' Neal's Algorithm 3 for a Partition
#'
#' This function performs Algorithm 3 of Neal (2000), which updates a partition
#' based on a partition prior distribution and a user-supplied function giving
#' an item's contribution to the log integrated likelihood function (in which
#' the cluster-specific model parameters have been integrated out).
#'
#' \code{logIntegratedLikelihoodItem} is a function giving the contribution of
#' item \eqn{i} to the log integrate likelihood is: \deqn{ p( y_i | y_subset ) =
#' \int p( y_i | \theta ) p( \theta | y_subset ) d \theta, } which is available
#' for conditionally conjugate models.
#'
#' @param partition A numeric vector of cluster labels representing the current
#'   partition.  Items \eqn{i} and \eqn{j} are in the same cluster if and only
#'   if \code{partition[i] == partition[j]}.
#' @param logIntegratedLikelihoodItem A function taking an index \eqn{i} (as a
#'   single integer) and a subset of integers \eqn{subset} (as a numeric vector)
#'   and returning the natural logarithm of \eqn{p( y_i | y_subset )}, i.e.,
#'   that item's contribution to the log integrated likelihood given the subset
#'   of integers.
#' @param priorDistribution A specification of the prior partition distribution,
#'   i.e., an object of class \code{partitionDistribution} as returned by, for
#'   example, a function such as \code{\link{dCRPPartition}}.
#' @param mcmcTuning A list optionally containing \code{nUpdates} (an integer
#'   giving the number of Gibbs scans before returning, defaulting to \code{1})
#'   and other variables specific to particular prior partition distribution.
#'
#' @return A list containing \code{partition} (an integer vector giving the
#'   updated partition encoded using cluster labels) and possibly other items
#'   specific to a particular prior.
#'
#' @export
#' @example man/examples/nealAlgorithm3.R
#' @useDynLib pumpkin .nealAlgorithm
#' @useDynLib pumpkin .new_CRPParameters .free_CRPParameters
#' @useDynLib pumpkin .new_FRPParameters .free_FRPParameters
#' @useDynLib pumpkin .new_CPPParameters .free_CPPParameters
#'
nealAlgorithm3 <- function(partition, logIntegratedLikelihoodItem=function(i, subset) 0, priorDistribution=dCRPPartition(mass=1), mcmcTuning=list()) {
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  nUpdatesForPartition <- getOr(mcmcTuning$nUpdatesForPartition, 1)
  pd <- priorDistribution
  if ( priorDistribution$name == "CRP" ) {
    p <- .Call(.new_CRPParameters, pd$mass, pd$discount)
    result <- .Call(.nealAlgorithm, partition, logIntegratedLikelihoodItem, TRUE, environment(), nUpdatesForPartition, seed4rust(), 0, p)
    .Call(.free_CRPParameters, p)
    result
  } else if ( priorDistribution$name == "Focal" ) {
    p <- .Call(.new_FRPParameters, pd$target, pd$weights, pd$permutation, TRUE, pd$mass, pd$discount)
    result <- .Call(.nealAlgorithm, partition, logIntegratedLikelihoodItem, TRUE, environment(), nUpdatesForPartition, seed4rust(), 1, p)
    .Call(.free_FRPParameters, p)
    result
  } else if ( priorDistribution$name == "LocationScale" ) {
    p <- .Call(.new_LSPParameters, pd$target, pd$rate, pd$permutation, TRUE)
    result <- .Call(.nealAlgorithm, partition, logIntegratedLikelihoodItem, TRUE, environment(), nUpdatesForPartition, seed4rust(), 2, p)
    .Call(.free_LSPParameters, p)
    result
   } else if ( priorDistribution$name == "Centered" ) {
    p <- .Call(.new_CPPParameters, pd$target, pd$rate, pd$mass, pd$discount, pd$useVI, pd$a)
    result <- .Call(.nealAlgorithm, partition, logIntegratedLikelihoodItem, TRUE, environment(), nUpdatesForPartition, seed4rust(), 3, p)
    .Call(.free_CPPParameters, p)
    result
  } else stop(sprintf("'%s' is not supported.",priorDistribution$name))
}
