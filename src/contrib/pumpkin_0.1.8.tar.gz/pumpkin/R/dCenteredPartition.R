#' Probabilities for the Centered Partition Process
#'
#' This function evaluates the probability mass function of the centered
#' partition distribution for given target partition, rate, mass (a.k.a.,
#' concentration), and discount parameters.
#'
#' @inheritParams dFocalPartition
#' @param rate A numeric value giving the rate.
#' @param useVI Should the distance between the a particular partition and the
#'   target partition be measured using the variation of information
#'   (\code{TRUE}) or using Binder loss (\code{FALSE})?
#' @param a A nonnegative scalar giving the relative cost of placing two items
#'   in separate clusters when in truth they belong to the same cluster.  This
#'   defaults to \code{1}, meaning equal costs.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/dCenteredPartition.R
#' @useDynLib pumpkin .dCenteredPartition
#' @export
#'
dCenteredPartition <- function(partition, target, rate, mass, discount=0, useVI=TRUE, a=1.0, log=FALSE) {
  checkArgumentsCenteredPartition(target, rate, mass, discount, useVI, a)
  if ( missing(partition) ) {
    result <- list(name="Centered", target=target, rate=rate, mass=mass, discount=discount, useVI=useVI, a=a,
                   logProbability=function(partition) dCenteredPartitionEngine(partition, target, rate, mass, discount, useVI, a, log=TRUE))
    class(result) <- "partitionDistribution"
    result
  } else {
    dCenteredPartitionEngine(partition, target, rate, mass, discount, useVI, a, log)
  }
}

dCenteredPartitionEngine <- function(partition, target, rate, mass, discount, useVI, a, log) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != length(target) ) stop("Length of 'partition' must equal the length of 'target'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.dCenteredPartition, partition, numeric(nSamples), target, rate, mass, discount, useVI, a)
  if (log) logProbabilities else exp(logProbabilities)
}

checkArgumentsCenteredPartition <- function(target, rate, mass, discount, useVI, a) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  if ( length(rate) != 1 ) stop("'rate' must be a scalar.")
  if ( rate < 0.0 ) stop("'rate' must be nonnegative.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  if ( ! is.logical(useVI) ) stop("'useVI' must be a logical.")
  if ( length(a) != 1 ) stop("'a' must be a scalar.")
  if ( a < 0.0 ) stop("'a' must be nonnegative.")
}
