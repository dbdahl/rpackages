#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

// Actual Wrappers
RR_SEXP sexp_to_rr_sexp(SEXP sexp) {
  RR_SEXP s;
  s.sexp_ptr = (void*) sexp;
  return s;
}

RR_SEXP null_rr_sexp() {
  RR_SEXP s;
  s.sexp_ptr = (void*) 0;
  return s;
}

RR_SEXP_vector_INTSXP rrAllocVectorINTSXP(int len) {
  RR_SEXP_vector_INTSXP s;
  s.sexp_ptr = (void*) PROTECT(Rf_allocVector(INTSXP, len));
  s.data_ptr = INTEGER((SEXP)s.sexp_ptr);
  s.len = len;
  return s;
}

double callRFunction_logIntegratedLikelihoodItem(const void* fn_ptr, int i, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP s, t;
  t = s = PROTECT(Rf_allocList(3));
  SET_TYPEOF(s, LANGSXP);
  SETCAR(t, *(SEXP*)fn_ptr); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(i)); t = CDR(t);
  SETCAR(t, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(s, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

double callRFunction_logIntegratedLikelihoodSubset(const void* fn_ptr, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP R_fcall = PROTECT(Rf_lang2(*(SEXP*)fn_ptr, R_NilValue));
  SETCADR(R_fcall, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(R_fcall, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

double callRFunction_logLikelihoodItem(const void* fn_ptr, int i, int label, int is_new, const void* env_ptr) {
  SEXP s, t;
  t = s = PROTECT(Rf_allocList(4));
  SET_TYPEOF(s, LANGSXP);
  SETCAR(t, *(SEXP*)fn_ptr); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(i)); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(label)); t = CDR(t);
  SETCAR(t, Rf_ScalarLogical(is_new)); t = CDR(t);
  double ans = Rf_asReal(Rf_eval(s, *(SEXP*)env_ptr));
  UNPROTECT(1);
  return ans;
}

SEXP new_CRPParameters(SEXP mass_sexp, SEXP discount_sexp) {
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  if ( mass <= -discount ) Rf_error("'mass' must be greater than the negative of 'discount'.");
  CRPParameters *ptr = dahl_randompartition__crpparameters_new(mass, discount);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_CRPParameters(SEXP ptr_sexp) {
  CRPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__crpparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_FRPParameters(SEXP partition_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP use_random_permutation_sexp, SEXP mass_sexp, SEXP discount_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  weights_sexp = PROTECT(Rf_coerceVector(weights_sexp, REALSXP));
  if ( n_items != Rf_length(weights_sexp) ) Rf_error("Length of 'focal' and 'weights' must match.");
  double* weights = REAL(weights_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  if ( ! use_random_permutation && ( n_items != Rf_length(permutation_sexp) ) ) Rf_error("Length of 'focal' and 'permutation' must match.");
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  if ( mass <= -discount ) Rf_error("'mass' must be greater than the negative of 'discount'.");
  FRPParameters *ptr = dahl_randompartition__frpparameters_new(n_items, partition, weights, permutation, use_random_permutation, mass, discount);
  UNPROTECT(3);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_FRPParameters(SEXP ptr_sexp) {
  FRPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__frpparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_LSPParameters(SEXP partition_sexp, SEXP rate_sexp, SEXP permutation_sexp, SEXP use_random_permutation_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  double rate = Rf_asReal(rate_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  if ( ! use_random_permutation && ( n_items != Rf_length(permutation_sexp) ) ) Rf_error("Length of 'location' and 'permutation' must match.");
  LSPParameters *ptr = dahl_randompartition__lspparameters_new(n_items, partition, rate, permutation, use_random_permutation);
  UNPROTECT(2);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_LSPParameters(SEXP ptr_sexp) {
  LSPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__lspparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP new_CPPParameters(SEXP partition_sexp, SEXP rate_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP use_vi_sexp, SEXP a_sexp) {
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int n_items = Rf_length(partition_sexp);
  int* partition = INTEGER(partition_sexp);
  double rate = Rf_asReal(rate_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  int use_vi = Rf_asLogical(use_vi_sexp);
  double a = Rf_asReal(a_sexp);
  if ( mass <= -discount ) Rf_error("'mass' must be greater than the negative of 'discount'.");
  CPPParameters *ptr = dahl_randompartition__cppparameters_new(n_items, partition, rate, mass, discount, use_vi, a);
  UNPROTECT(1);
  return R_MakeExternalPtr(ptr, R_UnboundValue, R_UnboundValue);
}

SEXP free_CPPParameters(SEXP ptr_sexp) {
  CPPParameters *ptr = R_ExternalPtrAddr(ptr_sexp);
  dahl_randompartition__cppparameters_free(ptr);
  R_ClearExternalPtr(ptr_sexp);
  return R_UnboundValue;
}

SEXP nealAlgorithm(SEXP partition_sexp, SEXP callback_sexp, SEXP is_algorithm3_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP prior_id_sexp, SEXP prior_ptr_sexp) {
  int prior_only = Rf_isNull(callback_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(callback_sexp)) Rf_error("Expecting a function.");
  }
  void* callback_ptr = &callback_sexp;
  int is_algorithm3 = Rf_asLogical(is_algorithm3_sexp);
  RR_SEXP map = null_rr_sexp();
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int prior_id = Rf_asInteger(prior_id_sexp);
  void *prior_ptr = R_ExternalPtrAddr(prior_ptr_sexp);
  if ( is_algorithm3 != 0 ) {
    dahl_randompartition__neal_algorithm3(n_updates_for_partition, n_items, partition, prior_only, callback_ptr, env_ptr, seed, prior_id, prior_ptr);
  } else {
    dahl_randompartition__neal_algorithm8(n_updates_for_partition, n_items, partition, prior_only, callback_ptr, env_ptr, seed, prior_id, prior_ptr, &map);
  }
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  if ( is_algorithm3 == 0 ) {
    SET_VECTOR_ELT(results_sexp, 1, (SEXP)map.sexp_ptr);
  }
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("map"));
  Rf_namesgets(results_sexp, names_sexp);
  if ( is_algorithm3 != 0 ) {
    UNPROTECT(3);
  } else {
    UNPROTECT(4);
  }
  return results_sexp;
}

/*
SEXP randomWalkFocalPartition_CRP(SEXP partition_sexp, SEXP rate_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP logLikelihoodSubset_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP crp_mass_sexp, SEXP crp_discount_sexp) {
  int prior_only = Rf_isNull(logLikelihoodSubset_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logLikelihoodSubset_sexp)) Rf_error("'logLikelihoodSubset' must be a function.");
  }
  void* logLikelihoodSubset_ptr = &logLikelihoodSubset_sexp;
  int rate = Rf_asReal(rate_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int n_accepts = 0;
  double crp_mass = Rf_asReal(crp_mass_sexp);
  double crp_discount = Rf_asReal(crp_discount_sexp);
  dahl_randompartition__focalrw_crp(n_updates_for_partition, n_items, partition, rate, mass, discount, prior_only, logLikelihoodSubset_ptr, env_ptr, seed, &n_accepts, crp_mass, crp_discount);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 3));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SET_VECTOR_ELT(results_sexp, 1, Rf_ScalarInteger(n_accepts));
  SET_VECTOR_ELT(results_sexp, 2, n_updates_for_partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 3));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("nAccepts"));
  SET_STRING_ELT(names_sexp, 2, Rf_mkChar("nAttempts"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(3);
  return results_sexp;
}

SEXP randomWalkFocalPartition_FRP(SEXP partition_sexp, SEXP rate_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP logLikelihoodSubset_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP frp_partition_sexp, SEXP frp_weights_sexp, SEXP frp_permutation_sexp, SEXP frp_mass_sexp, SEXP frp_discount_sexp) {
  int prior_only = Rf_isNull(logLikelihoodSubset_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logLikelihoodSubset_sexp)) Rf_error("'logLikelihoodSubset' must be a function.");
  }
  void* logLikelihoodSubset_ptr = &logLikelihoodSubset_sexp;
  int rate = Rf_asReal(rate_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int n_accepts = 0;
  frp_partition_sexp = PROTECT(Rf_coerceVector(frp_partition_sexp, INTSXP));
  int* frp_partition = INTEGER(frp_partition_sexp);
  frp_weights_sexp = PROTECT(Rf_coerceVector(frp_weights_sexp, REALSXP));
  double* frp_weights = REAL(frp_weights_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  int* frp_permutation = INTEGER(frp_permutation_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  double frp_mass = Rf_asReal(frp_mass_sexp);
  double frp_discount = Rf_asReal(frp_discount_sexp);
  dahl_randompartition__focalrw_frp(n_updates_for_partition, n_items, partition, rate, mass, discount, prior_only, logLikelihoodSubset_ptr, env_ptr, seed, &n_accepts, frp_partition, frp_weights, frp_permutation, frp_mass, frp_discount);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 3));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SET_VECTOR_ELT(results_sexp, 1, Rf_ScalarInteger(n_accepts));
  SET_VECTOR_ELT(results_sexp, 2, n_updates_for_partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 3));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("nAccepts"));
  SET_STRING_ELT(names_sexp, 2, Rf_mkChar("nAttempts"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(7);
  return results_sexp;
}
*/

/*
SEXP nealAlgorithm3_EPA(SEXP partition_sexp, SEXP logIntegratedLikelihoodItem_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP similarity_sexp, SEXP frp_permutation_sexp, SEXP frp_mass_sexp, SEXP frp_discount_sexp) {
  int prior_only = Rf_isNull(logIntegratedLikelihoodItem_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logIntegratedLikelihoodItem_sexp)) Rf_error("'logPosteriorPrectiveDensity' must be a function.");
  }
  void* logIntegratedLikelihoodItem_ptr = &logIntegratedLikelihoodItem_sexp;
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  similarity_sexp = PROTECT(Rf_coerceVector(similarity_sexp, REALSXP));
  if ( n_items != Rf_ncols(similarity_sexp) ) Rf_error("The dimensionality of 'partition' and 'similarity' do not match.");
  double* similarity = REAL(similarity_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  int* frp_permutation = INTEGER(frp_permutation_sexp);
  double frp_mass = Rf_asReal(frp_mass_sexp);
  double frp_discount = Rf_asReal(frp_discount_sexp);
  dahl_randompartition__neal_algorithm3_epa(n_updates_for_partition, n_items, partition, prior_only, logIntegratedLikelihoodItem_ptr, env_ptr, seed, similarity, frp_permutation, frp_mass, frp_discount);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 1));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 1));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(5);
  return results_sexp;
}
*/

SEXP bCRPPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP mass_sexp, SEXP discount_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  dahl_randompartition__crp_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, mass, discount);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(4);
    return results_sexp;
  } else {
    UNPROTECT(2);
    return probabilities_sexp;
  }
}

/*
SEXP bEPAPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP similarity_sexp, SEXP permutation_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP use_random_permutation_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  similarity_sexp = PROTECT(Rf_coerceVector(similarity_sexp, REALSXP));
  double* similarity = REAL(similarity_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  dahl_randompartition__epa_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, similarity, permutation, mass, discount, use_random_permutation);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(6);
    return results_sexp;
  } else {
    UNPROTECT(4);
    return probabilities_sexp;
  }
}

SEXP bNGGPPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP u_sexp, SEXP mass_sexp, SEXP reinforcement_sexp, SEXP n_updates_for_u_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  double u = Rf_asReal(u_sexp);
  double mass = Rf_asReal(mass_sexp);
  double reinforcement = Rf_asReal(reinforcement_sexp);
  int n_updates_for_u = Rf_asInteger(n_updates_for_u_sexp);
  dahl_randompartition__nggp_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, u, mass, reinforcement, n_updates_for_u);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(4);
    return results_sexp;
  } else {
    UNPROTECT(2);
    return probabilities_sexp;
  }
}
*/

SEXP bFocalPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP frp_partition_sexp, SEXP frp_weights_sexp, SEXP frp_permutation_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP use_random_permutation_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  frp_partition_sexp = PROTECT(Rf_coerceVector(frp_partition_sexp, INTSXP));
  int* frp_partition = INTEGER(frp_partition_sexp);
  frp_weights_sexp = PROTECT(Rf_coerceVector(frp_weights_sexp, REALSXP));
  double* frp_weights = REAL(frp_weights_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  int* frp_permutation = INTEGER(frp_permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  dahl_randompartition__focal_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, frp_partition, frp_weights, frp_permutation, mass, discount, use_random_permutation);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(7);
    return results_sexp;
  } else {
    UNPROTECT(5);
    return probabilities_sexp;
  }
}

SEXP bLocationScalePartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP lsp_partition_sexp, SEXP lsp_rate_sexp, SEXP lsp_permutation_sexp, SEXP use_random_permutation_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  lsp_partition_sexp = PROTECT(Rf_coerceVector(lsp_partition_sexp, INTSXP));
  int* lsp_partition = INTEGER(lsp_partition_sexp);
  double lsp_rate = Rf_asReal(lsp_rate_sexp);
  lsp_permutation_sexp = PROTECT(Rf_coerceVector(lsp_permutation_sexp, INTSXP));
  int* lsp_permutation = INTEGER(lsp_permutation_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  dahl_randompartition__ls_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, lsp_partition, lsp_rate, lsp_permutation, use_random_permutation);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(6);
    return results_sexp;
  } else {
    UNPROTECT(4);
    return probabilities_sexp;
  }
}

SEXP dCenteredPartition(SEXP partitions_sexp, SEXP probabilities_sexp, SEXP cpp_partition_sexp, SEXP rate_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP use_vi_sexp, SEXP a_sexp) {
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  cpp_partition_sexp = PROTECT(Rf_coerceVector(cpp_partition_sexp, INTSXP));
  int* cpp_partition = INTEGER(cpp_partition_sexp);
  double rate = Rf_asReal(rate_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  int use_vi = Rf_asLogical(use_vi_sexp);
  double a = Rf_asReal(a_sexp);
  dahl_randompartition__centered_partition(n_partitions, n_items, partitions, probabilities, cpp_partition, rate, mass, discount, use_vi, a);
  UNPROTECT(3);
  return probabilities_sexp;
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
//  {".randomWalkFocalPartition_CRP", (DL_FUNC) &randomWalkFocalPartition_CRP, 10},
//  {".randomWalkFocalPartition_FRP", (DL_FUNC) &randomWalkFocalPartition_FRP, 13},
  {".new_CRPParameters", (DL_FUNC) &new_CRPParameters, 2},
  {".free_CRPParameters", (DL_FUNC) &free_CRPParameters, 1},
  {".new_FRPParameters", (DL_FUNC) &new_FRPParameters, 6},
  {".free_FRPParameters", (DL_FUNC) &free_FRPParameters, 1},
  {".new_LSPParameters", (DL_FUNC) &new_LSPParameters, 4},
  {".free_LSPParameters", (DL_FUNC) &free_LSPParameters, 1},
  {".new_CPPParameters", (DL_FUNC) &new_CPPParameters, 6},
  {".free_CPPParameters", (DL_FUNC) &free_CPPParameters, 1},
  {".nealAlgorithm", (DL_FUNC) &nealAlgorithm, 8},
//  {".nealAlgorithm3_NGGP", (DL_FUNC) &nealAlgorithm3_NGGP, 9},
//  {".nealAlgorithm3_FRP", (DL_FUNC) &nealAlgorithm3_FRP, 10},
//  {".nealAlgorithm3_LSP", (DL_FUNC) &nealAlgorithm3_LSP, 8},
//  {".nealAlgorithm3_CPP", (DL_FUNC) &nealAlgorithm3_CPP, 11},
//  {".nealAlgorithm3_EPA", (DL_FUNC) &nealAlgorithm3_EPA, 9},
  {".bCRPPartition", (DL_FUNC) &bCRPPartition, 6},
  {".bFocalPartition", (DL_FUNC) &bFocalPartition, 10},
  {".bLocationScalePartition", (DL_FUNC) &bLocationScalePartition, 8},
  {".dCenteredPartition", (DL_FUNC) &dCenteredPartition, 8},
//  {".bEPAPartition", (DL_FUNC) &bEPAPartition, 9},
//  {".bNGGPPartition", (DL_FUNC) &bNGGPPartition, 8},
  {NULL, NULL, 0}
};

void R_init_pumpkin(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
