#' #' Probabilities for the Normalized Generalized Gamma Process (NGGP) Partition
#' #' Distribution
#' #'
#' #' This function evaluates the probability mass function of the normalized
#' #' generalized gamma process (NGGP) partition distribution for given u, mass
#' #' (a.k.a., concentration), and reinforcement parameters.
#' #'
#' #' @param partition An integer matrix containing a partition in each row in
#' #'   cluster label form.
#' #' @param u The latent u as a numeric value greater than zero.
#' #' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#' #'   greater than zero.
#' #' @param reinforcement The reinforcement parameter as a numeric value in [0,1).
#' #' @param log A logical indicating whether the probability (\code{FALSE}) or its
#' #'   natural logarithm (\code{TRUE}) is desired.
#' #'
#' #' @return A numeric vector giving either probabilities or log probabilities for
#' #'   the supplied partitions.
#' #'
#' #' @examples
#' #' dNGGPPartition(c(0,0,1,0), u=200, mass=1, reinforcement=0.2)
#' #'
#' #' @concept useDynLib pumpkin .bNGGPPartition
#' #' @export
#' #'
#' dNGGPPartition <- function(partition, u, mass, reinforcement, log=FALSE) {
#'   if ( u < 0.0 ) stop("'u' must be non-negative.")
#'   if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
#'   if ( ( reinforcement < 0.0 ) || ( reinforcement >= 1.0 ) ) stop("'reinforcement' must be in [0,1).")
#'   if ( missing(partition) ) {
#'     result <- list(name="NGGP", u=u, mass=mass, reinforcement=reinforcement, logProbability=function(partition) dNGGPPartition(partition, u, mass, reinforcement, TRUE))
#'     class(result) <- "partitionDistribution"
#'     return(result)
#'   }
#'   if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
#'   nSamples <- nrow(partition)
#'   if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
#'   nItems <- ncol(partition)
#'   if ( nItems < 1 ) stop("The number of columns of 'partition' must be at least one.")
#'   logProbabilities <- .Call(.bNGGPPartition, FALSE, partition, numeric(nSamples), 0L, u, mass, reinforcement, FALSE)
#'   if (log) logProbabilities else exp(logProbabilities)
#' }
#'
#' #' Probabilities for the Normalized Generalized Gamma Process (NGGP) Partition
#' #' Distribution
#' #'
#' #' This function returns randomly sampled partitions from the normalized
#' #' generalized gamma process (NGGP) for a given u, mass (a.k.a., concentration),
#' #' and reinforcement parameters.
#' #'
#' #' @param nSamples An integer giving the number of partitions to sample.
#' #' @param nItems An integer giving the number of items in each partition.
#' #' @param u The latent u as a numeric value greater than zero.
#' #' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#' #'   greater than zero.
#' #' @param reinforcement The reinforcement parameter as a numeric value in [0,1).
#' #' @param nUpdatesForU Number of updates for u for every reallocation scan.
#' #'
#' #' @return A numeric vector giving either probabilities or log probabilities for
#' #'   the supplied partitions.
#' #'
#' #' @examples
#' #' rNGGPPartition(7, 3, u=200, mass=1, reinforcement=0.2)
#' #'
#' #' @concept useDynLib pumpkin .bNGGPPartition
#' #' @export
#' #'
#' rNGGPPartition <- function(nSamples, nItems, u, mass, reinforcement, nUpdatesForU=1L) {
#'   if ( nSamples < 1 ) stop("The number of samples must be at least one.")
#'   if ( nItems < 1 ) stop("The number of items must be at least one.")
#'   if ( u < 0.0 ) stop("'u' must be non-negative.")
#'   if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
#'   if ( ( reinforcement < 0.0 ) || ( reinforcement >= 1.0 ) ) stop("'reinforcement' must be in [0,1).")
#'   partitions <- matrix(0L, nrow=nSamples, ncol=nItems)
#'   .Call(.bNGGPPartition, TRUE, partitions, numeric(nSamples), seed4rust(), u, mass, reinforcement, nUpdatesForU)
#' }
