mass <- 1.0
discount <- 0.1
nSamples <- 3

distr <- CRPPartition(nItems=5, mass, discount)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

target <- c(1,1,1,2,2)
permutation <- c(1,5,4,2,3)

distr <- LocationScalePartition(target, weight=1/0.1, permutation)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

distr <- FocalPartition(target, weights=c(10,10,10,3,3), permutation, mass, discount)
x <- samplePartition(distr, nSamples)
prPartition(distr, x)

distr <- CenteredPartition(target, weight=1/0.1, mass, discount)
prPartition(distr, x)
