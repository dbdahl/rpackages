# Neal (2000) model and data

data <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
sigma2 <- 0.1^2
mu0 <- 0
sigma02 <- 1

logLikelihoodOfItem <- function(i, parameter) {
  dnorm(data[i], mean=parameter, sd=sqrt(sigma2), log=TRUE)
}

sampleParameter <- function() {
  rnorm(1, mean=mu0, sd=sqrt(sigma02))
}

updateParameter <- function(parameter, subset) {
  posteriorVariance <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
  posteriorMean     <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
  rnorm(1, mean=posteriorMean, sd=sqrt(posteriorVariance))
}

# Prior partition distribution

distr <- CRPPartition(nItems=length(data), mass=1.5, discount=0.2)

# MCMC

mcmcTuning <- list(nUpdates=2)
nSamples <- 1000L
nAccepts <- nAttempts <- 0L
partitionSamples <- matrix(1, nrow=nSamples, ncol=length(data))
parametersSamples <- list(list(sampleParameter()))
for ( i in 2:nSamples ) {
  # Update partition
  out <- nealAlgorithm8(partitionSamples[i-1,], parametersSamples[[i-1]], distr,
                        logLikelihoodOfItem, sampleParameter, updateParameter, mcmcTuning)
  partitionSamples[i,] <- out$partition
  parametersSamples[[i]] <- out$parameters
  # Update permutation
  # Perhaps add code to update other parameters, e.g., mass, discount, etc.
}

nSubsets <- apply(partitionSamples, 1, function(x) length(unique(x)))
mean(nSubsets)
sum(acf(nSubsets)$acf)-1   # Autocorrelation time
