FocalPartition(target=c(1,1,1,2,2), weights=c(10,10,10,3,3), permutation=c(1,5,4,2,3),
               mass=1.0, discount=0.1)
