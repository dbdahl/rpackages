scalaDevelDownloadJARs("org.apache.commons:commons-math3:3.6.1")
scalaDevelDownloadJARs("org.scala-lang.modules:scala-parallel-collections_2.13:0.2.0", "2.13")

