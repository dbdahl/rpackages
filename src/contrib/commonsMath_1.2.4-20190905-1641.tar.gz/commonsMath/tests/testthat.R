library(testthat)
library(commonsMath)

test_check("commonsMath")
