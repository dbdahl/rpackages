if ( ! skipall ) {
  close(s)
  cat("Stopping instance. **************************\n")
}
