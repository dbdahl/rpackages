partition <- c(1,1,2,2,3)
focal <- c(1,1,1,2,2)
weights <- c(10,10,10,3,3)
permutation <- c(1,5,4,2,3)
mass <- 1.0
discount <- 0.1

dFocalPartition(partition, focal, weights, permutation, mass, discount)
x <- rFocalPartition(100, focal, weights, permutation, mass, discount, useRandomPermutation=FALSE)
p <- dFocalPartition(x$partition, focal, weights, permutation, mass, discount, log=TRUE)
all.equal(p, x$logProbability)
