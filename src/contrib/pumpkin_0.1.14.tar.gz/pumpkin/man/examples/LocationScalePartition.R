scale <- 0.1
LocationScalePartition(target=c(1,1,1,2,2), weight=1/scale, permutation=c(1,5,4,2,3))
