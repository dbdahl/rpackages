lpmlPartition <- function(partition, parameters, logLikelihoodOfItem, callback) {
  S <- nrow(partition)
  n <- ncol(partition)
  x <- computeLikelihoodComponents(partition, parameters, logLikelihoodOfItem, callback)
  mins <- apply(x,2,min)
  n*log(S) + sum(mins) - sum(sapply(seq_len(n), function(k) {
    log(sum(exp(mins[k] - x[,k])))
  }))
}

waicPartition <- function(partition, parameters, logLikelihoodOfItem, callback) {
  S <- nrow(partition)
  n <- ncol(partition)
  x <- computeLikelihoodComponents(partition, parameters, logLikelihoodOfItem, callback)
  maxs <- apply(x,2,max)
  lppd <- -n*log(S) + sum(maxs) + sum(sapply(seq_len(n), function(k) {
    log(sum(exp(x[,k] - maxs[k])))
  }))
  p <- sum(apply(x,2,var))
  -2*(lppd - p)
}

computeLikelihoodComponents <- function(partition, parameters, logLikelihoodOfItem, callback) {
  S <- nrow(partition)
  n <- ncol(partition)
  t(sapply(seq_len(S), function(s) {
    part <- partition[s,]
    parms <- parameters[[s]]
    callback(s)
    sapply(seq_len(n), function(i) {
      logLikelihoodOfItem(i, parms[[part[i]]])
    })
  }))
}

