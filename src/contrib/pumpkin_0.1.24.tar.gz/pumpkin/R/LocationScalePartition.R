#' Probabilities for the Location Scale Partition Distribution
#'
#' This function specifies the location scale partition distribution for given
#' baseline partition, weight, and permutation parameters.  The weight parameter
#' is the reciprocal of the scale parameter.
#'
#' @inheritParams FocalPartition
#' @param weights A scalar giving the value of the weight parameter, i.e.,the
#'   reciprocal of the scale parameter.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/LocationScalePartition.R
#' @export
#'
LocationScalePartition <- function(baselinePartition, weights, permutation) {
  nItems <- length(baselinePartition)
  if ( nItems < 1 ) stop("The number of items in 'baselinePartition' must be at least one.")
  if ( length(weights) != 1 ) stop("'weights' must be a scalar.")
  if ( weights < 0.0 ) stop("'weights' must be nonnegative.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'baselinePartition'.")
  result <- list(nItems=nItems, baselinePartition=baselinePartition, weights=weights, permutation=permutation-1L)
  class(result) <- c("LocationScalePartition", "partitionDistribution")
  result
}

#' @export
print.LocationScalePartition <- function(x, ...) {
  cat("\nLocation scale partition distribution\n\n")
  z <- unclass(x)
  z$permutation <- z$permutation + 1L
  print(z)
}
