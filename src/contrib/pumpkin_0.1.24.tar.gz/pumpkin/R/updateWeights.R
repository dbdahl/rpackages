#' Update the Weights Parameter of a Partition Distribution
#'
#' This function updates the weights parameter of a partition distribution (e.g,
#' \code{\link{FocalPartition}} and \code{\link{TiltedPartition}}) using a
#' Gaussian random walk.  The prior can be specified by the user.
#'
#' @inheritParams updatePermutation
#' @param rwsd A scalar giving the standard deviation of the Gaussian random
#'   walk.
#' @param relativeTo An integer between 1 and the number of items (inclusive)
#'   indicating the item to which the other weights are relative.
#' @param logPriorDensity A function taking a single scalar argument and
#'   returning the log of the prior density for the parameter evaluated at the
#'   argument.
#'
#' @return A list containing the potentially updated partition distribution and
#'   a logical named \code{accepted} (indicating whether the proposal was
#'   accepted).
#'
#' @seealso \code{\link{nealAlgorithm3}}, \code{\link{nealAlgorithm8}}
#'
#' @example man/examples/nealAlgorithm3.R
#'
#' @export
#'
updateWeights <- function(distr, partition, rwsd=1, relativeTo=1,
                          logPriorDensity=function(w) dunif(w, 0, 25, log=TRUE)) {
  if ( is.null(distr[['weights']]) || rwsd <= 0 || inherits(distr,"CenteredPartition") ) {
    return(list(distr=distr, accepted=FALSE))
  }
  proposalDistr <- distr
  oldW <- distr[['weights']][relativeTo]
  newW <- rnorm(1, mean=oldW, sd=rwsd)
  proposalDistr$weights <- newW/distr[['weights']][relativeTo] * distr[['weights']]
  if ( newW < 0.0 ) return(list(distr=distr, accepted=FALSE))
  logMHRatio <- prPartition(proposalDistr, partition, log=TRUE) + logPriorDensity(newW) - prPartition(distr, partition, log=TRUE) - logPriorDensity(oldW)
  if ( log(runif(1)) < logMHRatio ) list(distr=proposalDistr, accepted=TRUE)
  else list(distr=distr, accepted=FALSE)
}
