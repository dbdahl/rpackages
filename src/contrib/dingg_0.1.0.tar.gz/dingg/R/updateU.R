# As suggested by Favaro and Teh (2013), this uses a Gaussian random walk for the log(U) with a proposal variance of 1/4.
updateU <- function(partitionPrior, partition) {  # This could be implemented in a low-level language for the sake of speed.
  m <- partitionPrior$mass
  r <- partitionPrior$reinforcement
  ni <- length(partition)
  ns <- length(unique(partition))
  logFullConditionalOfV <- function(v) {
    uPlus1 <- exp(v) + 1
    v*ni - (ni - m*ns) * log(uPlus1) - (m/r)*(uPlus1^r - 1)
  }
  current <- log(partitionPrior$u)
  proposal <- rnorm(1,current,sd=sqrt(1/4))
  lmh <- logFullConditionalOfV(proposal) - logFullConditionalOfV(current)
  if ( log(runif(1)) < lmh ) {
    partitionPrior$u <- exp(proposal)
  }
  partitionPrior
}

# This uses a slice sampler, but isn't very stable.
updateU.OLD <- function(partitionPrior, partition, tuningParameter) {  # This could be implemented in a low-level language for the sake of speed.
  DEBUG <- if ( tuningParameter < 0 ) {
    tuningParameter <- -tuningParameter
    browser()
    TRUE
  } else FALSE
  m <- partitionPrior$mass
  r <- partitionPrior$reinforcement
  ni <- length(partition)
  ns <- length(unique(partition))
  logFullConditionalOfV <- function(v) {
    uPlus1 <- exp(v) + 1
    v*ni - (ni - m*ns) * log(uPlus1) - (m/r)*(uPlus1^r - 1)
  }
  uss <- univariateSliceSampler(1, logFullConditionalOfV, log(partitionPrior$u), tuningParameter)
  partitionPrior$u <- exp(uss$samples)
  if ( DEBUG ) cat("< ",partitionPrior$u," ",uss$evaluationsPerSample," >\n",sep="")
  partitionPrior
}




