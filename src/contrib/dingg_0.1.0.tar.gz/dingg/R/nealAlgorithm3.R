#' Neal's Algorithm 3 for a Partition
#'
#' This function performs Algorithm 3 of Neal (2000), which updates a partition
#' based on either a Dirichlet process (DP) or a normalized generalized gamma
#' process (NGGP) prior for the partition and user-supplied posterior predictive
#' density.
#'
#' @param partition A numeric vector of cluster labels representing the current
#'   partition.
#' @param logPosteriorPredictiveDensity A function taking an index \eqn{i} (as
#'   an numeric vector of length one) and a subset of integers \eqn{subset} (as
#'   a numeric vector) and returning the natural logarithm of \eqn{p( y_i |
#'   y_subset )}, i.e., that item's contribution to the log integrated
#'   likelihood given the subset of integers. The default value "turns off" the
#'   likelihood, resulting in prior simulation (rather than posterior
#'   simulation).
#' @param priorDistribution A specification of the prior partition distribution
#'   as returned by a function such as \code{\link{dCRPPartition}}.
#' @param nUpdates An integer giving the number of Gibbs scans before returning.
#'   This has the effect of thinning the Markov chain.
#'
#' @return An integer vector giving the updated partition encoded using cluster
#'   labels.
#'
#' @export
#' @useDynLib dingg .nealAlgorithm3
#' @examples
#' # Neal (2000) model and data
#' nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
#' mkLogIntegratedLikelihoodOfItem <- function(data=nealData, sigma2=0.1^2, mu0=0, sigma02=1) {
#'   function(i, subset) {
#'     posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
#'     posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
#'     posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
#'     dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
#'   }
#' }
#'
#' logLike <- mkLogIntegratedLikelihoodOfItem()
#' partitionPrior <- dCRPPartition(mass=1.0)
#'
#' nSamples <- 1000L
#' nAccepts <- nAttempts <- 0L
#' partitions <- matrix(0, nrow=nSamples, ncol=length(nealData))
#' for ( i in 2:nSamples ) {
#'   partitions[i,] <- nealAlgorithm3(partitions[i-1,], logLike, partitionPrior, nUpdates=2)
#' }
#'
#' nSubsets <- apply(partitions, 1, function(x) length(unique(x)))
#' mean(nSubsets)
#' sum(acf(nSubsets)$acf)-1   # Autocorrelation time
#'
nealAlgorithm3 <- function(partition, logPosteriorPredictiveDensity=function(i, subset) 0.0, priorDistribution=dCRPPartition(mass=1.0), nUpdates=1) {
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  if ( priorDistribution$name == "CRP" ) {
    priorPartitionCode <- 0
    u <- -Inf
    mass <- priorDistribution$mass
    reinforcement <- -Inf
  } else if ( priorDistribution$name == "NGGP" ) {
    priorPartitionCode <- 1
    u <- priorDistribution$u
    mass <- priorDistribution$mass
    reinforcement <- priorDistribution$reinforcement
  } else stop(sprintf("'%s' is not supported.",priorDistribution$name))
  .Call(.nealAlgorithm3, partition, logPosteriorPredictiveDensity, environment(), nUpdates, priorPartitionCode, u, mass, reinforcement)
}
