#' Probability mass function of a Chinese Restaurant Process partition
#'
#' @param partitions Supplied in the form of a matrix containing partition samples per each row where cluster labels are input and must be in canonical form with base 0.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value.
#' @param log Logical. log = TRUE returns a log probability
#'
#' @return Probability mass of observing supplied partition from the Chinese Restaurant Process partition distribution under mass.
#'
#' @examples
#' dCRPPartition(c(0,0,1,0), mass = 1)
#'
#' @export
#'
dCRPPartition <- function(partitions, mass, log=FALSE) {
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( missing(partitions) ) {
    result <- list(name="CRP", mass=mass, logProbability=function(partition) dCRPPartition(partition, mass, TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partitions) ) partitions <- matrix(partitions, nrow=1)
  nSamples <- nrow(partitions)
  if ( nSamples < 1 ) stop("The number of rows of 'partitions' must be at least one.")
  nItems <- ncol(partitions)
  if ( nItems < 1 ) stop("The number of columns of 'partitions' must be at least one.")
  focal <- rep(0L, nItems)
  weights <- 0.0
  permutation <- 0L:(nItems-1L)
  result <- .Call(.dFocalPartition, partitions, focal, weights, permutation, mass)
  if (log) result else exp(result)
}
