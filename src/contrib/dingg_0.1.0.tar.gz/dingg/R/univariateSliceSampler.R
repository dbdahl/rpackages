# Function to sample from a univariate distribution (without isolated nodes)
# using the log of its (potentially unnormalized) density. This can be helpful if you are
# in a Gibbs sampling framework but don't recognize the density as belonging to
# a known distributional family.
#
# Our approach is the slice sampler.  See Gelman, pg. 297 and
# https://en.wikipedia.org/wiki/Slice_sampling
#
# The width is a tuning parameter affecting the computational efficiency of the
# algorithm.
#
univariateSliceSampler <- function(n, logDensity, initial, width) {
  nEvaluations <- 0
  f <- function(x) { nEvaluations <<- nEvaluations + 1; logDensity(x) }
  samples <- numeric(n)
  current <- initial
  fCurrent <- f(current)
  for ( i in seq_along(samples) ) {
    y <- log(runif(1, 0, exp(fCurrent)))
    l <- current - width
    while ( y < f(l) ) l <- l - width
    u <- current + width
    while ( y < f(u) ) u <- u + width
    while ( TRUE ) {
      candidate <- runif(1, l, u)
      fCandidate <- f(candidate)
      if ( y > fCandidate ) {
        if ( candidate < current ) l <- candidate
        else u <- candidate
      } else break
    }
    current <- candidate
    fCurrent <- fCandidate
    samples[i] <- current
  }
  list(samples=samples, evaluationsPerSample=nEvaluations/n)
}
