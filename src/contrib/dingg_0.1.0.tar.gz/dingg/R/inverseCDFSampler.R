# Function to sample from an arbitrary univariate distribution using its
# (potentially unnormalized) density. This can be helpful if you are in a Gibbs
# sampling framework but don't recognize the density as belonging to a known
# distributional family.
#
# Our approach is the inverse CDF method.  Specifically, given a Uniformly(0,1)
# random variate u, find the root (i.e., the value z such that the function is
# zero) for the function w(z) = "integration of density unto to z" - u.
#
# Note that the function finds the normalizing constant.
#
# Our approach here is not terribly efficient, but it works!
# 
inverseCDFSampler <- function(n, density, interval) {
  normalizingConstant <- integrate(density, interval[1], interval[2])$value
  normalizedDensity <- function(x) density(x)/normalizingConstant
  sapply(runif(n), function(u) {
    w <- function(z) integrate(normalizedDensity, interval[1], z)$value - u
    uniroot(w, interval)$root
  })
}
