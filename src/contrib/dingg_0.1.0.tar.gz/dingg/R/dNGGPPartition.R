#' Probability mass function of a Chinese Restaurant Process partition
#'
#' @param partitions Supplied in the form of a matrix containing partition samples per each row where cluster labels are input and must be in canonical form with base 0.
#' @param u The latent u as a numeric value.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value.
#' @param reinformcement The reinforcement parameter as a numeric value.
#' @param log Logical. log = TRUE returns a log probability
#'
#' @return Probability mass of observing supplied partition from the Chinese Restaurant Process partition distribution under mass.
#'
#' @examples
#' dCRPPartition(c(0,0,1,0), mass = 1)
#'
#' @export
#'
dNGGPPartition <- function(partitions, u, mass, reinforcement, log=FALSE) {
  if ( u < 0.0 ) stop("'u' must be non-negative.")
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( ( reinforcement < 0.0 ) || ( reinforcement >= 1.0 ) ) stop("'reinforcement' must be in [0,1).")
  if ( missing(partitions) ) {
    result <- list(name="NGGP", u=u, mass=mass, reinforcement=reinforcement, logProbability=function(partition) dNGGPPartition(partition, u, mass, reinforcement, TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partitions) ) partitions <- matrix(partitions, nrow=1)
  nSamples <- nrow(partitions)
  if ( nSamples < 1 ) stop("The number of rows of 'partitions' must be at least one.")
  nItems <- ncol(partitions)
  if ( nItems < 1 ) stop("The number of columns of 'partitions' must be at least one.")
  result <- .Call(.dNGGPPartition, partitions, u, mass, reinforcement)
  if (log) result else exp(result)
}
