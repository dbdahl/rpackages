#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

// Actual Wrappers
RR_SEXP_vector_INTSXP rrAllocVectorINTSXP(int len) {
  RR_SEXP_vector_INTSXP s;
  s.sexp_ptr = (void*) PROTECT(Rf_allocVector(INTSXP, len));
  s.data_ptr = INTEGER((SEXP)s.sexp_ptr);
  s.len = len;
  return s;
}

double callRFunction_logIntegratedLikelihoodOfSubset(const void* fn_ptr, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP R_fcall = PROTECT(Rf_lang2(*(SEXP*)fn_ptr, R_NilValue));
  SETCADR(R_fcall, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(R_fcall, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

double callRFunction_logIntegratedLikelihoodOfItem(const void* fn_ptr, int i, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP s, t;
  t = s = PROTECT(Rf_allocList(3));
  SET_TYPEOF(s, LANGSXP);
  SETCAR(t, *(SEXP*)fn_ptr); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(i)); t = CDR(t);
  SETCAR(t, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(s, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

SEXP nealAlgorithm3(SEXP partition_sexp, SEXP logLikelihoodOfItem_sexp, SEXP env_sexp, SEXP n_updates_sexp, SEXP prior_partition_code_sexp, SEXP u_sexp, SEXP mass_sexp, SEXP reinforcement_sexp) {
  if (!Rf_isFunction(logLikelihoodOfItem_sexp)) Rf_error("'logLikelihoodOfSubset' must be a function.");
  void* logLikelihoodOfItem_ptr = &logLikelihoodOfItem_sexp;
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates = Rf_asInteger(n_updates_sexp);
  int prior_partition_code = Rf_asInteger(prior_partition_code_sexp);
  double u = Rf_asReal(u_sexp);
  double mass = Rf_asReal(mass_sexp);
  double reinforcement = Rf_asReal(reinforcement_sexp);
  dahl_randompartition__neal_algorithm3_update(n_updates, n_items, prior_partition_code, u, mass, reinforcement, partition, logLikelihoodOfItem_ptr, env_ptr);
  UNPROTECT(1);
  return partition_sexp;
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
  {".nealAlgorithm3", (DL_FUNC) &nealAlgorithm3, 5},
  {NULL, NULL, 0}
};

void R_init_dingg(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
