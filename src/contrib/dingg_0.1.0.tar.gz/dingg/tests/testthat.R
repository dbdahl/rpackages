library(testthat)
library(dingg)

test_check("dingg")
