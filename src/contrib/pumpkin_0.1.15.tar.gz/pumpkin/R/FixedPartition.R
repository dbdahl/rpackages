#' Probabilities for the Fixed Partition Distribution
#'
#' This function evaluates the probability mass function of the fixed partition
#' distribution for given target partition.  This is a point-mass distribution
#' at the target partition.
#'
#' @inheritParams FocalPartition
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/FixedPartition.R
#' @export
#'
FixedPartition <- function(target) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  result <- list(nItems=nItems, target=target)
  class(result) <- c("FixedPartition", "partitionDistribution")
  result
}

#' @export
print.FixedPartition <- function(x, ...) {
  cat("\nFixed partition distribution\n\n")
  print(unclass(x))
}
