getOr <- function(x, or) {
  if ( is.null(x) ) or else x
}

seed4rust <- function() sapply(1:32, function(i) sample.int(256L,1L)-1L)

checkSimilarity <- function(similarity) {
  if ( ! is.matrix(similarity) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
  if ( ! isSymmetric(similarity) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
  if ( any( similarity <= 0 ) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
}

checkPermutation <- function(permutation) {
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  if ( ! is.vector(permutation) ) stop("'permutation' must a vector.")
  if ( ! all(permutation %% 1 == 0) ) stop("'permutation' must only contain integers.")
  n <- length(permutation)
  if ( ( min(permutation) < 1 ) || ( max(permutation) > n ) || ( length(unique(permutation)) != n ) ) stop("'permutation' is not a valid permutation.")
}

checkMassDiscount <- function(mass, discount) {
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
}

isCanonical <- function(labels) isCanonicalFromUnique(unique(labels))

isCanonicalFromUnique <- function(u) {
  if ( min(u) != 1L ) return(FALSE)
  if ( max(u) != length(u) ) return(FALSE)
  all(diff(u) > 0)
}

canonicalForm <- function(labels) {
  temp <- integer(length(labels))
  i <- 1
  for (s in unique(labels)) {
    temp[which(labels == s)] <- i
    i <- i + 1
  }
  temp
}

#' @useDynLib pumpkin .new_FixedPartitionParameters .free_FixedPartitionParameters
#' @useDynLib pumpkin .new_CRPParameters .free_CRPParameters
#' @useDynLib pumpkin .new_FRPParameters .free_FRPParameters
#' @useDynLib pumpkin .new_LSPParameters .free_LSPParameters
#' @useDynLib pumpkin .new_CPPParameters .free_CPPParameters
#' @useDynLib pumpkin .new_EPAParameters .free_EPAParameters
#'
partitionDispatch <- function(engine, distr, excluded=NULL) {
  stp <- function() stop(sprintf("'%s' is not supported.", class(distr)[1]))
  if ( ( ! is.null(excluded) ) && ( class(distr)[1] %in% excluded ) ) stp()
  if ( inherits(distr,"FixedPartition") ) {
    p <- .Call(.new_FixedPartitionParameters, distr$target)
    result <- engine(0, p)
    .Call(.free_FixedPartitionParameters, p)
    result
  } else if ( inherits(distr,"CRPPartition") ) {
    p <- .Call(.new_CRPParameters, distr$nItems, distr$mass, distr$discount)
    result <- engine(1, p)
    .Call(.free_CRPParameters, p)
    result
  } else if ( inherits(distr, "FocalPartition") ) {
    p <- .Call(.new_FRPParameters, distr$target, distr$weights, distr$permutation, FALSE, distr$mass, distr$discount, distr$power)
    result <- engine(2, p)
    .Call(.free_FRPParameters, p)
    result
  } else if ( inherits(distr, "LocationScalePartition") ) {
    p <- .Call(.new_LSPParameters, distr$target, distr$weight, distr$permutation, FALSE)
    result <- engine(3, p)
    .Call(.free_LSPParameters, p)
    result
  } else if ( inherits(distr, "CenteredPartition") ) {
    p <- .Call(.new_CPPParameters, distr$target, distr$weight, distr$mass, distr$discount, distr$useVI, distr$a)
    result <- engine(4, p)
    .Call(.free_CPPParameters, p)
    result
  } else if ( inherits(distr, "EPAPartition") ) {
    p <- .Call(.new_EPAParameters, distr$similarity, distr$permutation, FALSE, distr$mass, distr$discount)
    result <- engine(5, p)
    .Call(.free_EPAParameters, p)
    result
  } else stp()
}
