FixedPartition(target=c(1,1,1,2,2))
