#' Probabilities for the Chinese restaurant process (CRP) partition distribution
#'
#' This function evaluates the probability mass function of the Chinese
#' restaurant process (CRP) partition distribution for a given mass (a.k.a.,
#' concentration) parameter.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than zero.
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logorithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @examples
#' m <- 1.5
#' x <- rCRPPartition(10, 5, mass=m)
#' p <- dCRPPartition(x$partition, mass=m, log=TRUE)
#' all.equal(p, x$logProbability)
#'
#' @useDynLib pumpkin .bCRPPartition
#' @export
#'
dCRPPartition <- function(partition, mass, log=FALSE) {
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( missing(partition) ) {
    result <- list(name="CRP", mass=mass, logProbability=function(partition) dCRPPartition(partition, mass, TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  nItems <- ncol(partition)
  if ( nItems < 1 ) stop("The number of columns of 'partition' must be at least one.")
  logProbabilities <- .Call(.bCRPPartition, FALSE, partition, numeric(nSamples), 0L, mass)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Chinese restaurant process (CRP) partition distribution
#'
#' This function returns randomly sampled partitions from the Chinese restaurant
#' process (CRP) partition for a given mass (a.k.a., concentration) parameter.
#'
#' @param nSamples An integer giving the number of partitions to sample.
#' @param nItems An integer giving the number of items in each partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value.
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @examples
#' m <- 1.5
#' x <- rCRPPartition(10, 5, mass=m)
#' p <- dCRPPartition(x$partition, mass=m, log=TRUE)
#' all.equal(p, x$logProbability)
#'
#' @useDynLib pumpkin .bCRPPartition
#' @export
#'
rCRPPartition <- function(nSamples, nItems, mass) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  if ( nItems < 1 ) stop("The number of items must be at least one.")
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  partitions <- matrix(0L, nrow=nSamples, ncol=nItems)
  .Call(.bCRPPartition, TRUE, partitions, numeric(nSamples), seed4rust(), mass)
}
