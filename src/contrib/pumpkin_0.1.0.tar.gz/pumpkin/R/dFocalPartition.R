#' Probabilities for the focal partition distribution
#'
#' This function evaluates the probability mass function of the focal partition
#' distribution for given partition, weights, permutation, and mass (a.k.a.,
#' concentration) parameters.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param focal An integer vector giving the focal partition.
#' @param weights A numeric vector of length equal to the number of unique
#'   labels in \code{focal} (i.e., the number of subsets) giving the weight for
#'   each of the labels.  The first element of this vector corresponds to the
#'   subset with cluster label \code{0} and the last element corresponds to the
#'   subset with cluster label \code{k-1}, where \code{k} is the number of
#'   subsets.
#' @param permutation An vector of integers containing the integers 0, 1, ...,
#'   n-1 giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than zero.
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logorithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @examples
#' partition <- c(0,0,1,1,2)
#' focal <- c(0,0,0,1,1)
#' weights <- c(10,2)
#' permutation <- c(0,4,3,1,2)
#' mass <- 1.0
#'
#' dFocalPartition(partition, focal, weights, permutation, mass)
#' x <- rFocalPartition(100, focal, weights, permutation, mass, useRandomPermutation=FALSE)
#' p <- dFocalPartition(x$partition, focal, weights, permutation, mass, log=TRUE)
#' all.equal(p, x$logProbability)
#'
#' @useDynLib pumpkin .bFocalPartition
#' @export
#'
dFocalPartition <- function(partition, focal, weights, permutation, mass, log=FALSE) {
  nItems <- length(focal)
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  nSubsets <- length(unique(focal))
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nSubsets)
  else {
    if ( length(weights) != nSubsets ) stop("The length of 'weights' must be equal to the number of subsets in 'focal'.")
    if ( ! isCanonical(focal) ) stop("'focal' must be in canonical form when multiple weights are specified.")
  }
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'focal'.")
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( missing(partition) ) {
    result <- list(name="Focal", focal=focal, weights=weights, permutation=permutation, mass=mass,
                   logProbability=function(partition) dFocalPartition(partition, focal, weights, permutation, mass, log=TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != nItems ) stop("Length of 'partition' must equal the length of 'focal'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bFocalPartition, FALSE, partition, numeric(nSamples), 0L, focal, weights, permutation, mass, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the focal partition distribution
#'
#' This function returns randomly sampled partitions from the focal partition
#' distribution for given focal partition, weights, permutation, and mass
#' (a.k.a., concentration) parameters.
#'
#' @param nSamples An integer giving the number of partitions to sample.
#' @param focal An integer vector giving the focal partition.
#' @param weights A numeric vector of length equal to the number of unique
#'   labels in \code{focal} (i.e., the number of subsets) giving the weight for
#'   each of the labels.  The first element of this vector corresponds to the
#'   subset with cluster label \code{0} and the last element corresponds to the
#'   subset with cluster label \code{k-1}, where \code{k} is the number of
#'   subsets.
#' @param permutation An vector of integers containing the integers 0, 1, ...,
#'   n-1 giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than zero.
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @examples
#' partition <- c(0,0,1,1,2)
#' focal <- c(0,0,0,1,1)
#' weights <- c(10,2)
#' permutation <- c(0,4,3,1,2)
#' mass <- 1.0
#'
#' dFocalPartition(partition, focal, weights, permutation, mass)
#' x <- rFocalPartition(100, focal, weights, permutation, mass, useRandomPermutation=FALSE)
#' p <- dFocalPartition(x$partition, focal, weights, permutation, mass, log=TRUE)
#' all.equal(p, x$logProbability)
#'
#' @useDynLib pumpkin .bFocalPartition
#' @export
#'
rFocalPartition <- function(nSamples, focal, weights, permutation, mass, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  nItems <- length(focal)
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  nSubsets <- length(unique(focal))
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nSubsets)
  else {
    if ( length(weights) != nSubsets ) stop("The length of 'weights' must be equal to the number of subsets in 'focal'.")
    if ( ! isCanonical(focal) ) stop("'focal' must be in canonical form when multiple weights are specified.")
  }
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'focal'.")
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  partitions <- matrix(0L, nrow=nSamples, ncol=nItems)
  .Call(.bFocalPartition, TRUE, partitions, numeric(nSamples), seed4rust(), focal, weights, permutation, mass, useRandomPermutation)
}
