getOr <- function(x, or) {
  if ( is.null(x) ) or else x
}

seed4rust <- function() sapply(1:32, function(i) sample.int(256L,1L)-1L)

checkSimilarity <- function(similarity) {
  if ( ! is.matrix(similarity) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
  if ( ! isSymmetric(similarity) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
  if ( sum( similarity <= 0 ) ) stop("'similarity' must be a symmetric matrix of strictly positive enteries.")
}

checkPermutation <- function(permutation) {
  if ( ! is.vector(permutation) ) stop("'permutation' must a vector.")
  n <- length(permutation)
  if ( ( min(permutation) < 0 ) || ( max(permutation) > n-1 ) || ( length(unique(permutation)) != n ) ) stop("'permutation' is not a valid permutation.")
}

isCanonical <- function(labels) {
  u <- unique(labels)
  if ( min(u) != 0L ) return(FALSE)
  if ( max(u) != length(u)-1 ) return(FALSE)
  !any(diff(u) < 0)
}

canonicalForm <- function(labels) {
  temp <- integer(length(labels))
  i <- 0
  for (s in unique(labels)) {
    temp[which(labels == s)] <- i
    i <- i + 1
  }
  temp
}
