#' Probabilities for the Ewens-Pitman attraction (EPA) partition distribution
#'
#' This function evaluates the probability mass function of the Ewens-Pitman
#' attraction (EPA) partition distribution for given similarity, permutation,
#' mass (a.k.a., concentration), and discount parameters.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param similarity An n-by-n symmetric matrix giving the similarity between
#'   pairs of items.  Matrix enteries must be strictly positive.
#' @param permutation An vector of integers containing the integers 0, 1, ...,
#'   n-1 giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than zero.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logorithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @examples
#' partition <- c(0,0,1,1,2)
#' n <- length(partition)
#' subset <- c("Maine","Georgia","California","Minnesota","Montana")
#' d <- as.matrix(dist(USArrests[subset,]))
#' temperature <- 1.0
#' similarity <- exp( -temperature * d )
#' permutation <- 0:(n-1)
#' mass <- 1.0
#' discount <- 0.1
#'
#' x <- rEPAPartition(100, similarity, permutation, mass, discount, useRandomPermutation=FALSE)
#' p <- dEPAPartition(x$partition, similarity, permutation, mass, discount, log=TRUE)
#' all.equal(p, x$logProbability)
#'
#' @useDynLib pumpkin .bEPAPartition
#' @export
#'
dEPAPartition <- function(partition, similarity, permutation, mass, discount, log=FALSE) {
  checkSimilarity(similarity)
  checkPermutation(permutation)
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( length(permutation) != nrow(similarity) ) stop("Dimensionality in 'similarity' and 'permutation' are not compatible.")
  if ( missing(partition) ) {
    result <- list(name="EPA", similarity=similarity, permutation=permutation, mass=mass, discount=discount,
                   logProbability=function(partition) dEPAPartition(partition, similarity, permutation, mass, discount, TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != nrow(similarity) ) stop("Length of 'partition' must equal the number of rows of 'similarity'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.bEPAPartition, FALSE, partition, numeric(nSamples), 0L, similarity, permutation, mass, discount, FALSE)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Ewens-Pitman attraction (EPA) partition distribution
#'
#' This function returns randomly sampled partitions from the Ewens-Pitman
#' attraction (EPA) partition distribution for given similarity, permutation,
#' mass (a.k.a., concentration), and discount parameters.
#'
#' @param nSamples An integer giving the number of partitions to sample.
#' @param similarity An n-by-n symmetric matrix giving the similarity between
#'   pairs of items.  Matrix enteries must be strictly positive.
#' @param permutation An vector of integers containing the integers 0, 1, ...,
#'   n-1 giving the order in which items are allocated to the partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than zero.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param useRandomPermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @examples
#' partition <- c(0,0,1,1,2)
#' n <- length(partition)
#' subset <- c("Maine","Georgia","California","Minnesota","Montana")
#' d <- as.matrix(dist(USArrests[subset,]))
#' temperature <- 1.0
#' similarity <- exp( -temperature * d )
#' permutation <- 0:(n-1)
#' mass <- 1.0
#' discount <- 0.1
#'
#' x <- rEPAPartition(100, similarity, permutation, mass, discount, useRandomPermutation=FALSE)
#' p <- dEPAPartition(x$partition, similarity, permutation, mass, discount, log=TRUE)
#' all.equal(p, x$logProbability)
#'
#' @useDynLib pumpkin .bEPAPartition
#' @export
#'
rEPAPartition <- function(nSamples, similarity, permutation, mass, discount, useRandomPermutation=TRUE) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  checkSimilarity(similarity)
  checkPermutation(permutation)
  nItems <- length(permutation)
  if ( nItems != nrow(similarity) ) stop("Dimensionality in 'similarity' and 'permutation' are not compatible.")
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  partitions <- matrix(0L, nrow=nSamples, ncol=nItems)
  .Call(.bEPAPartition, TRUE, partitions, numeric(nSamples), seed4rust(), similarity, permutation, mass, discount, useRandomPermutation)
}
