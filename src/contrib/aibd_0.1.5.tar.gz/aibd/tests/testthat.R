library(testthat)

test_check("aibd")
