# Neal (2000) model and data
nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
mkLogPosteriorPredictiveOfItem <- function(data=nealData, sigma2=0.1^2, mu0=0, sigma02=1) {
  function(i, subset) {
    posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
    posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
    posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
    dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
  }
}

logLike <- mkLogPosteriorPredictiveOfItem()
partitionPrior <- dCRPPartition(mass=1.0)
partitionPrior <- dLocationScalePartition(location=c(1,1,1,1,1,2,2,2,2), rate=1/0.5,permutation=1:9)
partitionPrior <- dCenteredPartition(center=c(1,1,1,1,1,2,2,2,2), rate=2, mass=1.0)
partitionPrior <- dFocalPartition(focal=c(1,1,1,1,1,2,2,2,2), weights=2, permutation=1:9, mass=1.0)
mcmcTuning <- list(nUpdates=2)

nSamples <- 1000L
nAccepts <- nAttempts <- 0L
partitions <- matrix(1, nrow=nSamples, ncol=length(nealData))
for ( i in 2:nSamples ) {
  partitions[i,] <- nealAlgorithm3(partitions[i-1,], logLike, partitionPrior, mcmcTuning)$partition
}

nSubsets <- apply(partitions, 1, function(x) length(unique(x)))
mean(nSubsets)
sum(acf(nSubsets)$acf)-1   # Autocorrelation time

