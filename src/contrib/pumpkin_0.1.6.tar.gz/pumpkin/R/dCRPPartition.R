#' Probabilities for the Chinese Restaurant Process (CRP) Partition Distribution
#'
#' This function evaluates the probability mass function of the Chinese
#' restaurant process (CRP) partition distribution for given mass (a.k.a.,
#' concentration) and discount parameters.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logarithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/bCRPPartition.R
#' @useDynLib pumpkin .bCRPPartition
#' @export
#'
dCRPPartition <- function(partition, mass, discount=0, log=FALSE) {
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  if ( missing(partition) ) {
    result <- list(name="CRP", mass=mass, discount=discount, logProbability=function(partition) dCRPPartition(partition, mass, discount, TRUE))
    class(result) <- "partitionDistribution"
    return(result)
  }
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  nItems <- ncol(partition)
  if ( nItems < 1 ) stop("The number of columns of 'partition' must be at least one.")
  logProbabilities <- .Call(.bCRPPartition, FALSE, partition, numeric(nSamples), 0L, mass, discount)
  if (log) logProbabilities else exp(logProbabilities)
}

#' Samples from the Chinese Restaurant Process (CRP) Partition Distribution
#'
#' This function returns randomly sampled partitions from the Chinese restaurant
#' process (CRP) partition for given mass (a.k.a., concentration) and discount parameters.
#'
#' @param nSamples An integer giving the number of partitions to sample.
#' @param nItems An integer giving the number of items in each partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#'
#' @return A list having: a. an integer matrix containing a partition in each
#'   row in cluster label form, and b. a numeric vector of log probabilities for
#'   the associated partitions.
#'
#' @example man/examples/bCRPPartition.R
#' @useDynLib pumpkin .bCRPPartition
#' @export
#'
rCRPPartition <- function(nSamples, nItems, mass, discount=0) {
  if ( nSamples < 1 ) stop("The number of samples must be at least one.")
  if ( nItems < 1 ) stop("The number of items must be at least one.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  partitions <- matrix(0L, nrow=nSamples, ncol=nItems)
  .Call(.bCRPPartition, TRUE, partitions, numeric(nSamples), seed4rust(), mass, discount)
}
