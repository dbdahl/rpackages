context("sampling-frequencies-match-pmf")

test_that("dFocalPartition and rFocalPartition report the same probabilities.", {
  requireLevel(1)
  nItems <- 7
  nSamples <- 100000
  permutation <- sample(1:nItems)
  focal <- as.vector(rCRPPartition(1,nItems,runif(1,0.001,10))$partition)
  weights <- runif(length(unique(focal)),0,10)
  mass <- runif(1,0.0001,10)
  x <- rFocalPartition(nSamples, focal, permutation, weights, mass)
  y <- dFocalPartition(x$partition, focal, permutation, weights, mass, log=TRUE)
  expect(all.equal(x$logProbability, y), "Probabilities not equal.")
})

mkString <- function(partitions) {
  apply(partitions, 1, function(y) paste0(y, collapse=""))
}

test_that("Sampling from the focal partition distribution produces frequencies compability with the probabily mass function.", {
  requireLevel(3)
  confidenceLevel <- 0.90
  nItems <- 5
  nSamples <- 10000
  nReps <- 1000
  sampleSizeThreshold <- 15
  w <- rep(0.0, nReps)
  i <- 1
  while ( i <= nReps ) {
    permutation <- sample(1:nItems)
    focal <- as.vector(rCRPPartition(1,nItems,runif(1,0.001,10))$partition)
    weights <- runif(length(unique(focal)),0,10)
    mass <- runif(1,0.0001,10)
    x <- rFocalPartition(1, focal, permutation, weights, mass)
    theoretical <- exp(x$logProbability)
    if ( nSamples * theoretical < sampleSizeThreshold ) next
    target <- mkString(x$partition)
    x <- rFocalPartition(nSamples, focal, permutation, weights, mass)
    emperical <- mkString(x$partition)
    alphaStar <- sum(emperical==target)
    #cat(alphaStar,"\n")
    betaStar <- nSamples - alphaStar
    lower <- qbeta((1-confidenceLevel)/2, alphaStar, betaStar)
    upper <- qbeta(1-(1-confidenceLevel)/2, alphaStar, betaStar)
    w[i] <- ( lower <= theoretical ) && ( theoretical <= upper )
    i <- i + 1
  }
  coverage <- mean(w)
  expect_gte(coverage, confidenceLevel-3*confidenceLevel*(1-confidenceLevel)/nReps)
})
