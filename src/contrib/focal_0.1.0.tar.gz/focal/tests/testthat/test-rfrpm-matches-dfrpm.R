context("rfrpm-matches-dfrpm empirically")

numItems <- 4
nSamp <- 10000
allObs <- enumerate.partitions(numItems)
ms <- 4
wt <- 2

test_that("rfrpm-matches-dfrpm", {
  part <- as.integer(allObs[sample(1:nrow(allObs),1),]+1)
  sampObs <- rfocalpart(nSamples = nSamp, focal = listing(part-1), permutation = 1:numItems, weight = wt, mass = ms)
  expect_lt((mean(sapply(sampObs,function(x) identical(x,part)))-dfocalpart(partition = listing(part-1),focal = listing(part-1),weight = wt,mass = ms,log = FALSE)),0.02)
})
