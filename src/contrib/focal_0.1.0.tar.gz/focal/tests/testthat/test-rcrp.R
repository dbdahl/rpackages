context("crp-sampling")

nItems <- 5
mass <- 2
nSamples <- 10000

test_that("Check that the Rust implementation of sampling from the CRP using rfocalpart gives the correct expected number of subsets.", {
  x2 <- rfocalpart(nSamples, rep(0,nItems), weight=0, mass=mass, implementation="rust")
  library(shallot)
  mean <- nsubsets.average(ewens(mass(mass),nItems))
  expect_gte(t.test(apply(x2,1,max)+1, mu=mean)$p.value, 0.001)
})

