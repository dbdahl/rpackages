context("crp-pmf")

mass <- 2
numItem <- 5
library(salso)
allObs <- enumerate.partitions(numItem)

test_that("Check that CRP PMF sums to one", {
  requireLevel(1)
  expect_gte(sum(apply(allObs, 1, function(y) {
    x <- listing(y)
    dCRPPartition(x,mass,log = FALSE)
  })),0.995)
})

