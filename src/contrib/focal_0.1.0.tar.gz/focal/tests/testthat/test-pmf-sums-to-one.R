context("pmf-sums-to-one")

library(salso)
nItems <- 5
partitions <- enumerate.partitions(nItems)

permutations <- function(x, prefix = c()) {
  if(length(x) == 0 ) return(prefix)
  do.call(rbind, sapply(1:length(x), FUN = function(idx) permutations( x[-idx], c( prefix, x[idx])), simplify = FALSE))
}

test_that("Check that p.m.f. of the focal partition distribution sums to one for all permutations and focals, with random weights and mass.", {
  requireLevel(1)
  expect_equal(sum(apply(permutations(1:ncol(partitions)), 1, function(permutation) {
    sums <- apply(partitions, 1, function(focal) {
      mass <- runif(1, 0.0001, 10)
      weights <- runif(length(unique(focal)),0,10)
      sum(dFocalPartition(partitions, focal, permutation, weights, mass))
    })
    all.equal(sums, rep(1,length(sums)))
  }) == FALSE), 0)
})

test_that("Check that p.m.f. of the CRP partition distribution sums to one, with random mass.", {
  requireLevel(1)
  mass <- runif(1, 0.0001, 10)
  expect_equal(sum(dCRPPartition(partitions, mass)), 1)
})
