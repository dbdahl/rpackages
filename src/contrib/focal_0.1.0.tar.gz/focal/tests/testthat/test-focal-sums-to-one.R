context("focal-pmf")

numItems <- 4
ms <- 1
wt <- 0
allObs <- enumerate.partitions(numItems)

test_that("Check that focal PMF sums to one", {
  requireLevel(1)
  focal <- listing(allObs[sample(1:nrow(allObs),1),])
  expect_gte(sum(apply(allObs,1,function(y) {
    x <- listing(y)
    dfocalpart(x,focal,weight = wt,mass = ms,log = FALSE)
  })),0.983)
})

test_that("Check that Focal reduces to CRP", {
  requireLevel(1)
  part <- listing(allObs[sample(1:nrow(allObs),1),])
  expect_equal(dfocalpart(part,focal = part,weight = wt,mass = ms,log = FALSE),dCRPPartition(part,ms,log = FALSE))
})

