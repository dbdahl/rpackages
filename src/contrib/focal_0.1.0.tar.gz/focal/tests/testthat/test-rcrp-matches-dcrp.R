context("rcrp-matches-dcrp empirically")

numItems <- 4
nSamp <- 10000
allObs <- enumerate.partitions(numItems)
ms <- 4


test_that("rCRPPartition-match-dCRPPartition", {
  part <- listing(allObs[sample(1:nrow(allObs),1),])
  sampObs <- rCRPPartition(nSamp,nItems = numItems,alpha = ms)
  expect_lt(abs(mean(sapply(sampObs,function(x) isTRUE(all.equal(x,part))))-dCRPPartition(part,alpha = ms)),.05)
})
