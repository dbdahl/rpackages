library(testthat)
library(focal)

test_check("focal")
