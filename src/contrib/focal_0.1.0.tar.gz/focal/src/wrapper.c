#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

struct FocalPartitionSpecification {
  int n_items;
  int* focal;
  double* weights;
  int* permutation;
  double mass;
};

struct FocalPartitionSpecification mkFocalPartitionSpecification(SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp) {
  struct FocalPartitionSpecification fps;
  focal_sexp = PROTECT(Rf_coerceVector(focal_sexp, INTSXP));
  fps.n_items = Rf_length(focal_sexp);
  fps.focal = INTEGER(focal_sexp);
  weights_sexp = PROTECT(Rf_coerceVector(weights_sexp, REALSXP));
  fps.weights = REAL(weights_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  fps.permutation = INTEGER(permutation_sexp);
  fps.mass = Rf_asReal(mass_sexp);
  return fps;
}

// Actual Wrappers
SEXP rFocalPartition(SEXP n_partitions_sexp, SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp, SEXP use_random_permutations_sexp) {
  int n_partitions = Rf_asInteger(n_partitions_sexp);
  struct FocalPartitionSpecification fps = mkFocalPartitionSpecification(focal_sexp, weights_sexp, permutation_sexp, mass_sexp);
  SEXP partitions_sexp = PROTECT(Rf_allocMatrix(INTSXP, n_partitions, fps.n_items));
  int* partitions = INTEGER(partitions_sexp);
  SEXP probs_sexp = PROTECT(Rf_allocVector(REALSXP, n_partitions));
  double* probs = REAL(probs_sexp);
  int do_sampling = 1;
  int use_random_permutations = Rf_asLogical(use_random_permutations_sexp);
  dahl_randompartition__focal_partition(n_partitions, fps.n_items, fps.focal, fps.weights, fps.permutation, fps.mass, do_sampling, use_random_permutations, partitions, probs);
  SEXP results = PROTECT(Rf_allocVector(VECSXP, 2));
  SET_VECTOR_ELT(results, 0, partitions_sexp);
  SET_VECTOR_ELT(results, 1, probs_sexp);
  SEXP results_names = PROTECT(Rf_allocVector(STRSXP, 2));
  SET_STRING_ELT(results_names, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(results_names, 1, Rf_mkChar("logProbability"));
  Rf_namesgets(results, results_names);
  UNPROTECT(7);
  return results;
}

SEXP dFocalPartition(SEXP partitions_sexp, SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp) {
  int n_partitions = Rf_nrows(partitions_sexp);
  struct FocalPartitionSpecification fps = mkFocalPartitionSpecification(focal_sexp, weights_sexp, permutation_sexp, mass_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  SEXP probs_sexp = PROTECT(Rf_allocVector(REALSXP, n_partitions));
  double* probs = REAL(probs_sexp);
  int do_sampling = 0;
  int use_random_permutations = 0;
  dahl_randompartition__focal_partition(n_partitions, fps.n_items, fps.focal, fps.weights, fps.permutation, fps.mass, do_sampling, use_random_permutations, partitions, probs);
  UNPROTECT(5);
  return probs_sexp;
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
  {".rFocalPartition", (DL_FUNC) &rFocalPartition, 6},
  {".dFocalPartition", (DL_FUNC) &dFocalPartition, 5},
  {NULL, NULL, 0}
};

void R_init_focal(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
