#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

struct FocalPartitionSpecification {
  int n_items;
  int* focal;
  double* weights;
  int* permutation;
  double mass;
};

struct FocalPartitionSpecification mkFocalPartitionSpecification(SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp) {
  struct FocalPartitionSpecification fps;
  focal_sexp = PROTECT(Rf_coerceVector(focal_sexp, INTSXP));
  fps.n_items = Rf_length(focal_sexp);
  fps.focal = INTEGER(focal_sexp);
  weights_sexp = PROTECT(Rf_coerceVector(weights_sexp, REALSXP));
  fps.weights = REAL(weights_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  fps.permutation = INTEGER(permutation_sexp);
  fps.mass = Rf_asReal(mass_sexp);
  return fps;
}

// Actual Wrappers
RR_SEXP_vector_INTSXP rrAllocVectorINTSXP(int len) {
  RR_SEXP_vector_INTSXP s;
  s.sexp_ptr = (void*) PROTECT(Rf_allocVector(INTSXP, len));
  s.data_ptr = INTEGER((SEXP)s.sexp_ptr);
  s.len = len;
  return s;
}

double callRFunction_logIntegratedLikelihoodOfSubset(const void* fn_ptr, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP R_fcall = PROTECT(Rf_lang2(*(SEXP*)fn_ptr, R_NilValue));
  SETCADR(R_fcall, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(R_fcall, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

SEXP randomWalkFocalPartition(SEXP partition_sexp, SEXP logLikelihoodOfSubset_sexp, SEXP env_sexp, SEXP n_attempts_sexp, SEXP rate_sexp, SEXP mass_sexp) {
  if (!Rf_isFunction(logLikelihoodOfSubset_sexp)) Rf_error("'logLikelihoodOfSubset' must be a function.");
  void* logLikelihoodOfSubset_ptr = &logLikelihoodOfSubset_sexp;
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_attempts = Rf_asInteger(n_attempts_sexp);
  int rate = Rf_asReal(rate_sexp);
  int mass = Rf_asReal(mass_sexp);
  int n_accepts = 0;
  dahl_randompartition__mhrw_update(n_attempts, n_items, rate, mass, partition, logLikelihoodOfSubset_ptr, env_ptr, &n_accepts);
  SEXP results = PROTECT(Rf_allocVector(VECSXP, 3));
  SET_VECTOR_ELT(results, 0, partition_sexp);
  SET_VECTOR_ELT(results, 1, Rf_ScalarInteger(n_accepts));
  SET_VECTOR_ELT(results, 2, n_attempts_sexp);
  UNPROTECT(2);
  return results;
}

SEXP rFocalPartition(SEXP n_partitions_sexp, SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp, SEXP use_random_permutations_sexp) {
  int n_partitions = Rf_asInteger(n_partitions_sexp);
  struct FocalPartitionSpecification fps = mkFocalPartitionSpecification(focal_sexp, weights_sexp, permutation_sexp, mass_sexp);
  SEXP partitions_sexp = PROTECT(Rf_allocMatrix(INTSXP, n_partitions, fps.n_items));
  int* partitions = INTEGER(partitions_sexp);
  SEXP probs_sexp = PROTECT(Rf_allocVector(REALSXP, n_partitions));
  double* probs = REAL(probs_sexp);
  int do_sampling = 1;
  int use_random_permutations = Rf_asLogical(use_random_permutations_sexp);
  dahl_randompartition__focal_partition(n_partitions, fps.n_items, fps.focal, fps.weights, fps.permutation, fps.mass, do_sampling, use_random_permutations, partitions, probs);
  SEXP results = PROTECT(Rf_allocVector(VECSXP, 2));
  SET_VECTOR_ELT(results, 0, partitions_sexp);
  SET_VECTOR_ELT(results, 1, probs_sexp);
  SEXP results_names = PROTECT(Rf_allocVector(STRSXP, 2));
  SET_STRING_ELT(results_names, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(results_names, 1, Rf_mkChar("logProbability"));
  Rf_namesgets(results, results_names);
  UNPROTECT(7);
  return results;
}

SEXP dFocalPartition(SEXP partitions_sexp, SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp) {
  int n_partitions = Rf_nrows(partitions_sexp);
  struct FocalPartitionSpecification fps = mkFocalPartitionSpecification(focal_sexp, weights_sexp, permutation_sexp, mass_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  SEXP probs_sexp = PROTECT(Rf_allocVector(REALSXP, n_partitions));
  double* probs = REAL(probs_sexp);
  int do_sampling = 0;
  int use_random_permutations = 0;
  dahl_randompartition__focal_partition(n_partitions, fps.n_items, fps.focal, fps.weights, fps.permutation, fps.mass, do_sampling, use_random_permutations, partitions, probs);
  UNPROTECT(5);
  return probs_sexp;
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
  {".rFocalPartition", (DL_FUNC) &rFocalPartition, 6},
  {".dFocalPartition", (DL_FUNC) &dFocalPartition, 5},
  {".randomWalkFocalPartition", (DL_FUNC) &randomWalkFocalPartition, 6},
  {NULL, NULL, 0}
};

void R_init_focal(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
