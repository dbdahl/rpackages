#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

// Actual Wrappers
SEXP rFocalPartition(SEXP n_partitions_sexp, SEXP focal_sexp, SEXP weights_sexp, SEXP permutation_sexp, SEXP mass_sexp) {
  int n_partitions = Rf_asInteger(n_partitions_sexp);
  focal_sexp = PROTECT(Rf_coerceVector(focal_sexp, INTSXP));
  int n_items = Rf_length(focal_sexp);
  int* focal = INTEGER(focal_sexp);
  weights_sexp = PROTECT(Rf_coerceVector(weights_sexp, REALSXP));
  double* weights = REAL(weights_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  SEXP partitions_sexp = PROTECT(Rf_allocVector(INTSXP, n_partitions*n_items));
  int* partitions = INTEGER(partitions_sexp);
  dahl_randompartition__rfp__sample(n_partitions, n_items, focal, weights, permutation, mass, partitions);
  UNPROTECT(4);
  return partitions_sexp;
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
  {".rFocalPartition", (DL_FUNC) &rFocalPartition, 5},
  {NULL, NULL, 0}
};

void R_init_focal(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
