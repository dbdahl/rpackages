#' Generate random partitions centered on a supplied focal partition
#'
#' `rFocalPartition` Returns a list of list objects containing numeric vectors which represent focal clusterings
#'
#' This is a random focal partition generator.
#'
#' @param nSamples number of random focal partitionings
#' @param focal focal partition (list of numeric vectors)
#' @param permutation order of allocation
#' @param weight weight of certainty (numeric vector)
#' @param mass single number governing the number of subsets in each partitioning
#' @param asLabels logical (TRUE returns cluster labels)
#' @param implementation string, "R"
#'
#' @return Output will be a list of embedded lists of numeric vectors representing random focal allocations
#'
#' @examples
#' rFocalPartition(nSamples = 5, focal = list(c(1,2),3,4), permutation = 1:4,
#'            weight = 5, mass = 1, asLabels = FALSE)
#'
#' @export
#' @useDynLib focal .rfocalpart
#'
rFocalPartition <- function(nSamples, focal, permutation=NULL, weight=0, mass=1, asLabels=TRUE, implementation="R") {
  nSamples <- as.integer(nSamples[1])
  if ( nSamples < 1 ) stop("'nSamples' must be at least one.")
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( implementation=="R" ) {
    draws <- list()
    for ( s in 1:nSamples ) {
      partition <- list(integer(0))
      n <- sum(sapply(focal, length))
      permutatn <- if ( is.null(permutation) ) sample(1:n) else permutation
      for ( i in seq_along(permutatn) ) {
        k <- which(sapply(focal, function(subset) permutatn[i] %in% subset))
        focusedSubset <- focal[[k]]
        thisWeight <- if ( length(weight) > 1 ) weight[k] else weight
        if ( length(partition[[length(partition)]]) != 0 ) partition[[length(partition)+1]] <- integer(0)
        weights <- sapply(partition, function(subset) {
          if ( length(subset) == 0 ) {
            mass + thisWeight * ifelse(identical(intersect(focusedSubset,permutatn[1:i]),permutatn[i]),1,0)
          } else {
            length(subset) + thisWeight * length(intersect(subset,focusedSubset))/length(intersect(focusedSubset,permutatn[1:i]))
          }
        })
        k <- sample(seq_along(partition),1,prob=weights)
        partition[[k]] <- c(partition[[k]],permutatn[i])
      }
      if ( length(partition[[length(partition)]]) == 0 ) partition <- partition[1:(length(partition)-1)]
      if ( asLabels ) {
        labels <- integer(n)
        for ( k in 1:length(partition) ) labels[partition[[k]]] <- k
        draws[[s]] <- labels
      } else draws[[s]] <- partition
    }
    draws
  } else if ( implementation == "rust" ) {
    if ( ! is.null(permutation) ) stop("'permutation' must be NULL for the Rust implementation.")
    if ( length(weight) == 1 ) {
      weight <- rep(weight, length(focal))
    } else {
      warning("Careful... the focal partition should be in canonical form when cluster-specific weights are supplied!")
    }
    labels <- labeling(focal)
    matrix(.Call(.rfocalpart, nSamples, labels, weight, mass), nrow=nSamples)
  } else stop(paste0("Unsupported implementation: ",implementation))
}
