#' Generate random partitions centered on a supplied focal partition
#'
#' `rFocalPartition` Returns a matrix of cluster labels where each row represents a random draw from the focal partition distribution
#'
#' This is a random focal partition generator.
#'
#' @param nSamples Numeric value (length 1) to indicate the number of random samples desired
#' @param focal Focal partition represented as a numeric vector of cluster labels. Cluster labels may have either a base of 0 or 1.
#' @param weights Numeric vector of prior weights for input focal partition. Weights may either be a constant value which is applied to all clusters of the input focal partition, or a vector of length equal to the number of subsets in the input focal partition.
#' @param permutation Numeric vector of object labels which indicate the order of allocation of the items in the focal partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value.
#'
#' @return A matrix of cluster labels where each row represents a single independent draw from the focal partition distribution.
#'
#' @examples
#' rFocalPartition(nSamples = 5, focal = c(0,0,1,1), permutation = NULL, weights = 5, mass = 1)
#'
#' @export
#' @useDynLib focal .rFocalPartition
#'
rFocalPartition <- function(nSamples, focal, permutation=NULL, weights=0, mass=1) {
  nSamples <- as.integer(nSamples[1])
  if ( nSamples < 1 ) stop("'nSamples' must be at least one.")
  nItems <- length(focal)
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  nSubsets <- length(unique(focal))
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nSubsets)
  else {
    if ( length(weights) != nSubsets ) stop("The length of 'weights' must be equal to the number of subsets in 'focal'.")
    if ( ! isCanonical(focal) ) stop("'focal' must be in canonical form when multiple weights are specified.")
  }
  useRandomPermutations <- if ( ! is.null(permutation) ) {
    if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'focal'.")
    s <- sort(permutation)
    if ( ! all.equal(s, 1:nItems) ) stop("'permutation' is not a valid permutation.")
    permutation <- permutation - 1L
    FALSE
  } else TRUE
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  .Call(.rFocalPartition, nSamples, focal, weights, permutation, mass, useRandomPermutations)
}
