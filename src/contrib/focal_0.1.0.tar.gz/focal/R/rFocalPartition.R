#' Generate random partitions centered on a supplied focal partition
#'
#' `rFocalPartition` Returns a list of list objects containing numeric vectors which represent focal clusterings
#'
#' This is a random focal partition generator.
#'
#' @param nSamples number of random focal partitionings
#' @param focal focal partition (list of numeric vectors)
#' @param weights weights of certainty (numeric vector)
#' @param permutation order of allocation
#' @param mass single number governing the number of subsets in each partitioning
#' @param asLabels logical (TRUE returns cluster labels)
#' @param implementation string, "R"
#'
#' @return Output will be a list of embedded lists of numeric vectors representing random focal allocations
#'
#' @examples
#' rFocalPartition(nSamples = 5, focal = list(c(1,2),3,4), permutation = 1:4,
#'            weights = 5, mass = 1, asLabels = FALSE)
#'
#' @export
#' @useDynLib focal .rFocalPartition
#'
rFocalPartition <- function(nSamples, focal, weights=0, permutation=NULL, mass=1, asLabels=TRUE, implementation="R") {
  nSamples <- as.integer(nSamples[1])
  if ( nSamples < 1 ) stop("'nSamples' must be at least one.")
  labels <- subsetsToLabels(focal)
  if ( ! isCanonical(labels) ) stop("'focal' must be in canonical form.")
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, length(focal))
  if ( ! is.null(permutation) ) {
    nItems <- length(labels)
    if ( length(permutation) != nItems ) stop(sprintf("Based on the 'focal' arugument, the length of 'permutation' should be %s.",nItems))
    s <- sort(permutation)
    if ( ! identical(s,1L:nItems) ) stop("'permutation' is not a valid permutation.")
  }
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  if ( implementation=="R" ) {
    draws <- matrix(nrow = 0, ncol = nItems)
    for ( s in 1:nSamples ) {
      partition <- list(integer(0))
      n <- sum(sapply(focal, length))
      permutatn <- if ( is.null(permutation) ) sample(1:n) else permutation
      for ( i in seq_along(permutatn) ) {
        k <- which(sapply(focal, function(subset) permutatn[i] %in% subset))
        focusedSubset <- focal[[k]]
        thisWeight <- weights[k]
        if ( length(partition[[length(partition)]]) != 0 ) partition[[length(partition)+1]] <- integer(0)
        prob <- sapply(partition, function(subset) {
          if ( length(subset) == 0 ) {
            mass + thisWeight * ifelse(identical(intersect(focusedSubset,permutatn[1:i]),permutatn[i]),1,0)
          } else {
            length(subset) + thisWeight * length(intersect(subset,focusedSubset))/length(intersect(focusedSubset,permutatn[1:i]))
          }
        })
        k <- sample(seq_along(partition),1,prob=prob)
        partition[[k]] <- c(partition[[k]],permutatn[i])
      }
      if ( length(partition[[length(partition)]]) == 0 ) partition <- partition[1:(length(partition)-1)]
      labels <- integer(n)
      for ( k in 1:length(partition) ) labels[partition[[k]]] <- k
      canonicalLabels <- canonicalForm(labels)
      draws <- rbind(draws,canonicalLabels)
    }
    draws
  } else if ( implementation == "rust" ) {
    permutation <- if ( is.null(permutation) ) rep(-1L, length(labels)) else permutation - 1L
    matrix(.Call(.rFocalPartition, nSamples, labels, weights, permutation, mass), nrow=nSamples)
  } else stop(paste0("Unsupported implementation: ",implementation))
}
