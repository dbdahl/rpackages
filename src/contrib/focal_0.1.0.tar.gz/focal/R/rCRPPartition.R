#' Generate a random Chinese Restaurant Process partition with a given number of items.
#'
#' @param nSamples The number of partition samples to obtain.
#' @param nItems The number of items to be in the partitioning.
#' @param mass Mass parameter which scales the allocation of items.
#'
#' @return A random partitioning of the supplied number of items.
#' @export
#'
#' @examples
#' rCRPPartition(10, 5, 1)
#'
rCRPPartition <- function(nSamples, nItems, mass) {
  nSamples <- as.integer(nSamples[1])
  if ( nSamples < 1 ) stop("'nSamples' must be at least one.")
  nItems <- as.integer(nItems[1])
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  focal <- rep(0L, nItems)
  weights <- 0.0
  useRandomPermutations <- FALSE
  permutation <- 0L:(nItems-1L)
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  .Call(.rFocalPartition, nSamples, focal, weights, permutation, mass, useRandomPermutations)
}
