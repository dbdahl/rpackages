#' Generate a random Chinese Restaurant Process partition with a given number of items.
#'
#' @param nSamples The number of partition samples to obtain.
#' @param nItems The number of items to be in the partitioning.
#' @param alpha Mass parameter which scales the allocation of items.
#' @param label If TRUE, returns the partitioning as a numeric vector where the values indicate which piece of the partition that item belongs to.
#'
#' @return A random partitioning of the supplied number of items.
#' @export
#'
#' @examples
#' rCRPPartition(10, nItems= 10, alpha = 1, label = TRUE)

rCRPPartition <- function(nSamples, nItems, alpha, label = FALSE) {
  if ( is.na(nItems) | is.nan(nItems) | length(nItems) > 1 | nItems < 1 ) {
    stop("nItems is misspecified")
  }
  if ( is.na(alpha) | is.nan(alpha) | length(alpha) > 1 ) {
    stop("nItems is misspecified")
  }
  storeSamps <- list()
  for ( j in 1:nSamples ) {
    n <- 0                  #Initialize at zero to increment in loop
    tables <- list()
    nCustPerTable <- alpha  #Becomes a vector of size length(tables) for each table's weight, alpha always remains in the first value because 0 represents a new table
    for ( i in 1:nItems ) {
      newSeat <- sample(0:length(tables), size = 1, prob = nCustPerTable/(n + alpha))
      n <- n + 1
      #Create new table
      if ( newSeat == 0 ) {
        newtable <- n
        tables <- c(tables, newtable) #append the new table at the end
        nCustPerTable <- c(nCustPerTable, 1) #add the new item to that table
      } else { ## Leave existing tables
        tables[[ newSeat ]] <- c(tables[[ newSeat ]], n) #append n because n represents the customer index
        nCustPerTable[ newSeat + 1 ] <- nCustPerTable[ newSeat + 1 ] + 1 # Leave alpha alone at first value
      }
    }
    storeSamps[[ j ]] <- if ( label == FALSE ) tables else labeling(tables) #labeling (within `internal-utils.R`) returns cluster labels
  }
  storeSamps
}


rCRPPartition <- function(nSamples, nItems, alpha, label = FALSE) {

  tables <- matrix(nrow = 0, ncol = nItems)
  n <- 0

  for ( i in 1:nItems ) {
    sample(0:1)

  }

}
