#' Generate a random Chinese Restaurant Process partition with a given number of items.
#'
#' @param nSamples The number of partition samples to obtain.
#' @param nItems The number of items to be in the partitioning.
#' @param mass Mass parameter which scales the allocation of items.
#'
#' @return A random partitioning of the supplied number of items.
#' @export
#'
#' @examples
#' rCRPPartition(10, nItems= 10, mass = 1)
#'

rCRPPartition <- function(nSamples, nItems, mass) {
  if ( is.na(nItems) | is.nan(nItems) | length(nItems) > 1 | nItems < 1 ) {
    stop("nItems is misspecified")
  }
  if ( is.na(mass) | is.nan(mass) | length(mass) > 1 ) {
    stop("nItems is misspecified")
  }
  allDraws <- matrix(nrow = 0, ncol = nItems)
  for ( j in 1:nSamples ) {
    n <- 0
    tables <- integer(0)
    nTable <- 0
    nPerTable <- mass
    for ( i in 1:nItems ) {
      newObs <- sample(0:nTable, size = 1, prob = nPerTable/(n + mass))
      n <- n + 1
      if ( !(newObs %in% tables) ) {
        nTable <- nTable + 1
        nPerTable <- c(1, nPerTable)
      } else {
        nPerTable[newObs+1] <- nPerTable[newObs+1] + 1
      }
      tables <- c(tables, newObs)
    }
    allDraws <- rbind(allDraws, unname(tables))
  }
  allDraws
}


#rCRPPartition <- function(nSamples, nItems, alpha, label = FALSE) {
#  if ( is.na(nItems) | is.nan(nItems) | length(nItems) > 1 | nItems < 1 ) {
#    stop("nItems is misspecified")
#  }
#  if ( is.na(alpha) | is.nan(alpha) | length(alpha) > 1 ) {
#    stop("nItems is misspecified")
#  }
#  storeSamps <- list()
#  for ( j in 1:nSamples ) {
#    n <- 0                  #Initialize at zero to increment in loop
#    tables <- list()
#    nCustPerTable <- alpha  #Becomes a vector of size length(tables) for each #table's weight, alpha always remains in the first value because 0 represents a new #table
#    for ( i in 1:nItems ) {
#      newSeat <- sample(0:length(tables), size = 1, prob = nCustPerTable/(n + alpha#))
#      n <- n + 1
#      #Create new table
#      if ( newSeat == 0 ) {
#        newtable <- n
#        tables <- c(tables, newtable) #append the new table at the end
#        nCustPerTable <- c(nCustPerTable, 1) #add the new item to that table
#      } else { ## Leave existing tables
#        tables[[ newSeat ]] <- c(tables[[ newSeat ]], n) #append n because n #represents the customer index
#        nCustPerTable[ newSeat + 1 ] <- nCustPerTable[ newSeat + 1 ] + 1 # Leave #alpha alone at first value
#      }
#    }
#    storeSamps[[ j ]] <- if ( label == FALSE ) tables else labeling(tables) ##labeling (within `internal-utils.R`) returns cluster labels
#  }
#  storeSamps
#}
#
