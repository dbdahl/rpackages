#' Generate a random Chinese Restaurant Process partition with a given number of items and supplied mass parameter.
#'
#' @param nSamples Numeric value (length 1) to indicate the number of random samples desired
#' @param nItems Numeric value (length 1) to indicate the number of items to be allocated in the CRP partitioning.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value.
#'
#' @return A list where the first item is a matrix of cluster labels with each row representing a single independent draw from the CRP partition distribution and the second item is the associated log probability of observing each random draw.
#'
#' @examples
#' rCRPPartition(10, nItems = 5, mass = 1)
#'
#' @export
#'
rCRPPartition <- function(nSamples, nItems, mass) {
  nSamples <- as.integer(nSamples[1])
  if ( nSamples < 1 ) stop("'nSamples' must be at least one.")
  nItems <- as.integer(nItems[1])
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  focal <- rep(0L, nItems)
  weights <- 0.0
  useRandomPermutations <- FALSE
  permutation <- 0L:(nItems-1L)
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  .Call(.rFocalPartition, nSamples, focal, weights, permutation, mass, useRandomPermutations)
}
