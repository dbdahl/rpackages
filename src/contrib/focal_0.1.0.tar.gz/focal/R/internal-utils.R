listing <- function(x) {
  list <- lapply(unique(x)+1, function(x) integer(0))
  for (i in 1:length(x)) list[[x[i]+1]] <- c(list[[x[i]+1]], i)
  list
}

Labels2List <- function(label) {
 uniqueClusters <- length(unique(label))
 list <- lapply(1:uniqueClusters, function(x) integer(0))
 for ( i in 1:length(label) ) list[[label[i]+1]] <- c(list[[label[i]+1]], i)
 list
}

obsTogether <- function(obs,partitions) {
 apply(partitions,1,function(y) {
   lab <- y[obs[1]]
   all(sapply(obs, function(z) y[z] == lab))
 })
}

labeling <- function(x) {
  label <- numeric(length(Reduce(c,x)))
  for (j in 1:length(x)) {
    label[x[[j]]] <- j
  }
  label
}

isCanonical <- function(labels) {
  u <- unique(labels)
  if ( min(u) != 0L ) return(FALSE)
  if ( max(u) != length(u)-1 ) return(FALSE)
  !any(diff(u) < 0)
}

subsetsToLabels <- function(subsets) {
  labels <- integer(length(subsets))
  i <- 0
  for ( subset in subsets ) {
    labels[subset] <- i
    i <- i + 1
  }
  labels
}

canonicalForm <- function(labels) {
  temp <- integer(length(labels))
  i <- 0
  for (s in unique(labels)) {
    temp[which(labels == s)] <- i
    i <- i + 1
  }
  temp
}





