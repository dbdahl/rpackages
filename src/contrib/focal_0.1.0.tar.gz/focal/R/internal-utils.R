isCanonical <- function(labels) {
  u <- unique(labels)
  if ( min(u) != 0L ) return(FALSE)
  if ( max(u) != length(u)-1 ) return(FALSE)
  !any(diff(u) < 0)
}

canonicalForm <- function(labels) {
  temp <- integer(length(labels))
  i <- 0
  for (s in unique(labels)) {
    temp[which(labels == s)] <- i
    i <- i + 1
  }
  temp
}
