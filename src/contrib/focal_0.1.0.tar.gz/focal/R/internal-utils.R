listing <- function(x) {
  list <- lapply(unique(x)+1, function(x) integer(0))
  for (i in 1:length(x)) list[[x[i]+1]] <- c(list[[x[i]+1]], i)
  list
}

Labels2List <- function(label) {
 uniqueClusters <- length(unique(label))
 list <- lapply(1:uniqueClusters, function(x) integer(0))
 for ( i in 1:length(label) ) list[[label[i]+1]] <- c(list[[label[i]+1]], i)
 list
}

obsTogether <- function(obs,partitions) {
 apply(partitions,1,function(y) {
   lab <- y[obs[1]]
   all(sapply(obs, function(z) y[z] == lab))
 })
}

labeling <- function(x) {
  label <- numeric(length(Reduce(c,x)))
  for (j in 1:length(x)) {
    label[x[[j]]] <- j
  }
  label
}
