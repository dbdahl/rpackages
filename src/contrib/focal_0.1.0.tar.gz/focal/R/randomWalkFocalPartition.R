#' Random Walk Update of a Partition
#'
#' This function performs a random walk update for a partition using the focal partition distribution for proposals.  The current
#' partition serves as the focal partition and \code{rate} providing a tuning parameter (analogous to a precision parameter
#' for a Gaussian random walk for a real-valued parameter.)
#'
#' @param partition A numeric vector of cluster labels representing the current partition.
#' @param logLikelihoodOfSubset A function taking a subset of integers (as a numeric vector) and returning the natural logarithm of that subset's contribution to the integrated likelihood.  The default value "turns off" the likelihood, resulting in prior simulation (rather than posterior simulation).
#' @param priorDistribution A specification of the prior partition distribution as returned by a function such as \code{\link{dCRPPartition}}.
#' @param nAttempts An integer giving the number of MCMC updates attempted before returning.  This has the effect of thinning the Markov chain.
#' @param rate A scalar providing the tuning parameter for the random walk proposals.  This value is analogous to a precision parameter for a Gaussian random walk for a real-valued parameter.
#'
#' @return A list of the following elements: \describe{ \item{partition}{An
#'   integer vector giving the updated partition encoded using cluster labels.}
#'   \item{nAccepts}{The number of proposals that were accepted.}
#'   \item{nAttempts}{The number of proposals that were attempted.}
#'   }
#'
#' @export
#' @useDynLib focal .randomWalkFocalPartition
#' @examples
#' # Neal (2000) model and data
#' nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
#' mkLogIntegratedLikelihoodOfItem <- function(data=nealData, sigma2=0.1^2, mu0=0, sigma02=1) {
#'   function(i, subset) {
#'     posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
#'     posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
#'     posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
#'     dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
#'   }
#' }
#'
#' mkLogIntegratedLikelihoodOfSubset <- function(f) {
#'   function(subset) sum(sapply(seq_along(subset), function(j) f(subset[j], subset[seq_len(j-1)])))
#' }
#'
#' logLike <- mkLogIntegratedLikelihoodOfSubset(mkLogIntegratedLikelihoodOfItem())
#' partitionPrior <- dCRPPartition(mass=1.0)
#'
#' nSamples <- 1000L
#' nAccepts <- nAttempts <- 0L
#' partitions <- matrix(0, nrow=nSamples, ncol=length(nealData))
#' for ( i in 2:nSamples ) {
#'   x <- randomWalkFocalPartition(partitions[i-1,], logLike, partitionPrior, nAttempts=2, rate=20)
#'   partitions[i,] <- x$partition
#'   nAccepts  <- nAccepts  + x$nAccepts
#'   nAttempts <- nAttempts + x$nAttempts
#' }
#'
#' nSubsets <- apply(partitions, 1, function(x) length(unique(x)))
#' mean(nSubsets)
#' nAccepts/nAttempts         # Acceptance rate
#' sum(acf(nSubsets)$acf)-1   # Autocorrelation time
#'
randomWalkFocalPartition <- function(partition, logLikelihoodOfSubset=function(subset) 0.0, priorDistribution=dCRPPartition(mass=1.0), nAttempts=1, rate=2.0) {
  if ( rate < 0.0) stop("'rate' must be nonnegative.")
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  if ( priorDistribution$name != "CRP" ) {
    stop(sprintf("'%s' is not supported.",priorDistribution$name))
  }
  if ( is.list(partition) ) partition <- partition$partition
  result <- .Call(.randomWalkFocalPartition, partition, logLikelihoodOfSubset, environment(), nAttempts, rate, priorDistribution$mass)
  names(result) <- c("partition","nAccepts","nAttempts")
  result
}
