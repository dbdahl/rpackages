#' Calculate the probability mass of a Chinese Restaurant Process partition
#'
#' @param partition The observed partition for which the probability mass is to be calculated
#' @param mass The mass variable to control the spread of the allocation
#' @param log log = TRUE returns a log probability
#'
#' @return Probability mass of a supplied Chinese Restaurant Process partition
#' @export
#'
#' @examples
#' dCRPPartition(list(c(1,2),c(3,4)), mass = 2)

dCRPPartition <- function(partition, mass, log=FALSE) {
  if ( !(is.list(partition) | is.numeric(partition)) | as.logical(prod(is.na(partition))) | length(partition) < 1 ) {
    stop("partition must be a list or numeric vector")
  }
  if ( is.na(mass) | is.nan(mass) | missing(mass) | length(mass) != 1 ) {
    stop("'mass' is misspecified")
  }
  if ( is.integer(partition) | is.numeric(partition) | is.double(partition) ) {
      partition <- labeling(partition)
  }
  n <- 0                                       #initialize n at 0 to be incremented in loop
  lnumer <- log(mass) * length(partition)     #On log scale to avoid divide by 0, log(mass) * length(partition) because there are as many masses multiplied in the numerator as there are tables in the clustering because P(new table) = mass/(n+mass)
  for ( i in 1:length(partition) ) {
    if ( length(partition[[ i ]]) >= 2 ) {  #Counting the number of values allocated to each table with 2+ items
      n <- n + length(partition[[ i ]])     #Increment n by how many items are on each table
      lnumer <- lnumer + lfactorial(length(partition[[ i ]]) - 1) #lfactorial because the probability mass numerator contains 1,2,...,n for n items on each table
    } else {
      n <- n + 1                            #For the scenario that partition[[ i ]] has length 1
      next                                  #Don't multiply into numerator because mass is in the numerator for this value.
    }
  }
  ldenom <- sum(log(sapply(0:(n - 1), function(x) x + mass))) #Create the denominator, because of associativity of multiplication, the ordering does not matter.
  if ( log == FALSE) {
    return( exp(lnumer - ldenom) )
  } else {
    return( lnumer - ldenom )
  }
}
