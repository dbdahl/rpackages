#' Calculate the probability mass of a Chinese Restaurant Process partition
#'
#' @param partitions The observed partition for which the probability mass is to be calculated
#' @param mass The mass variable to control the spread of the allocation
#' @param log log = TRUE returns a log probability
#'
#' @return Probability mass of a supplied Chinese Restaurant Process partition
#' @export
#'
#' @examples
#' dCRPPartition(partitions = c(0,0,1,0), mass = 1)
#'
dCRPPartition <- function(partitions, mass, log=FALSE) {
  if ( ! is.matrix(partitions) ) partitions <- matrix(partitions, nrow=1)
  nSamples <- nrow(partitions)
  if ( nSamples < 1 ) stop("The number of rows of 'partitions' must be at least one.")
  nItems <- ncol(partitions)
  if ( nItems < 1 ) stop("The number of columns of 'partitions' must be at least one.")
  focal <- rep(0L, nItems)
  weights <- 0.0
  permutation <- 0L:(nItems-1L)
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  result <- .Call(.dFocalPartition, partitions, focal, weights, permutation, mass)
  if (log) result else exp(result)
}
