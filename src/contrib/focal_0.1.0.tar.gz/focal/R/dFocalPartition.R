#' Focal partition probability mass function
#'
#' `dFocalPartition`` This function computes the probabiilty mass of a partition using the focal partition distribution.
#'
#' This is a probability mass function for an observed random focal partitioning
#'
#' @param partitions a list of numeric vectors representing the observed partitioning
#' @param focal a list of numeric vectors representing the expected focal partitioning
#' @param permutation a numeric vector representing the order of allocation
#' @param weights a single integer or integer vector representing the weights of certainty for a given subset
#' @param mass a single integer to govern the number of subsets in a given partitioning
#' @param log logical, TRUE returns the log probability
#'
#' @return Probability mass of observing supplied partition given supplied focal partition.
#'
#' @examples
#' dFocalPartition(partitions = c(0,0,1,0), focal = c(0,0,1,1), permutation = 1:4,
#'                 weights = 5, mass = 1)
#' dFocalPartition(partitions = c(0,0,1,0), focal = c(0,0,1,1), permutation = c(3,2,4,1),
#'                 weights = 5, mass = 1)
#'
#' @export
#' @useDynLib focal .dFocalPartition
#'
dFocalPartition <- function(partitions, focal, permutation, weights=0, mass=1, log=FALSE) {
  if ( ! is.matrix(partitions) ) partitions <- matrix(partitions, nrow=1)
  nSamples <- nrow(partitions)
  if ( nSamples < 1 ) stop("Number of rows of 'partitions' must be at least one.")
  nItems <- length(focal)
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  nSubsets <- length(unique(focal))
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nSubsets)
  else {
    if ( length(weights) != nSubsets ) stop("The length of 'weights' must be equal to the number of subsets in 'focal'.")
    if ( ! isCanonical(focal) ) stop("'focal' must be in canonical form when multiple weights are specified.")
  }
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'focal'.")
  s <- sort(permutation)
  if ( ! all.equal(s, 1:nItems) ) stop("'permutation' is not a valid permutation.")
  permutation <- permutation - 1L
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  result <- .Call(.dFocalPartition, partitions, focal, weights, permutation, mass)
  if (log) result else exp(result)
}
