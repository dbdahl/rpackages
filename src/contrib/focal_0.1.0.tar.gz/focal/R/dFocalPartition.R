#' Focal partition probability mass function
#'
#' `dFocalPartition`` This function computes the probabiilty mass of a partition from the focal partition distribution.
#'
#' This is the probability mass function for partitions from the focal partition distribution under all specified weights, mass, and other conditionings.
#'
#' @param partitions Supplied in the form of a matrix containing partition samples per each row where cluster labels are input and must be in canonical form with base 0.
#' @param focal Focal partition represented as a numeric vector of cluster labels. Cluster labels must be presented in canoncial form with base 0.
#' @param permutation Numeric vector of item labels which indicate the order of allocation of the items in the focal partition. The permutation vector must only include values 1 to n (number of items in focal).
#' @param weights Numeric vector of prior weights for input focal partition. Weights may either be a constant value which is applied to all clusters of the input focal partition, or a vector of length equal to the number of clusters in the input focal partition.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value.
#' @param log Logical. log = TRUE returns a log probability
#'
#' @return Probability mass of observing supplied partition from the focal partition distribution under all specified weights, mass, and other conditionings.
#'
#' @examples
#' dFocalPartition(c(0,0,1,0), focal = c(0,0,1,1), permutation = 1:4,
#'                 weights = 5, mass = 1)
#' dFocalPartition(c(0,0,1,0), focal = c(0,0,1,1), permutation = c(3,2,4,1),
#'                 weights = 5, mass = 1)
#'
#' @export
#' @useDynLib focal .dFocalPartition
#'
dFocalPartition <- function(partitions, focal, permutation, weights=0, mass=1, log=FALSE) {
  if ( ! is.matrix(partitions) ) partitions <- matrix(partitions, nrow=1)
  nSamples <- nrow(partitions)
  if ( nSamples < 1 ) stop("Number of rows of 'partitions' must be at least one.")
  nItems <- length(focal)
  if ( nItems < 1 ) stop("The number of items in 'focal' must be at least one.")
  nSubsets <- length(unique(focal))
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nSubsets)
  else {
    if ( length(weights) != nSubsets ) stop("The length of 'weights' must be equal to the number of subsets in 'focal'.")
    if ( ! isCanonical(focal) ) stop("'focal' must be in canonical form when multiple weights are specified.")
  }
  if ( is.null(permutation) ) stop("'permutation' must be non-null.")
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'focal'.")
  s <- sort(permutation)
  if ( ! all.equal(s, 1:nItems) ) stop("'permutation' is not a valid permutation.")
  permutation <- permutation - 1L
  mass <- as.double(mass[1])
  if ( mass <= 0.0 ) stop("'mass' must be strictly positive.")
  result <- .Call(.dFocalPartition, partitions, focal, weights, permutation, mass)
  if (log) result else exp(result)
}
