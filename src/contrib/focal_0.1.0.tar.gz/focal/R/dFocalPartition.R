#' Focal partition probability mass function
#'
#' `dFocalPartition`` This function computes the probabiilty mass of a partition using the focal partition distribution.
#'
#' This is a probability mass function for an observed random focal partitioning
#'
#' @param partition a list of numeric vectors representing the observed partitioning
#' @param focal a list of numeric vectors representing the expected focal partitioning
#' @param permutation a numeric vector representing the order of allocation
#' @param weight a single integer or integer vector representing the weights of certainty for a given subset
#' @param mass a single integer to govern the number of subsets in a given partitioning
#' @param log logical, TRUE returns the log probability
#'
#' @return Probability mass of observing supplied partition given supplied focal partition.
#'
#' @examples
#' dFocalPartition(partition = list(c(1,2,3),4), focal = list(c(1,2),3,4),
#'            permutation = 1:4, weight = c(10,2,3), mass = 1, log = FALSE)
#'
#' @export
#'
#'
dFocalPartition <- function(partition, focal, permutation=NULL, weight=0, mass=1, log=FALSE) {
  partition <- if ( !is.list(partition) ) listing(partition) else partition
  focal <- if ( !is.list(focal) ) listing(focal) else focal
  perm <- if ( is.null(permutation) ) sort(Reduce(c,partition)) else permutation
  prob <- c()
  for ( i in 1:length(perm) ) {
    k <- which(sapply(focal, function(subset) perm[i] %in% subset))
    focalSub <- focal[[k]]
    partSub <- partition[[which(sapply(partition, function(subset) perm[i] %in% subset))]]
    if ( length(weight) > 1 ) wt <- weight[k] else wt <- weight
    if ( identical(intersect(partSub, perm[1:i]), perm[i]) ) {
      numer <- mass + wt*ifelse(identical(intersect(focalSub, perm[1:i]), perm[i]),1,0)
    } else {
      numer <- length(intersect(partSub, perm[1:(i-1)])) + wt * length(intersect(intersect(focalSub, perm[1:(i-1)]), partSub))/length(intersect(focalSub, perm[1:i]))
    }
    top <- length(intersect(focalSub,perm[1:i]))-1
    denom <- length(perm[1:i]) - 1 + (wt/length(intersect(focalSub,perm[1:i])))*top + wt*ifelse(identical(intersect(focalSub, perm[1:i]), perm[i]),1,0) + mass
    prob[i] <- log(numer)-log(denom)
  }
  result <- sum(prob)
  if (log) result else exp(result)
}

