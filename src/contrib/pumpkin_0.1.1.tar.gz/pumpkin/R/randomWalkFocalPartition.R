#' Random Walk Update for a Partition
#'
#' This function performs a random walk update for a partition using the focal
#' partition distribution for proposals.  The current partition serves as the
#' focal partition and \code{rate} providing a tuning parameter (analogous to a
#' precision parameter for a Gaussian random walk for a real-valued parameter.)
#'
#' @param partition A numeric vector of cluster labels representing the current
#'   partition.
#' @param rate A scalar providing the tuning parameter for the random walk
#'   proposals.  This value is analogous to a precision parameter for a Gaussian
#'   random walk for a real-valued parameter.
#' @param mass A scalar providing the tuning parameter for the random walk
#'   proposals.  This value is a mass parameter for the focal random partition
#'   distribution proposal.
#' @param logLikelihoodOfSubset A function taking a subset of integers (as a
#'   numeric vector) and returning the natural logarithm of that subset's
#'   contribution to the integrated likelihood.  The default value "turns off"
#'   the likelihood, resulting in prior simulation (rather than posterior
#'   simulation).
#' @param priorDistribution A specification of the prior partition distribution,
#'   as returned by a function such as \code{\link{dCRPPartition}}.
#' @param nAttempts An integer giving the number of MCMC updates attempted
#'   before returning.  This has the effect of thinning the Markov chain.
#'
#' @return A list of the following elements: \describe{ \item{partition}{An
#'   integer vector giving the updated partition encoded using cluster labels.}
#'   \item{nAccepts}{The number of proposals that were accepted.}
#'   \item{nAttempts}{The number of proposals that were attempted.} }
#'
#' @export
#' @useDynLib pumpkin .randomWalkFocalPartition_CRP
#'   .randomWalkFocalPartition_FRP
#' @examples
#' # Neal (2000) model and data
#' nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
#' mkLogIntegratedLikelihoodOfItem <- function(data=nealData, sigma2=0.1^2, mu0=0, sigma02=1) {
#'   function(i, subset) {
#'     posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
#'     posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
#'     posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
#'     dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
#'   }
#' }
#'
#' mkLogIntegratedLikelihoodOfSubset <- function(f) {
#'   function(subset) sum(sapply(seq_along(subset), function(j) f(subset[j], subset[seq_len(j-1)])))
#' }
#'
#' logLike <- mkLogIntegratedLikelihoodOfSubset(mkLogIntegratedLikelihoodOfItem())
#' partitionPrior <- dFocalPartition(focal=rep(0,length(nealData)), weights=0, mass=1.0,
#'                                   permutation=(1:length(nealData))-1L)
#' partitionPrior <- dCRPPartition(mass=1.0)
#'
#' nSamples <- 1000L
#' nAccepts <- nAttempts <- 0L
#' partitions <- matrix(1, nrow=nSamples, ncol=length(nealData))
#' for ( i in 2:nSamples ) {
#'   x <- randomWalkFocalPartition(partitions[i-1,], 20, 1, logLike, partitionPrior, nAttempts=2)
#'   partitions[i,] <- x$partition
#'   nAccepts  <- nAccepts  + x$nAccepts
#'   nAttempts <- nAttempts + x$nAttempts
#' }
#'
#' nSubsets <- apply(partitions, 1, function(x) length(unique(x)))
#' mean(nSubsets)
#' nAccepts/nAttempts         # Acceptance rate
#' sum(acf(nSubsets)$acf)-1   # Autocorrelation time
#'
randomWalkFocalPartition <- function(partition, rate=1.0, mass=1.0, logLikelihoodOfSubset=function(subset) 0.0, priorDistribution=dCRPPartition(mass=1.0), nAttempts=1) {
  if ( rate <  0.0) stop("'rate' must be nonnegative.")
  if ( mass <= 0.0) stop("'mass' must be strictly positive.")
  if ( ! inherits(priorDistribution, "partitionDistribution") ) stop("'priorDistribution' is not recognized.")
  if ( is.list(partition) ) partition <- partition$partition
  if ( priorDistribution$name == "CRP" ) {
    .Call(.randomWalkFocalPartition_CRP, partition, rate, mass, logLikelihoodOfSubset, environment(), nAttempts, seed4rust(), priorDistribution$mass)
  } else if ( priorDistribution$name == "Focal" ) {
    pd <- priorDistribution
    .Call(.randomWalkFocalPartition_FRP, partition, rate, mass, logLikelihoodOfSubset, environment(), nAttempts, seed4rust(), pd$focal, pd$weights, pd$permutation-1L, pd$mass)
  } else stop(sprintf("'%s' is not supported.",priorDistribution$name))
}
