#define R_NO_REMAP
#define STRICT_R_HEADERS
#include <R.h>
#include <Rinternals.h>
#include <R_ext/Rdynload.h>

// Import C headers for rust API
#include "rustlib/dahl-randompartition.h"

// Actual Wrappers
RR_SEXP_vector_INTSXP rrAllocVectorINTSXP(int len) {
  RR_SEXP_vector_INTSXP s;
  s.sexp_ptr = (void*) PROTECT(Rf_allocVector(INTSXP, len));
  s.data_ptr = INTEGER((SEXP)s.sexp_ptr);
  s.len = len;
  return s;
}

double callRFunction_logIntegratedLikelihoodOfSubset(const void* fn_ptr, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP R_fcall = PROTECT(Rf_lang2(*(SEXP*)fn_ptr, R_NilValue));
  SETCADR(R_fcall, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(R_fcall, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

double callRFunction_logPosteriorPredictiveOfItem(const void* fn_ptr, int i, RR_SEXP_vector_INTSXP indices, const void* env_ptr) {
  SEXP s, t;
  t = s = PROTECT(Rf_allocList(3));
  SET_TYPEOF(s, LANGSXP);
  SETCAR(t, *(SEXP*)fn_ptr); t = CDR(t);
  SETCAR(t, Rf_ScalarInteger(i)); t = CDR(t);
  SETCAR(t, (SEXP)indices.sexp_ptr);
  double ans = Rf_asReal(Rf_eval(s, *(SEXP*)env_ptr));
  UNPROTECT(2);
  return ans;
}

SEXP randomWalkFocalPartition_CRP(SEXP partition_sexp, SEXP rate_sexp, SEXP mass_sexp, SEXP logLikelihoodOfSubset_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP crp_mass_sexp) {
  int prior_only = Rf_isNull(logLikelihoodOfSubset_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logLikelihoodOfSubset_sexp)) Rf_error("'logLikelihoodOfSubset' must be a function.");
  }
  void* logLikelihoodOfSubset_ptr = &logLikelihoodOfSubset_sexp;
  int rate = Rf_asReal(rate_sexp);
  double mass = Rf_asReal(mass_sexp);
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int n_accepts = 0;
  double crp_mass = Rf_asReal(crp_mass_sexp);
  dahl_randompartition__focalrw_crp(n_updates_for_partition, n_items, partition, rate, mass, prior_only, logLikelihoodOfSubset_ptr, env_ptr, seed, &n_accepts, crp_mass);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 3));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SET_VECTOR_ELT(results_sexp, 1, Rf_ScalarInteger(n_accepts));
  SET_VECTOR_ELT(results_sexp, 2, n_updates_for_partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 3));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("nAccepts"));
  SET_STRING_ELT(names_sexp, 2, Rf_mkChar("nAttempts"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(3);
  return results_sexp;
}

SEXP randomWalkFocalPartition_FRP(SEXP partition_sexp, SEXP rate_sexp, SEXP mass_sexp, SEXP logLikelihoodOfSubset_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP frp_partition_sexp, SEXP frp_weights_sexp, SEXP frp_permutation_sexp, SEXP frp_mass_sexp) {
  int prior_only = Rf_isNull(logLikelihoodOfSubset_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logLikelihoodOfSubset_sexp)) Rf_error("'logLikelihoodOfSubset' must be a function.");
  }
  void* logLikelihoodOfSubset_ptr = &logLikelihoodOfSubset_sexp;
  int rate = Rf_asReal(rate_sexp);
  double mass = Rf_asReal(mass_sexp);
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int n_accepts = 0;
  frp_partition_sexp = PROTECT(Rf_coerceVector(frp_partition_sexp, INTSXP));
  int* frp_partition = INTEGER(frp_partition_sexp);
  frp_weights_sexp = PROTECT(Rf_coerceVector(frp_weights_sexp, REALSXP));
  double* frp_weights = REAL(frp_weights_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  int* frp_permutation = INTEGER(frp_permutation_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  double frp_mass = Rf_asReal(frp_mass_sexp);
  dahl_randompartition__focalrw_frp(n_updates_for_partition, n_items, partition, rate, mass, prior_only, logLikelihoodOfSubset_ptr, env_ptr, seed, &n_accepts, frp_partition, frp_weights, frp_permutation, frp_mass);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 3));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SET_VECTOR_ELT(results_sexp, 1, Rf_ScalarInteger(n_accepts));
  SET_VECTOR_ELT(results_sexp, 2, n_updates_for_partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 3));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("nAccepts"));
  SET_STRING_ELT(names_sexp, 2, Rf_mkChar("nAttempts"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(7);
  return results_sexp;
}

SEXP nealAlgorithm3_CRP(SEXP partition_sexp, SEXP logPosteriorPredictiveDensity_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP mass_sexp) {
  int prior_only = Rf_isNull(logPosteriorPredictiveDensity_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logPosteriorPredictiveDensity_sexp)) Rf_error("'logPosteriorPrectiveDensity' must be a function.");
  }
  void* logPosteriorPredictiveOfItem_ptr = &logPosteriorPredictiveDensity_sexp;
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  double mass = Rf_asReal(mass_sexp);
  dahl_randompartition__neal_algorithm3_crp(n_updates_for_partition, n_items, partition, prior_only, logPosteriorPredictiveOfItem_ptr, env_ptr, seed, mass);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 1));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 1));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(3);
  return results_sexp;
}

SEXP nealAlgorithm3_NGGP(SEXP partition_sexp, SEXP logPosteriorPredictiveDensity_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP n_updates_for_u_sexp, SEXP nggp_u_sexp, SEXP nggp_mass_sexp, SEXP nggp_reinforcement_sexp) {
  int prior_only = Rf_isNull(logPosteriorPredictiveDensity_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logPosteriorPredictiveDensity_sexp)) Rf_error("'logPosteriorPrectiveDensity' must be a function.");
  }
  void* logPosteriorPredictiveOfItem_ptr = &logPosteriorPredictiveDensity_sexp;
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  int n_updates_for_u = Rf_asInteger(n_updates_for_u_sexp);
  double nggp_u = Rf_asReal(nggp_u_sexp);
  nggp_u_sexp = PROTECT(Rf_ScalarReal(nggp_u));   // Make a new u_sexp to avoid R's copy on modify semantics
  double* nggp_u_ptr = REAL(nggp_u_sexp);
  double nggp_mass = Rf_asReal(nggp_mass_sexp);
  double nggp_reinforcement = Rf_asReal(nggp_reinforcement_sexp);
  dahl_randompartition__neal_algorithm3_nggp(n_updates_for_partition, n_items, partition, prior_only, logPosteriorPredictiveOfItem_ptr, env_ptr, seed, n_updates_for_u, nggp_u_ptr, nggp_mass, nggp_reinforcement);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SET_VECTOR_ELT(results_sexp, 1, nggp_u_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  SET_STRING_ELT(names_sexp, 1, Rf_mkChar("u"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(4);
  return results_sexp;
}

SEXP nealAlgorithm3_FRP(SEXP partition_sexp, SEXP logPosteriorPredictiveDensity_sexp, SEXP env_sexp, SEXP n_updates_for_partition_sexp, SEXP seed_sexp, SEXP frp_partition_sexp, SEXP frp_weights_sexp, SEXP frp_permutation_sexp, SEXP frp_mass_sexp) {
  int prior_only = Rf_isNull(logPosteriorPredictiveDensity_sexp);
  if ( ! prior_only ) {
    if (!Rf_isFunction(logPosteriorPredictiveDensity_sexp)) Rf_error("'logPosteriorPrectiveDensity' must be a function.");
  }
  void* logPosteriorPredictiveOfItem_ptr = &logPosteriorPredictiveDensity_sexp;
  if (!Rf_isEnvironment(env_sexp)) Rf_error("'env' must be an environment.");
  void* env_ptr = &env_sexp;
  int n_items = Rf_length(partition_sexp);
  partition_sexp = PROTECT(Rf_coerceVector(partition_sexp, INTSXP));
  int* partition = INTEGER(partition_sexp);
  int n_updates_for_partition = Rf_asInteger(n_updates_for_partition_sexp);
  int *seed = INTEGER(seed_sexp);
  frp_partition_sexp = PROTECT(Rf_coerceVector(frp_partition_sexp, INTSXP));
  int* frp_partition = INTEGER(frp_partition_sexp);
  frp_weights_sexp = PROTECT(Rf_coerceVector(frp_weights_sexp, REALSXP));
  double* frp_weights = REAL(frp_weights_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  int* frp_permutation = INTEGER(frp_permutation_sexp);
  double frp_mass = Rf_asReal(frp_mass_sexp);
  dahl_randompartition__neal_algorithm3_frp(n_updates_for_partition, n_items, partition, prior_only, logPosteriorPredictiveOfItem_ptr, env_ptr, seed, frp_partition, frp_weights, frp_permutation, frp_mass);
  SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 1));
  SET_VECTOR_ELT(results_sexp, 0, partition_sexp);
  SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 1));
  SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
  Rf_namesgets(results_sexp, names_sexp);
  UNPROTECT(6);
  return results_sexp;
}

SEXP bCRPPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP mass_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  double mass = Rf_asReal(mass_sexp);
  dahl_randompartition__crp_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, mass);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(4);
    return results_sexp;
  } else {
    UNPROTECT(2);
    return probabilities_sexp;
  }
}

SEXP bEPAPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP similarity_sexp, SEXP permutation_sexp, SEXP mass_sexp, SEXP discount_sexp, SEXP use_random_permutation_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  similarity_sexp = PROTECT(Rf_coerceVector(similarity_sexp, REALSXP));
  double* similarity = REAL(similarity_sexp);
  permutation_sexp = PROTECT(Rf_coerceVector(permutation_sexp, INTSXP));
  int* permutation = INTEGER(permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  double discount = Rf_asReal(discount_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  dahl_randompartition__epa_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, similarity, permutation, mass, discount, use_random_permutation);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(6);
    return results_sexp;
  } else {
    UNPROTECT(4);
    return probabilities_sexp;
  }
}

SEXP bNGGPPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP u_sexp, SEXP mass_sexp, SEXP reinforcement_sexp, SEXP n_updates_for_u_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  double u = Rf_asReal(u_sexp);
  double mass = Rf_asReal(mass_sexp);
  double reinforcement = Rf_asReal(reinforcement_sexp);
  int n_updates_for_u = Rf_asInteger(n_updates_for_u_sexp);
  dahl_randompartition__nggp_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, u, mass, reinforcement, n_updates_for_u);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(4);
    return results_sexp;
  } else {
    UNPROTECT(2);
    return probabilities_sexp;
  }
}

SEXP bFocalPartition(SEXP do_sampling_sexp, SEXP partitions_sexp, SEXP probabilities_sexp, SEXP seed_sexp, SEXP frp_partition_sexp, SEXP frp_weights_sexp, SEXP frp_permutation_sexp, SEXP mass_sexp, SEXP use_random_permutation_sexp) {
  int do_sampling = Rf_asLogical(do_sampling_sexp);
  int n_partitions = Rf_nrows(partitions_sexp);
  int n_items = Rf_ncols(partitions_sexp);
  partitions_sexp = PROTECT(Rf_coerceVector(partitions_sexp, INTSXP));
  int* partitions = INTEGER(partitions_sexp);
  probabilities_sexp = PROTECT(Rf_coerceVector(probabilities_sexp, REALSXP));
  double* probabilities = REAL(probabilities_sexp);
  int *seed = INTEGER(seed_sexp);
  frp_partition_sexp = PROTECT(Rf_coerceVector(frp_partition_sexp, INTSXP));
  int* frp_partition = INTEGER(frp_partition_sexp);
  frp_weights_sexp = PROTECT(Rf_coerceVector(frp_weights_sexp, REALSXP));
  double* frp_weights = REAL(frp_weights_sexp);
  frp_permutation_sexp = PROTECT(Rf_coerceVector(frp_permutation_sexp, INTSXP));
  int* frp_permutation = INTEGER(frp_permutation_sexp);
  double mass = Rf_asReal(mass_sexp);
  int use_random_permutation = Rf_asLogical(use_random_permutation_sexp);
  dahl_randompartition__focal_partition(do_sampling, n_partitions, n_items, partitions, probabilities, seed, frp_partition, frp_weights, frp_permutation, mass, use_random_permutation);
  if ( do_sampling != 0 ) {
    SEXP results_sexp = PROTECT(Rf_allocVector(VECSXP, 2));
    SET_VECTOR_ELT(results_sexp, 0, partitions_sexp);
    SET_VECTOR_ELT(results_sexp, 1, probabilities_sexp);
    SEXP names_sexp = PROTECT(Rf_allocVector(STRSXP, 2));
    SET_STRING_ELT(names_sexp, 0, Rf_mkChar("partition"));
    SET_STRING_ELT(names_sexp, 1, Rf_mkChar("logProbability"));
    Rf_namesgets(results_sexp, names_sexp);
    UNPROTECT(7);
    return results_sexp;
  } else {
    UNPROTECT(5);
    return probabilities_sexp;
  }
}

// Standard R package stuff
static const R_CallMethodDef CallEntries[] = {
  {".randomWalkFocalPartition_CRP", (DL_FUNC) &randomWalkFocalPartition_CRP, 8},
  {".randomWalkFocalPartition_FRP", (DL_FUNC) &randomWalkFocalPartition_FRP, 11},
  {".nealAlgorithm3_CRP", (DL_FUNC) &nealAlgorithm3_CRP, 6},
  {".nealAlgorithm3_NGGP", (DL_FUNC) &nealAlgorithm3_NGGP, 9},
  {".nealAlgorithm3_FRP", (DL_FUNC) &nealAlgorithm3_FRP, 9},
  {".bCRPPartition", (DL_FUNC) &bCRPPartition, 5},
  {".bEPAPartition", (DL_FUNC) &bEPAPartition, 9},
  {".bNGGPPartition", (DL_FUNC) &bNGGPPartition, 8},
  {".bFocalPartition", (DL_FUNC) &bFocalPartition, 9},
  {NULL, NULL, 0}
};

void R_init_pumpkin(DllInfo *dll) {
  R_registerRoutines(dll, NULL, CallEntries, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
