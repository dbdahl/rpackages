context("posterior-sampling-matches")

# skip("posterior-sampling-matches")

mkLogIntegratedLikelihoodOfItem <- function(data, sigma2=0.1^2, mu0=0, sigma02=1) {
  function(i, subset) {
    posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
    posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
    posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
    dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
  }
}

mkLogIntegratedLikelihoodOfSubset <- function(f) {
  function(subset) sum(sapply(seq_along(subset), function(j) f(subset[j], subset[seq_len(j-1)])))
}

mkLogIntegratedLikelihoodOfPartition <- function(logIntegratedLikelihoodOfSubset) {
  function(partition) {
    result <- 0.0
    for ( label in unique(partition) ) {
      subset <- which(label == partition)
      result <- result + logIntegratedLikelihoodOfSubset(subset)
    }
    result
  }
}

engine <- function(data, partitionPrior) {

  logLike <- mkLogIntegratedLikelihoodOfSubset(mkLogIntegratedLikelihoodOfItem(data))

  nSamples <- 2000L
  nAccepts <- nAttempts <- 0L
  partitions <- matrix(0, nrow=nSamples, ncol=length(data))
  for ( i in 2:nSamples ) {
    x <- randomWalkFocalPartition(partitions[i-1,], 5, 1, logLike, partitionPrior, nAttempts=20)
    partitions[i,] <- x$partition
    nAccepts  <- nAccepts  + x$nAccepts
    nAttempts <- nAttempts + x$nAttempts
  }

  logLikePartition <- mkLogIntegratedLikelihoodOfPartition(logLike)

  logPosteriorUnnormalized <- function(partition, normalizingConst=0) {
    logLikePartition(partition) + partitionPrior$logProbability(partition) + normalizingConst
  }

  normalizingConst <- -log(sum(exp(apply(salso::enumerate.partitions(length(data)), 1, logPosteriorUnnormalized))))
  logPosterior <- function(partition) {
    logPosteriorUnnormalized(partition, normalizingConst=normalizingConst)
  }

  logPosteriorFromString <- function(partitionAsString) {
    sapply(partitionAsString, function(partitionAsString) logPosterior(as.numeric(strsplit(partitionAsString,"")[[1]])))
  }

  obs <- table(apply(partitions, 1, function(x) paste(x,collapse="")))

  df <- salso::bell(length(data))-1
  chisq <- sum(apply(salso::enumerate.partitions(length(data)), 1, function(partition) {
    expected <- nSamples * exp(logPosterior(partition))
    if ( expected < 5 ) {
      df <<- df - 1
      0.0
    } else {
      observed <- tryCatch(obs[[paste(partition,collapse="")]],error=function(x) 0.0)
      (observed - expected)^2 / expected
    }
  }))
  p.value <- pchisq(chisq,df=df,lower.tail=FALSE)
  cat("\nchisq: ",chisq,"; df: ",df,"; p.value: ",p.value,"\n",sep="")
  testthat::expect_gt(p.value, 0.001)

}

test_that("Sampling from CRP posterior from model/data of Neal (2000) matches enumeration.", {
  requireLevel(1)
  # Neal (2000) model and data
  nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
  data <- nealData[1:5]
  partitionPrior <- dCRPPartition(mass=1.0)
  engine(data, partitionPrior)
})

test_that("Sampling from focal posterior from model/data of Neal (2000) matches enumeration.", {
  requireLevel(1)
  # Neal (2000) model and data
  nealData <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
  data <- nealData[1:5]
  partitionPrior <- dFocalPartition(focal=c(0,0,1,1,1), weights=10, permutation=c(2,1,0,3,4), mass=1.0)
  engine(data, partitionPrior)
})
