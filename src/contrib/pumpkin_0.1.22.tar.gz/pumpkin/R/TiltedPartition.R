#' Probabilities for the Tilted Partition Distribution
#'
#' This function specifies the tilted partition distribution for given baseline
#' partition, weights, permutation and a baseline partition distribution.
#'
#' @inheritParams FocalPartition
#' @param baselineDistribution An object of class \code{partitionDistribution}
#'   representing a partition distribution, e.g., the result of calling the
#'   \code{\link{CRPPartition}}.
#' @param loss The loss function to use.  Currently supported loss functions are
#'   Binder loss and the generalization of the variation of information loss.
#'   This argument should therefore be either the result of calling
#'   \code{VI(a=x)} or \code{binder(a=x)} for some value \code{x}, but the
#'   \code{a=x} argument is optional.  See \code{\link[salso]{partition.loss}}.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/TiltedPartition.R
#' @importFrom salso VI
#' @export
#'
TiltedPartition <- function(baselinePartition, weights, permutation, baselineDistribution, loss=VI()) {
  nItems <- length(baselinePartition)
  if ( nItems < 1 ) stop("The number of items in 'baselinePartition' must be at least one.")
  if ( any(weights < 0.0) ) stop("'weights' must be nonnegative.")
  if ( length(weights) == 1 ) weights <- rep(weights, nItems)
  else  if ( length(weights) != nItems ) stop("The length of 'weights' must be equal to the number of items in 'baselinePartition'.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'baselinePartition'.")
  if ( ! inherits(baselineDistribution, "partitionDistribution") ) stop("'baselineDistribution' must be a valid partition distribution.")
  if ( baselineDistribution$nItems != nItems ) stop("'baselinePartition' implies a different number of items than the baseline partition distribution.")
  if ( ! inherits(loss, "salso.loss") ) stop("'loss' must be a 'partition.loss' object.")
  if ( ! ( loss$loss %in% c("binder", "VI") ) ) {
    stop(sprintf("'%s' is not a supported loss.", loss$loss))
  }
  result <- list(nItems=nItems, baselinePartition=baselinePartition, weights=weights, permutation=permutation-1L, baselineDistribution=baselineDistribution, loss=loss)
  class(result) <- c("TiltedPartition", "partitionDistribution")
  result
}

#' @export
print.TiltedPartition <- function(x, ...) {
  cat("\nTilted partition distribution\n\n")
  z <- unclass(x)
  z$permutation <- z$permutation + 1L
  print(z)
}

samplePartitionTiltedPartition <- function(distr, nSamples, randomizePermutation) {
  samples <- matrix(0L, nrow=nSamples, ncol=distr$nItems)
  for ( k in seq_len(nSamples) ) {
    partition <- 1
    for ( i in seq_len(distr$nItems)[-1] ) {
      candidates <- Reduce(rbind, c(lapply(seq_along(unique(partition)), function(x) c(partition,x)), list(c(partition,length(unique(partition))+1))))
      weights <- prPartition(distr$baselineDistribution, candidates, log=FALSE) * exp( -distr$weights[i] * (i-1) * salso::VI(candidates, distr$baselinePartition[seq_len(i)]) )
      partition <- candidates[sample.int(nrow(candidates), 1, prob=weights),]
    }
    samples[k,] <- partition
  }
  samples
}

