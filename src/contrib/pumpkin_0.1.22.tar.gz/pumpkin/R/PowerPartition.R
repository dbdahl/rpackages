#' Probabilities for the Power Partition Distribution
#'
#' This function specifies the power partition distribution for given for given
#' mass (a.k.a., concentration) and power parameters.
#'
#' @inheritParams CRPPartition
#' @param power A scalar by which the each cluster size is exponentiated.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @export
#'
PowerPartition <- function(nItems, mass, power) {
  if ( nItems < 1 ) stop("'nItems' must be at least one.")
  if ( ( length(power) != 1 ) || ! is.numeric(power) || is.na(power) ) stop("'power' must be a scalar.")
  result <- list(nItems=nItems, mass=mass, power=power)
  class(result) <- c("PowerPartition", "partitionDistribution")
  result
}

#' @export
#'
print.PowerPartition <- function(x, ...) {
  cat("\nPower partition distribution\n\n")
  print(unclass(x))
}

#' @export
#'
samplePartition.PowerPartition <- function(distr, nSamples, randomizePermutation=FALSE) {
  samples <- matrix(0L, nrow=nSamples, ncol=distr$nItems)
  for ( k in seq_len(nSamples) ) {
    partition <- 1
    for ( i in seq_len(distr$nItems)[-1] ) {
      candidates <- Reduce(rbind, c(lapply(seq_along(unique(partition)), function(x) c(partition,x)), list(c(partition,length(unique(partition))+1))))
      weights <- c(lapply(seq_along(unique(partition)), function(x) sum(partition==x)^distr$power), list(distr$mass))
      partition <- candidates[sample.int(nrow(candidates), 1, prob=weights),]
    }
    samples[k,] <- partition
  }
  samples
}
