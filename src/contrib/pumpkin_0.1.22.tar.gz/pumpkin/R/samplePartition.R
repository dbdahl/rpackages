#' Sample From a Partition Distribution
#'
#' This function samples from a partition distribution.
#'
#' Note that the centered partition distribution \code{\link{CenteredPartition}}
#' is not supported, but could be sampled using Markov chain Monte Carlo, using
#' \code{\link{nealAlgorithm3}} or \code{\link{nealAlgorithm8}}.
#'
#' @param distr A specification of the partition distribution, i.e., an object
#'   of class \code{partitionDistribution} as returned by, for example, a
#'   function such as \code{\link{CRPPartition}}.
#' @param nSamples An integer giving the number of partitions to sample.
#' @param randomizePermutation Should the permutation be uniformly randomly
#'   sampled?
#'
#' @return An integer matrix containing a partition in each row using cluster
#'   label notation.
#'
#' @seealso \code{\link{CRPPartition}}, \code{\link{FocalPartition}},
#'   \code{\link{LocationScalePartition}}, \code{\link{CenteredPartition}},
#'   \code{\link{prPartition}}, \code{\link{nealAlgorithm3}},
#'   \code{\link{nealAlgorithm8}}
#'
#' @example man/examples/prPartition.R
#'
#' @useDynLib pumpkin .samplePartition
#' @export
#'
samplePartition <- function(distr, nSamples, randomizePermutation=FALSE) {
  UseMethod("samplePartition")
}

#' @export
#'
samplePartition.default <- function(distr, nSamples, randomizePermutation=FALSE) {
  engine <- function(priorID, p) {
    .Call(.samplePartition, nSamples, distr$nItems, seed4rust(), priorID, p, randomizePermutation)
  }
  partitionDispatch(engine, distr, c("CenteredPartition","PowerPartition","PeggedTimeDependentPartition"))
}
