#' Probabilities for the Distance-Dependent CRP (ddCRP) Partition Distribution
#'
#' This function specifies the Distance-Dependent CRP (ddCRP) partition
#' distribution for given similarity matrix and mass (a.k.a., concentration).
#'
#' @inheritParams EPAPartition
#' @param similarity An n-by-n symmetric matrix giving the similarity between
#'   pairs of items.  Matrix entries must be strictly positive.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/DDCRPPartition.R
#' @export
#'
DDCRPPartition <- function(similarity, mass) {
  checkSimilarity(similarity)
  nItems <- nrow(similarity)
  if ( nItems < 1 ) stop("The number of rows in 'similarity' must be at least one.")
  checkMassDiscount(mass, 0.0)
  result <- list(nItems=nItems, similarity=similarity, mass=mass)
  class(result) <- c("DDCRPPartition", "partitionDistribution")
  result
}

#' @export
print.DDCRPPartition <- function(x, ...) {
  cat("\nDDCRP partition distribution\n\n")
  print(unclass(x))
}

edgesToLabels <- function(edges) {
  n <- length(edges)
  labels <- integer(n)
  visited <- logical(n)
  nextAvailableLabel <- 0
  findLabelFor <- function(i) {
    if ( labels[i] == 0 ) {
      labels[i] <<- if ( visited[i] ) {
        nextAvailableLabel <<- nextAvailableLabel + 1
        nextAvailableLabel
      } else {
        visited[i] <<- TRUE
        findLabelFor(edges[i])
      }
    }
    labels[i]
  }
  sapply(seq_along(edges), findLabelFor)
}

#' @export
#'
samplePartition.DDCRPPartition <- function(distr, nSamples, randomizePermutation=FALSE) {
  m <- distr$similarity
  diag(m) <- distr$mass
  t(sapply(seq_len(nSamples), function(k) edgesToLabels(sapply(seq_len(distr$nItems), function(i) sample(distr$nItems, 1, prob=m[i,])))))
}
