#' Probabilities for the Pegged Time Dependent Random Partition Distribution
#'
#' This function specifies the pegged time dependent random partition
#' distribution for given mass (a.k.a., concentration), discount, and pegging
#' probability parameters and the given number of time slices.
#'
#' @inheritParams CRPPartition
#' @inheritParams TiltedPartition
#' @param nSlices The number of time slices to consider in {1, 2, ...}.
#' @param peggedProbability The probability that an item is not reallocated
#'   between time points.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/PeggedTimeDependentPartition.R
#' @export
#'
PeggedTimeDependentPartition <- function(nItems, mass, discount, nSlices, peggedProbability, baselinePartition=NULL) {
  if ( nItems < 1 ) stop("'nItems' must be at least one.")
  checkMassDiscount(mass, discount)
  if ( nSlices < 1 ) stop("'nSlices' must be at least one.")
  if ( peggedProbability < 0 || peggedProbability > 1 ) stop("'peggedProbability' must be in [0,1].")
  result <- list(nItems=nItems, mass=mass, discount=discount, nSlices=nSlices, peggedProbability=peggedProbability, baselinePartition=baselinePartition)
  class(result) <- c("PeggedTimeDependentPartition", "partitionDistribution")
  return(result)
}

#' @export
print.PeggedTimeDependentPartition <- function(x, ...) {
  cat("\nPegged time dependent partition distribution\n\n")
  print(unclass(x))
}

#' @importFrom stats rbinom
#' @export
#'
samplePartition.PeggedTimeDependentPartition <- function(distr, nSamples, randomizePermutation=FALSE) {
  x <- array(0L, dim=c(nSamples, distr$nItems, distr$nSlices, 2))
  x[,,-1,1] <- rbinom(nSamples*distr$nItems*(distr$nSlices-1), 1, distr$peggedProbability)
  x[,,1,2] <- if ( is.null(distr$baselinePartition) ) {
    samplePartition(CRPPartition(distr$nItems, distr$mass, distr$discount), nSamples, randomizePermutation)
  } else {
    rep(distr$baselinePartition, each=nSamples)
  }
  for ( t in seq_len(distr$nSlices-1)+1 ) {
    x[,,t,2] <- x[,,t-1,2,drop=FALSE]
    x[,,t,2][x[,,t,1,drop=FALSE]!=1] <- NA
    x[,,t,2] <- t(apply(x[,,t,2,drop=FALSE], 1, function(y) {
      tab <- if ( all(is.na(y)) ) 0
      else table(factor(y, levels=seq_len(max(y,na.rm=TRUE))))
      for ( i in which(is.na(y)) ) {
        y[i] <- sample(c(seq_along(tab),length(tab)+1), 1, prob=c(tab-ifelse(tab==0,0,distr$discount), distr$mass+distr$discount*sum(tab!=0)))
        if ( y[i] > length(tab) ) tab[y[i]] <- 0
        tab[y[i]] <- tab[y[i]] + 1
      }
      canonicalForm(y)
    }))
  }
  x
}

expectedRI <- function(x, y) {
  s <- 0
  for ( i in seq_len(nrow(x)) ) {
    s <- s + salso::RI(x[i,],y[i,])
  }
  s/nrow(x)
}

probPaired <- function(x, y, togetherAtTime1=TRUE, i=1, j=2) {
  w <- if ( is.null(togetherAtTime1) ) rep(TRUE,nrow(x))
  else if ( togetherAtTime1 ) x[,i] == x[,j]
  else if ( ! togetherAtTime1 ) x[,i] != x[,j]
  else stop("Error")
  mean(y[w,i] == y[w,j])
}
