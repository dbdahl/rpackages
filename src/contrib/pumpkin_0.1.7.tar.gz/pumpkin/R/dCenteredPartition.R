#' Probabilities for the Centered Partition Process
#'
#' This function evaluates the probability mass function of the centered
#' partition distribution for given partition, rate, mass (a.k.a.,
#' concentration), and discount parameters.
#'
#' @param partition An integer matrix containing a partition in each row in
#'   cluster label form.
#' @param center An integer vector giving the centering partition.
#' @param rate A numeric vector of length one giving the rate.
#' @param mass The mass (a.k.a., concentration) parameter as a numeric value
#'   greater than the \code{-discount}.
#' @param discount The discount parameter as a numeric value in [0,1).
#' @param useVI Should the distance between the a particular partition and the
#'   centered partition be measured using the variation of information
#'   (\code{TRUE}) or using Binder loss (\code{FALSE})?
#' @param a A nonnegative scalar giving the relative cost of placing two items
#'   in separate clusters when in truth they belong to the same cluster.  This
#'   defaults to \code{1}, meaning equal costs.
#' @param log A logical indicating whether the probability (\code{FALSE}) or its
#'   natural logarithm (\code{TRUE}) is desired.
#'
#' @return A numeric vector giving either probabilities or log probabilities for
#'   the supplied partitions.
#'
#' @example man/examples/dCenteredPartition.R
#' @useDynLib pumpkin .dCenteredPartition
#' @export
#'
dCenteredPartition <- function(partition, center, rate, mass, discount=0, useVI=TRUE, a=1.0, log=FALSE) {
  checkArgumentsCenteredPartition(center, rate, mass, discount, useVI, a)
  if ( missing(partition) ) {
    result <- list(name="Centered", center=center, rate=rate, mass=mass, discount=discount, useVI=useVI, a=a,
                   logProbability=function(partition) dCenteredPartitionEngine(partition, center, rate, mass, discount, useVI, a, log=TRUE))
    class(result) <- "partitionDistribution"
    result
  } else {
    dCenteredPartitionEngine(partition, center, rate, mass, discount, useVI, a, log)
  }
}

dCenteredPartitionEngine <- function(partition, center, rate, mass, discount, useVI, a, log) {
  if ( ! is.matrix(partition) ) partition <- matrix(partition, nrow=1)
  if ( ncol(partition) != length(center) ) stop("Length of 'partition' must equal the length of 'center'.")
  nSamples <- nrow(partition)
  if ( nSamples < 1 ) stop("The number of rows of 'partition' must be at least one.")
  logProbabilities <- .Call(.dCenteredPartition, partition, numeric(nSamples), center, rate, mass, discount, useVI, a)
  if (log) logProbabilities else exp(logProbabilities)
}

checkArgumentsCenteredPartition <- function(center, rate, mass, discount, useVI, a) {
  nItems <- length(center)
  if ( nItems < 1 ) stop("The number of items in 'center' must be at least one.")
  if ( length(rate) != 1 ) stop("'rate' must be a scalar.")
  if ( rate < 0.0 ) stop("'rate' must be nonnegative.")
  if ( ( discount < 0.0 ) || ( discount >= 1 ) ) stop("'discount' must be in [0,1).")
  if ( mass <= -discount ) stop("'mass' must be greater than -'discount'.")
  if ( ! is.logical(useVI) ) stop("'useVI' must be a logical.")
  if ( length(a) != 1 ) stop("'a' must be a scalar.")
  if ( a < 0.0 ) stop("'a' must be nonnegative.")
}
