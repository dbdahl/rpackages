partition <- c(1,1,2,2,3)
location <- c(1,1,1,2,2)
scale <- 0.2
rate <- 1/scale
permutation <- c(1,5,4,2,3)

dLocationScalePartition(partition, location, rate, permutation)
x <- rLocationScalePartition(100, location, rate, permutation, useRandomPermutation=FALSE)
p <- dLocationScalePartition(x$partition, location, rate, permutation, log=TRUE)
all.equal(p, x$logProbability)
