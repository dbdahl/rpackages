CenteredPartition(baselinePartition=c(1,1,1,2,2), weight=3, mass=1.0, discount=0.1)
