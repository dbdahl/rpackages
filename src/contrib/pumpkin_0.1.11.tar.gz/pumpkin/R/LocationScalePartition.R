#' Probabilities for the Location Scale Partition Distribution
#'
#' This function evaluates the probability mass function of the location scale
#' partition distribution for given target partition, weight, and permutation
#' parameters.  The weight parameter is the reciprocal of the scale parameter.
#'
#' @inheritParams FocalPartition
#' @param weight A numeric value giving the weight, i.e., the reciprocal of the
#'   scale.
#'
#' @return An object of class \code{partitionDistribution} representing this
#'   partition distribution.
#'
#' @example man/examples/LocationScalePartition.R
#' @export
#'
LocationScalePartition <- function(target, weight, permutation) {
  nItems <- length(target)
  if ( nItems < 1 ) stop("The number of items in 'target' must be at least one.")
  if ( length(weight) != 1 ) stop("'weight' must be a scalar.")
  if ( weight < 0.0 ) stop("'weight' must be nonnegative.")
  checkPermutation(permutation)
  if ( length(permutation) != nItems ) stop("The length of 'permutation' must equal the length of 'target'.")
  result <- list(nItems=nItems, target=target, weight=weight, permutation=permutation-1L)
  class(result) <- c("LocationScalePartition", "partitionDistribution")
  result
}

#' @export
print.LocationScalePartition <- function(x, ...) {
  cat("\nLocation scale partition distribution\n\n")
  z <- unclass(x)
  z$permutation <- z$permutation + 1L
  print(z)
}
