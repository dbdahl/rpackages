# Neal (2000) model and data

data <- c(-1.48, -1.40, -1.16, -1.08, -1.02, 0.14, 0.51, 0.53, 0.78)
sigma2 <- 0.1^2
mu0 <- 0
sigma02 <- 1

logIntegratedLikelihoodItem <- function(i, subset) {
  posteriorVariance     <- 1 / ( 1/sigma02 + length(subset)/sigma2 )
  posteriorMean         <- posteriorVariance * ( mu0/sigma02 + sum(data[subset])/sigma2 )
  posteriorPredictiveSD <- sqrt(posteriorVariance + sigma2)
  dnorm(data[i], posteriorMean, posteriorPredictiveSD, log=TRUE)
}

mass <- 1.5
discount <- 0.2
target <- c(1,1,2,2,2,3,4,4,4)
permutation <- sample(length(target))

distr <- CRPPartition(length(data), mass, discount)
distr <- LocationScalePartition(target, 3, permutation)
distr <- CenteredPartition(target, weight=3, mass, discount)
distr <- FocalPartition(target, weights=c(3,3,1,1,1,0,5,5,0), permutation, mass, discount)

# MCMC

mcmcTuning <- list(nUpdates=2)
nSamples <- 1000L
partitionSamples <- matrix(1, nrow=nSamples, ncol=length(data))
nAcceptancesPermutation <- 0L
for ( i in 2:nSamples ) {
  # Update partition
  partitionSamples[i,] <- nealAlgorithm3(partitionSamples[i-1,],
                                         distr, logIntegratedLikelihoodItem, mcmcTuning)$partition
  # Update permutation
  out <- updatePermutation(distr, partitionSamples[i,], k=length(data)/2)
  distr <- out$distr
  nAcceptancesPermutation <- nAcceptancesPermutation + out$accepted
  # Perhaps add code to update other parameters, e.g., mass, discount, etc.
}

# Acceptance rate for updating the permutation
nAcceptancesPermutation / nSamples

nSubsets <- apply(partitionSamples, 1, function(x) length(unique(x)))
mean(nSubsets)
sum(acf(nSubsets)$acf)-1   # Autocorrelation time





# # Prior partition distribution
#
#
# target <- c(1,1,1,1,1,2,2,2,2)
#
# distr <- dLocationScalePartition(
#     target=target, weight=1/0.5, permutation=seq_along(data))
#
# distr <- dCenteredPartition(
#     target=target, weight=2, mass=1.0)
#
# distr <- dFocalPartition(
#     target=target, weights=2, permutation=seq_along(data), mass=1.0, discount=0.1)
#

# #
# # # Covariate-based partition distribution
# #
# # partition <- c(0,0,1,1,2)
# # subset <- c("Maine","Georgia","California","Minnesota","Montana")
# # d <- as.matrix(dist(USArrests[subset,]))
# # temperature <- 1.0
# # similarity <- exp( -temperature * d )
# # mass <- 1.0
# # discount <- 0.1
# #
# # distr <- dEPAPartition(similarity=similarity, permutation=1:5,
# #     mass=mass, discount=discount)
# #
# # mcmcTuning <- list(nUpdates=2)
# # nSamples <- 1000L
# # nAccepts <- nAttempts <- 0L
# # partitions <- matrix(1, nrow=nSamples, ncol=ncol(similarity))
# # for ( i in 2:nSamples ) {
# #   # Update partition
# #   partitions[i,] <- nealAlgorithm3(partitions[i-1,], logIntegratedLikelihoodItem,
# #                                    distr, mcmcTuning)$partition
# #   # Update permutation
# #   if ( ! is.null(distr$permutation) ) {
# #     proposal <- sample(distr$permutation)
# #     logMHRatio <- 0.0
# #     logMHRatio <- logMHRatio + dEPAPartition(partitions[i,], similarity=similarity, mass=1.0,
# #         permutation=proposal)
# #     logMHRatio <- logMHRatio - dEPAPartition(partitions[i,], similarity=similarity, mass=1.0,
# #         permutation=distr$permutation)
# #     if ( log(runif(1)) < logMHRatio ) distr$permutation <- proposal
# #   }
# #   # Perhaps add code to update other parameters, e.g., mass, discount, etc.
# # }
# #
# # salso::psm(partitions)
# # d
# #
